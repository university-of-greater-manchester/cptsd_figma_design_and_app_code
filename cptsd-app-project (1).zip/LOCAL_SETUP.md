# CPTSD Toolkit - Local Development Setup

## Prerequisites

### System Requirements
- **Node.js**: v24.14.1 or higher
- **npm**: v11.11.0 or higher (or pnpm v9+)
- **PostgreSQL**: v14 or higher (for local database, or use Neon cloud)
- **Git**: v2.30 or higher

### Required Tools
- Code editor (VS Code recommended)
- Git client
- Terminal/Command line

---

## Step 1: Clone the Repository

```bash
git clone <your-repository-url>
cd cptsd-toolkit
```

---

## Step 2: Install Dependencies

### Using npm
```bash
npm install
```

### Using pnpm (recommended)
```bash
pnpm install
```

### Using yarn
```bash
yarn install
```

**Installed Dependencies:**
- `next`: 16.2.6 - React framework with App Router
- `react`: 19 - UI library
- `react-dom`: 19 - React DOM rendering
- `better-auth`: 1.6.14 - Email/password authentication
- `pg`: 8.21.0 - PostgreSQL client
- `drizzle-orm`: 0.45.2 - Type-safe SQL ORM
- `lucide-react`: 1.16.0 - Icon library
- `tailwindcss`: 4.2.0 - Utility-first CSS framework
- `shadcn`: 4.8.0 - Pre-built UI components
- `recharts`: 3.8.1 - Data visualization charts
- `sonner`: 2.0.7 - Toast notifications
- `typescript`: 5.7.3 - Type safety
- `@vercel/analytics`: 1.6.1 - Analytics tracking

---

## Step 3: Environment Configuration

### Create `.env.local` file

Copy the following template and fill in your values:

```bash
# Database Connection
# Format: postgresql://user:password@host:port/database
DATABASE_URL=postgresql://user:password@localhost:5432/cptsd_toolkit

# Better Auth Secret
# Generate with: openssl rand -base64 32
BETTER_AUTH_SECRET=your-secret-key-here-minimum-32-characters

# Optional: Better Auth URL (defaults to localhost:3000 in development)
# BETTER_AUTH_URL=http://localhost:3000

# Optional: Vercel Analytics
# NEXT_PUBLIC_VERCEL_ANALYTICS_ID=your-vercel-analytics-id
```

### Environment Variables Explained

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string. Format: `postgresql://user:password@host:port/database` |
| `BETTER_AUTH_SECRET` | Yes | 32+ character secret for signing auth sessions. Generate with `openssl rand -base64 32` |
| `BETTER_AUTH_URL` | No | Override auth URL. Defaults to `VERCEL_URL` or `http://localhost:3000` in dev |
| `NEXT_PUBLIC_VERCEL_ANALYTICS_ID` | No | Vercel Analytics tracking ID for production |

---

## Step 4: Database Setup

### Option A: Using Neon (Cloud PostgreSQL)

1. Go to [neon.tech](https://neon.tech) and create a free account
2. Create a new project
3. Copy the connection string to `DATABASE_URL` in `.env.local`
4. Skip to Step 5 (no local database needed)

### Option B: Local PostgreSQL

#### Install PostgreSQL
- **macOS**: `brew install postgresql`
- **Ubuntu/Debian**: `sudo apt-get install postgresql postgresql-contrib`
- **Windows**: Download from [postgresql.org](https://www.postgresql.org/download/windows/)

#### Create Database and User
```bash
# Connect to PostgreSQL
psql -U postgres

# Inside psql:
CREATE DATABASE cptsd_toolkit;
CREATE USER cptsd_user WITH PASSWORD 'your_secure_password';
ALTER ROLE cptsd_user SET client_encoding TO 'utf8';
ALTER ROLE cptsd_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE cptsd_user SET default_transaction_deferrable TO on;
ALTER ROLE cptsd_user SET default_transaction_read_only TO off;
GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;
\q
```

#### Set DATABASE_URL
```bash
# In .env.local
DATABASE_URL=postgresql://cptsd_user:your_secure_password@localhost:5432/cptsd_toolkit
```

#### Create Database Tables

The app will auto-create all tables on first run via Better Auth and the schema. Tables created:
- `user` - User accounts
- `session` - Auth sessions
- `account` - Account credentials
- `verification` - Email verification tokens
- `user_profile` - Extended user data
- `journal_entry` - Journal entries
- `daily_check_in` - Daily mood tracking
- `grounding_exercise` - Completed exercises
- `coping_strategy` - Saved strategies

---

## Step 5: Generate Better Auth Secret

If you haven't already, generate a secure secret:

```bash
# macOS/Linux
openssl rand -base64 32

# Windows (PowerShell)
[Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
```

Copy the output and add it to `BETTER_AUTH_SECRET` in `.env.local`.

---

## Step 6: Verify Environment Variables

Ensure `.env.local` has all required variables:

```bash
# Verify DATABASE_URL is set
echo $DATABASE_URL

# Verify BETTER_AUTH_SECRET is set
echo $BETTER_AUTH_SECRET
```

Both should return non-empty values.

---

## Step 7: Start Development Server

### Single Command
```bash
npm run dev
# or
pnpm dev
```

### Expected Output
```
> next dev

  ▲ Next.js 16.2.6
  - Local:        http://localhost:3000
  - Environments: .env.local

  ✓ Ready in 2.3s
```

The app is now running at **http://localhost:3000**

---

## Verification Checklist

After starting the dev server:

- [ ] App loads at http://localhost:3000
- [ ] Landing page displays with correct two-tone color scheme (dark forest green + beige)
- [ ] Sign-up page accessible at http://localhost:3000/sign-up
- [ ] Can create a test account
- [ ] Redirects to dashboard after sign-up
- [ ] Dashboard displays "Welcome Back" message with user name
- [ ] Navigation buttons work
- [ ] No console errors (check browser DevTools)

---

## Troubleshooting

### Database Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
**Solution**: Ensure PostgreSQL is running
- macOS: `brew services start postgresql`
- Linux: `sudo systemctl start postgresql`
- Windows: Start PostgreSQL service from Services

### "Invalid origin" error on sign-up
**Solution**: Ensure `DATABASE_URL` and `BETTER_AUTH_SECRET` are set correctly in `.env.local`

### Port 3000 already in use
```bash
# Use different port
npm run dev -- -p 3001
```

### Tailwind styles not loading
```bash
# Rebuild Tailwind cache
rm -rf .next && npm run dev
```

---

## Build for Production

```bash
# Build the app
npm run build

# Start production server
npm start
```

---

## Project Structure

```
cptsd-toolkit/
├── app/
│   ├── api/auth/[...all]/route.ts    # Auth endpoints
│   ├── actions/                       # Server actions (CRUD)
│   ├── dashboard/                     # Protected dashboard
│   ├── journal/                       # Journal entries
│   ├── check-in/                      # Daily check-ins
│   ├── grounding/                     # Grounding exercises
│   ├── coping/                        # Coping strategies
│   ├── profile/                       # User profile
│   ├── sign-in/page.tsx               # Sign in page
│   ├── sign-up/page.tsx               # Sign up page
│   ├── layout.tsx                     # Root layout
│   ├── page.tsx                       # Landing page
│   └── globals.css                    # Global styles
├── components/
│   ├── auth-form.tsx                  # Login/signup form
│   ├── bottom-nav-bar.tsx             # Mobile navigation
│   ├── side-menu.tsx                  # Slide-out menu
│   └── ui/                            # shadcn/ui components
├── lib/
│   ├── auth.ts                        # Better Auth config
│   ├── auth-client.ts                 # Auth client
│   └── db/
│       ├── index.ts                   # Drizzle ORM client
│       └── schema.ts                  # Database schema
├── public/                            # Static assets
├── .env.local                         # Environment variables (create this)
├── .env.example                       # Template (reference only)
├── package.json                       # Dependencies
├── tsconfig.json                      # TypeScript config
└── next.config.mjs                    # Next.js config
```

---

## Development Workflow

### Running Tests
```bash
npm run lint
```

### Code Formatting
Tailwind and ESLint are configured. Auto-format on save in VS Code:
```json
// .vscode/settings.json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode"
}
```

### Database Migrations
Schema changes are managed via SQL directly in Neon console or local psql.

---

## Deployment

### Deploy to Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Vercel automatically:
- Installs dependencies
- Sets up environment variables from dashboard
- Runs build
- Deploys to production

### Environment Variables on Vercel
Add to Vercel project settings:
- `DATABASE_URL` - Your Neon connection string
- `BETTER_AUTH_SECRET` - Your 32+ character secret

---

## Support & Resources

- **Next.js Docs**: https://nextjs.org/docs
- **Better Auth**: https://better-auth.com
- **Drizzle ORM**: https://orm.drizzle.team
- **Tailwind CSS**: https://tailwindcss.com
- **shadcn/ui**: https://ui.shadcn.com

---

## Getting Help

If you encounter issues:

1. Check the **Troubleshooting** section above
2. Review browser console for errors (F12)
3. Check server logs in terminal
4. Verify all `.env.local` variables are set
5. Ensure PostgreSQL is running (if using local DB)
