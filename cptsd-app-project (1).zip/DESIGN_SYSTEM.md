# CPTSD Toolkit - Design System

## Color Palette

The application uses a strict 2-color design system for a calming, focused therapeutic experience.

### Primary Colors
- **Dark Forest Green** (#153a21) - Background, Primary text, Borders, Card backgrounds
- **Beige/Gold** (#b5a47d) - Accent text, Primary buttons, Cards content, Highlights

### Design Token Mapping (from globals.css)
```
--background: #153a21 (Dark forest green)
--foreground: #b5a47d (Beige/gold)
--card: #b5a47d (Beige accent - used for card backgrounds)
--card-foreground: #153a21 (Dark green text on beige cards)
--primary: #b5a47d (Beige - main action color)
--primary-foreground: #153a21 (Dark green text on beige buttons)
--secondary: #153a21 (Dark green)
--secondary-foreground: #b5a47d (Beige text on dark green)
--accent: #b5a47d (Beige accent)
--accent-foreground: #153a21 (Dark text on accent)
--border: #153a21 (Dark green borders)
--input: #153a21 (Dark green input backgrounds)
--ring: #b5a47d (Beige focus rings)
--destructive: #dc2626 (Red for errors/warnings)
```

## Component Usage Guidelines

### Buttons

#### Primary Buttons (Default)
- Used for main actions (Save, Submit, Continue, Create)
- Background: `bg-primary` (#b5a47d beige)
- Text: `text-primary-foreground` (#153a21 dark green)
- Hover: 80% opacity on background
```jsx
<Button variant="default">Create Journal Entry</Button>
```

#### Secondary Buttons
- Used for alternative actions, less prominent
- Background: `bg-secondary` (#153a21 dark green)
- Text: `text-secondary-foreground` (#b5a47d beige)
```jsx
<Button variant="secondary">Cancel</Button>
```

#### Outline Buttons
- Used for less prominent actions, transparent background
- Border: `border-border` (#153a21 dark green)
- Text: `text-foreground` (#b5a47d beige)
- Hover: `hover:bg-muted` (subtle background)
```jsx
<Button variant="outline">Back</Button>
```

#### Ghost Buttons
- Used for icon buttons in headers, minimal styling
- No background, text only
- Hover: `hover:bg-muted` with light background
```jsx
<Button variant="ghost" size="icon">
  <Bell className="h-5 w-5" />
</Button>
```

#### Icon Buttons
- Use `size="icon"` for icon-only buttons
- Apply same variant rules as above
- Standard size: 40px (h-10 w-10)
```jsx
<Button variant="ghost" size="icon" className="h-10 w-10">
  <ArrowLeft className="h-5 w-5" />
</Button>
```

### Form Inputs

#### Text Inputs
- Background: `bg-transparent` with `border-border` (#153a21)
- Text: `text-foreground` (#b5a47d)
- Placeholder: `placeholder:text-muted-foreground` (lighter beige)
- Focus: `focus-visible:ring-3 focus-visible:ring-ring` (beige ring)
```jsx
<Input placeholder="Enter your name" />
```

#### Textareas
- Same styling as inputs but for multi-line content
- Use for journal entries, notes, descriptions
```jsx
<Textarea placeholder="Write your thoughts..." />
```

#### Labels
- Text: `text-foreground` (#b5a47d)
- Pair with inputs using `<Label htmlFor="input-id">`
```jsx
<Label htmlFor="mood">How are you feeling?</Label>
<Input id="mood" />
```

### Cards

#### Card Container
- Background: `bg-card` (#b5a47d beige)
- Text: `text-card-foreground` (#153a21 dark green)
- Border: `ring-1 ring-foreground/10` (subtle beige ring)
- Rounded: `rounded-xl` (1rem border radius)
```jsx
<Card>
  <CardContent>Quick action card content</CardContent>
</Card>
```

#### Card Header
- Usually contains title and description
- Padding: `px-4 py-4` (responsive)
```jsx
<CardHeader>
  <CardTitle>Journal Entry</CardTitle>
  <CardDescription>June 6, 2026</CardDescription>
</CardHeader>
```

#### Card Content
- Main card body content
- Padding: `px-4` (responsive)
```jsx
<CardContent>
  Your content here
</CardContent>
```

#### Card Footer
- Background: `bg-muted/50` (light beige background)
- Border-top: `border-t` (#153a21)
- Used for action buttons at bottom
```jsx
<CardFooter>
  <Button>Save</Button>
</CardFooter>
```

### Radio Buttons & Checkboxes

- Accent color: `accent-accent` (#b5a47d beige)
- Checked state: Background #b5a47d with dark green checkmark
```jsx
<div className="flex items-center gap-2">
  <input type="radio" id="option1" className="accent-accent" />
  <label htmlFor="option1" className="text-foreground">Option 1</label>
</div>
```

### Dropdowns & Select Menus

- Button styling: Follow button guidelines (primary/secondary/outline)
- Dropdown menu background: `bg-card` (#b5a47d)
- Menu item text: `text-card-foreground` (#153a21)
- Hover item: Slightly darker shade
- Selected item: Bold text with beige background
```jsx
<DropdownMenu>
  <DropdownMenuTrigger asChild>
    <Button variant="outline">Options</Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent className="bg-card">
    <DropdownMenuItem>Item 1</DropdownMenuItem>
    <DropdownMenuItem>Item 2</DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

### Bottom Navigation Bar

- Background: `bg-background/95` (#153a21 with 95% opacity)
- Backdrop blur: `backdrop-blur-sm`
- Border-top: `border-t border-border`
- Active icon: `text-primary` (#b5a47d)
- Inactive icon: `text-foreground/60` (muted beige)
- Height: `h-20` (80px) for mobile comfort
- Items: 4 main navigation links (Home, Library, Patterns, Check-in)
```jsx
<nav className="flex-shrink-0 border-t border-border bg-background/95 backdrop-blur-sm">
  <div className="flex h-20 items-center justify-around px-2">
    {navItems.map((item) => (
      <Link href={item.href} className={isActive ? "text-primary" : "text-foreground/60"}>
        <item.icon className="h-5 w-5" />
      </Link>
    ))}
  </div>
</nav>
```

### Headers & Typography

- Page titles: `text-lg font-semibold text-foreground` (#b5a47d, 18px)
- Section headings: `text-base font-semibold text-foreground` (#b5a47d)
- Body text: `text-foreground` (#b5a47d) on dark green background
- Muted text: `text-muted-foreground` (lighter shade, 60% opacity)
- Accent headings: Use `text-primary` (#b5a47d) for emphasis
```jsx
<h1 className="text-lg font-semibold text-foreground">Journal</h1>
<p className="text-sm text-muted-foreground">Optional description</p>
```

### Dialogs & Modals

- Background: `bg-background` (#153a21)
- Text: `text-foreground` (#b5a47d)
- Title: `text-lg font-semibold text-foreground`
- Content padding: `p-4` or `p-6`
- Actions: Use primary/secondary buttons at bottom
```jsx
<Dialog>
  <DialogContent className="bg-background text-foreground">
    <DialogHeader>
      <DialogTitle className="text-foreground">Add New Item</DialogTitle>
    </DialogHeader>
    {/* Content */}
  </DialogContent>
</Dialog>
```

## Layout Patterns

### Screen Structure
```
┌─────────────────────┐
│      Header         │ h-16 (64px) - Back icon | Title | Bell icon
├─────────────────────┤
│                     │
│    Main Content     │ Flex-1 (grows to fill)
│                     │
├─────────────────────┤
│   Bottom Nav (H)    │ h-20 (80px) - Home | Library | Patterns | Check-in
└─────────────────────┘
```

### Content Areas
- Use `flex flex-col` for vertical layouts
- Use `grid` only for 2D layouts (rare)
- Primary method: Flexbox with `gap-x` and `gap-y` for spacing
- Padding: Use `px-4 py-4` for consistency
- Max-width: Full screen on mobile, consider constraints on larger screens

### Responsive Design
- Mobile-first: Design for 320px-480px first
- No breakpoint-specific changes needed for main screens
- All components are responsive via Tailwind defaults
- Bottom nav hides on very small screens, shows on mobile 320px+

## Icon Usage

- Icon size: 
  - Header/Navigation: `h-5 w-5` (20px)
  - Large buttons: `h-6 w-6` (24px)
  - Small buttons: `h-4 w-4` (16px)
- Icon color: Match surrounding text color
- Icon hover: Same as button hover
- Icon active/selected: Use `text-primary` (#b5a47d)

## Spacing Scale (Tailwind)

- `gap-1`: 0.25rem (4px) - tight spacing
- `gap-2`: 0.5rem (8px) - compact spacing
- `gap-3`: 0.75rem (12px) - standard spacing
- `gap-4`: 1rem (16px) - comfortable spacing
- `gap-6`: 1.5rem (24px) - large spacing
- `p-2`: 0.5rem (8px)
- `p-4`: 1rem (16px) - standard padding
- `px-4`: 1rem horizontal padding
- `py-4`: 1rem vertical padding

## Best Practices

1. **Color Consistency**: Always use CSS variables, never hardcode hex values in components
2. **Two-Tone Only**: Maintain the dark green + beige palette exclusively
3. **Button Hierarchy**: Primary buttons for main actions, secondary/outline for alternatives
4. **Accessibility**: Maintain sufficient contrast ratios, use semantic HTML
5. **Focus States**: Always include focus rings using the ring classes
6. **Icon Sizing**: Keep icons consistent with text baseline
7. **Card Usage**: Use cards for content containers, not text-only information
8. **Form Consistency**: All inputs should look similar - border style, focus state, padding
9. **Empty States**: Always show helpful message with icon when no data exists
10. **Dark Theme Ready**: All components already support dark mode through CSS variables

## Implementation Checklist for New Screens

- [ ] Use `bg-background` for page background (dark green)
- [ ] Use `text-foreground` for primary text (beige)
- [ ] All buttons have consistent sizing and variants
- [ ] Form inputs match the input component styling
- [ ] Cards use beige background with dark green text
- [ ] Headers include back icon on left, title in center, bell icon on right
- [ ] Bottom nav hidden on secondary pages, visible on dashboard only
- [ ] All icons are 20px or smaller
- [ ] Focus states visible with ring styling
- [ ] Empty states include helpful message with icon
- [ ] Responsive layout works on mobile 320px+
- [ ] No hardcoded colors - use CSS variables only
