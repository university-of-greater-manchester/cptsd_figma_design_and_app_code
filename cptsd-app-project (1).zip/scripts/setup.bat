@echo off
REM CPTSD Toolkit - Quick Setup Script for Windows
REM This script automates the local setup process

setlocal enabledelayedexpansion

echo.
echo ========================================
echo CPTSD Toolkit - Local Setup Script
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [X] Node.js is not installed. Please install Node.js first.
    echo     Download from: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node --version') do set NODE_VERSION=%%i
echo [OK] Node.js installed: %NODE_VERSION%

REM Check if pnpm is installed
where pnpm >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [*] Installing pnpm...
    call npm install -g pnpm
)

for /f "tokens=*" %%i in ('pnpm --version') do set PNPM_VERSION=%%i
echo [OK] pnpm installed: %PNPM_VERSION%

REM Check if PostgreSQL is installed
where psql >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [X] PostgreSQL is not installed. Please install PostgreSQL first.
    echo     Download from: https://www.postgresql.org/download/windows/
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('psql --version') do set PSQL_VERSION=%%i
echo [OK] PostgreSQL installed: %PSQL_VERSION%

REM Create .env.local if it doesn't exist
if not exist .env.local (
    echo.
    echo [*] Creating .env.local...
    
    REM Generate a random secret (using Node.js)
    for /f "delims=" %%i in ('node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"') do set SECRET=%%i
    
    (
        echo # Database Connection String
        echo DATABASE_URL=postgresql://cptsd_user:cptsd_password@localhost:5432/cptsd_toolkit
        echo.
        echo # Better Auth Secret
        echo BETTER_AUTH_SECRET=%SECRET%
        echo.
        echo # Environment
        echo NODE_ENV=development
    ) > .env.local
    
    echo [OK] Created .env.local with generated BETTER_AUTH_SECRET
) else (
    echo [OK] .env.local already exists
)

REM Install dependencies
echo.
echo [*] Installing dependencies...
call pnpm install

echo.
echo [OK] Dependencies installed successfully

echo.
echo ========================================
echo Setup Complete! [OK]
echo ========================================
echo.
echo Next steps:
echo.
echo 1. Create the database (open Command Prompt and run):
echo    psql -U postgres -d postgres -c "CREATE DATABASE cptsd_toolkit;"
echo    psql -U postgres -d postgres -c "CREATE USER cptsd_user WITH PASSWORD 'cptsd_password';"
echo    psql -U postgres -d postgres -c "GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;"
echo.
echo 2. Setup database tables:
echo    psql -U cptsd_user -d cptsd_toolkit -f scripts\create_public_db.sql
echo.
echo 3. Start the development server:
echo    pnpm dev
echo.
echo 4. Open http://localhost:3000 in your browser
echo.
pause
