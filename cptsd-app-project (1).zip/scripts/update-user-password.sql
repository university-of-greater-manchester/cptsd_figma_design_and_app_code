-- Update password for user kjb8377@hotmail.com
-- Password: KJButt8377@
-- Hashed using bcrypt (Better Auth standard)

UPDATE "user" 
SET "password" = '$2b$10$dbZA/HTPuXip8FQFPC/Z8.6WzTkrz5cmgILGXoc3tcItuA3jM/PFa' 
WHERE "email" = 'kjb8377@hotmail.com';

-- Verify the update
SELECT "id", "email", "password" FROM "user" WHERE "email" = 'kjb8377@hotmail.com';
