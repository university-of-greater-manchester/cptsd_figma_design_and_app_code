-- ============================================================================
-- PUBLIC DATABASE CREATION SCRIPT
-- ============================================================================
-- This script creates the public schema with all application-specific tables
-- for the CPTSD Support application
-- ============================================================================

-- ============================================================================
-- USER TABLE (Application User Info)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.user (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT NOT NULL UNIQUE,
    emailVerified BOOLEAN DEFAULT FALSE,
    image TEXT,
    createdAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_public_user_email ON public.user(email);

-- ============================================================================
-- SESSION TABLE (User Sessions)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.session (
    id TEXT PRIMARY KEY,
    token TEXT NOT NULL UNIQUE,
    userId TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    expiresAt TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    ipAddress TEXT,
    userAgent TEXT,
    createdAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for session lookups
CREATE INDEX IF NOT EXISTS idx_public_session_token ON public.session(token);
CREATE INDEX IF NOT EXISTS idx_public_session_user_id ON public.session(userId);

-- ============================================================================
-- ACCOUNT TABLE (OAuth/Provider Integration)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.account (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    accountId TEXT NOT NULL,
    providerId TEXT NOT NULL,
    accessToken TEXT,
    refreshToken TEXT,
    idToken TEXT,
    accessTokenExpiresAt TIMESTAMP WITHOUT TIME ZONE,
    refreshTokenExpiresAt TIMESTAMP WITHOUT TIME ZONE,
    scope TEXT,
    password TEXT,
    createdAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for account lookups
CREATE INDEX IF NOT EXISTS idx_public_account_user_id ON public.account(userId);
CREATE INDEX IF NOT EXISTS idx_public_account_provider ON public.account(providerId, accountId);

-- ============================================================================
-- USER_PROFILE TABLE (Extended User Information)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.user_profile (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL UNIQUE REFERENCES public.user(id) ON DELETE CASCADE,
    display_name TEXT,
    bio TEXT,
    avatar_url TEXT,
    theme TEXT,
    notifications_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on user_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_public_user_profile_user_id ON public.user_profile(user_id);

-- ============================================================================
-- USER_SETTINGS TABLE (User Preferences)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.user_settings (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL UNIQUE REFERENCES public.user(id) ON DELETE CASCADE,
    theme TEXT,
    language TEXT,
    daily_reminder_time TEXT,
    push_notifications_enabled BOOLEAN DEFAULT TRUE,
    ai_engagement_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on user_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_public_user_settings_user_id ON public.user_settings(user_id);

-- ============================================================================
-- DAILY_CHECK_IN TABLE (Version 1 - Legacy)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.daily_check_in (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    mood_score INTEGER CHECK (mood_score >= 1 AND mood_score <= 10),
    anxiety_level INTEGER CHECK (anxiety_level >= 1 AND anxiety_level <= 10),
    energy_level INTEGER CHECK (energy_level >= 1 AND energy_level <= 10),
    sleep_hours NUMERIC(4, 2),
    notes TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for check-in lookups
CREATE INDEX IF NOT EXISTS idx_public_daily_check_in_user_id ON public.daily_check_in(user_id);
CREATE INDEX IF NOT EXISTS idx_public_daily_check_in_date ON public.daily_check_in(date);
CREATE INDEX IF NOT EXISTS idx_public_daily_check_in_user_date ON public.daily_check_in(user_id, date);

-- ============================================================================
-- DAILY_CHECKIN_V2 TABLE (Version 2 - Current)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.daily_checkin_v2 (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    mood_state TEXT,
    nervous_system_state TEXT,
    capacity_level INTEGER CHECK (capacity_level >= 1 AND capacity_level <= 10),
    connection_level INTEGER CHECK (connection_level >= 1 AND connection_level <= 10),
    sleep_hours NUMERIC(4, 2),
    notes TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for check-in lookups
CREATE INDEX IF NOT EXISTS idx_public_daily_checkin_v2_user_id ON public.daily_checkin_v2(user_id);
CREATE INDEX IF NOT EXISTS idx_public_daily_checkin_v2_date ON public.daily_checkin_v2(date);
CREATE INDEX IF NOT EXISTS idx_public_daily_checkin_v2_user_date ON public.daily_checkin_v2(user_id, date);

-- ============================================================================
-- GROUNDING_FAVORITE TABLE (User's Favorite Exercises)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.grounding_favorite (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    exercise_name TEXT NOT NULL,
    category TEXT,
    exercise_description TEXT,
    order_index INTEGER,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for favorites lookup
CREATE INDEX IF NOT EXISTS idx_public_grounding_favorite_user_id ON public.grounding_favorite(user_id);
CREATE INDEX IF NOT EXISTS idx_public_grounding_favorite_user_exercise ON public.grounding_favorite(user_id, exercise_name);

-- ============================================================================
-- GROUNDING_EXERCISE TABLE (Completed Grounding Exercises)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.grounding_exercise (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    exercise_type TEXT NOT NULL,
    duration_seconds INTEGER,
    effectiveness_rating INTEGER CHECK (effectiveness_rating >= 1 AND effectiveness_rating <= 5),
    notes TEXT,
    completed_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for exercise lookup
CREATE INDEX IF NOT EXISTS idx_public_grounding_exercise_user_id ON public.grounding_exercise(user_id);
CREATE INDEX IF NOT EXISTS idx_public_grounding_exercise_type ON public.grounding_exercise(exercise_type);
CREATE INDEX IF NOT EXISTS idx_public_grounding_exercise_date ON public.grounding_exercise(completed_at);

-- ============================================================================
-- JOURNAL_ENTRY TABLE (User Journal Entries)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.journal_entry (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT,
    mood TEXT,
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for journal lookup
CREATE INDEX IF NOT EXISTS idx_public_journal_entry_user_id ON public.journal_entry(user_id);
CREATE INDEX IF NOT EXISTS idx_public_journal_entry_date ON public.journal_entry(created_at);
CREATE INDEX IF NOT EXISTS idx_public_journal_entry_tags ON public.journal_entry USING GIN(tags);

-- ============================================================================
-- WORKSHEET TABLE (User Worksheets/Exercises)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.worksheet (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    content TEXT,
    answers TEXT,
    is_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for worksheet lookup
CREATE INDEX IF NOT EXISTS idx_public_worksheet_user_id ON public.worksheet(user_id);
CREATE INDEX IF NOT EXISTS idx_public_worksheet_completed ON public.worksheet(is_completed);

-- ============================================================================
-- COPING_STRATEGY TABLE (User Coping Strategies)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.coping_strategy (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    is_favorite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for coping strategy lookup
CREATE INDEX IF NOT EXISTS idx_public_coping_strategy_user_id ON public.coping_strategy(user_id);
CREATE INDEX IF NOT EXISTS idx_public_coping_strategy_category ON public.coping_strategy(category);

-- ============================================================================
-- TRIGGER_TRACKER TABLE (PTSD Trigger Tracking)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.trigger_tracker (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    trigger_description TEXT NOT NULL,
    intensity INTEGER CHECK (intensity >= 1 AND intensity <= 10),
    response TEXT,
    location TEXT,
    time_of_day TEXT,
    support_used TEXT,
    notes TEXT,
    tracked_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for trigger lookup
CREATE INDEX IF NOT EXISTS idx_public_trigger_tracker_user_id ON public.trigger_tracker(user_id);
CREATE INDEX IF NOT EXISTS idx_public_trigger_tracker_date ON public.trigger_tracker(tracked_at);

-- ============================================================================
-- SAFETY_PLAN_ITEMS TABLE (Crisis Safety Plans)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.safety_plan_items (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    category TEXT NOT NULL,
    content TEXT NOT NULL,
    priority INTEGER,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for safety plan lookup
CREATE INDEX IF NOT EXISTS idx_public_safety_plan_items_user_id ON public.safety_plan_items(user_id);
CREATE INDEX IF NOT EXISTS idx_public_safety_plan_items_category ON public.safety_plan_items(category);

-- ============================================================================
-- SUPPORT_CONTACT TABLE (Crisis Support Contacts)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.support_contact (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    role TEXT,
    email TEXT,
    phone TEXT,
    availability TEXT,
    is_crisis_contact BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for support contact lookup
CREATE INDEX IF NOT EXISTS idx_public_support_contact_user_id ON public.support_contact(user_id);
CREATE INDEX IF NOT EXISTS idx_public_support_contact_crisis ON public.support_contact(is_crisis_contact);

-- ============================================================================
-- LIBRARY_SECTION TABLE (Resource Library Sections)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.library_section (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    icon TEXT,
    "order" INTEGER,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- ROLE TABLE (Authorization Roles)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.role (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    level INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- PERMISSION TABLE (Authorization Permissions)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.permission (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    resource TEXT NOT NULL,
    action TEXT NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- USER_ROLE TABLE (User Role Assignments)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.user_role (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT NOT NULL REFERENCES public.user(id) ON DELETE CASCADE,
    role_id INTEGER NOT NULL REFERENCES public.role(id) ON DELETE CASCADE,
    granted_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    granted_by TEXT
);

-- Create indexes for user role lookup
CREATE INDEX IF NOT EXISTS idx_public_user_role_user_id ON public.user_role(user_id);
CREATE INDEX IF NOT EXISTS idx_public_user_role_role_id ON public.user_role(role_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_public_user_role_user_role ON public.user_role(user_id, role_id);

-- ============================================================================
-- AUDIT_LOG TABLE (Application Audit Trail)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.audit_log (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id TEXT REFERENCES public.user(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    resource TEXT NOT NULL,
    resource_id TEXT,
    role TEXT,
    ip_address TEXT,
    user_agent TEXT,
    details TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for audit log lookup
CREATE INDEX IF NOT EXISTS idx_public_audit_log_user_id ON public.audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_public_audit_log_action ON public.audit_log(action);
CREATE INDEX IF NOT EXISTS idx_public_audit_log_date ON public.audit_log(created_at);

-- ============================================================================
-- END OF PUBLIC DATABASE SCRIPT
-- ============================================================================
