#!/bin/bash
# CPTSD Toolkit - Quick Setup Script for macOS/Linux
# This script automates the local setup process

set -e

echo "========================================"
echo "CPTSD Toolkit - Local Setup Script"
echo "========================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "   Download from: https://nodejs.org/"
    exit 1
fi

echo "✓ Node.js installed: $(node --version)"

# Check if pnpm is installed
if ! command -v pnpm &> /dev/null; then
    echo "📦 Installing pnpm..."
    npm install -g pnpm
fi

echo "✓ pnpm installed: $(pnpm --version)"

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL is not installed. Please install PostgreSQL first."
    echo "   macOS: brew install postgresql@15"
    echo "   Linux: sudo apt-get install postgresql"
    exit 1
fi

echo "✓ PostgreSQL installed: $(psql --version)"

# Check if PostgreSQL is running
if ! pg_isready -h localhost &> /dev/null; then
    echo "⚠️  PostgreSQL is not running. Starting PostgreSQL..."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew services start postgresql@15 || true
    else
        sudo service postgresql start || true
    fi
    sleep 2
fi

echo "✓ PostgreSQL is running"

# Create .env.local if it doesn't exist
if [ ! -f .env.local ]; then
    echo "📝 Creating .env.local..."
    
    # Generate BETTER_AUTH_SECRET
    SECRET=$(openssl rand -base64 32)
    
    cat > .env.local << EOF
# Database Connection String
DATABASE_URL=postgresql://cptsd_user:cptsd_password@localhost:5432/cptsd_toolkit

# Better Auth Secret
BETTER_AUTH_SECRET=$SECRET

# Environment
NODE_ENV=development
EOF
    
    echo "✓ Created .env.local with generated BETTER_AUTH_SECRET"
else
    echo "✓ .env.local already exists"
fi

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pnpm install

echo ""
echo "✓ Dependencies installed successfully"

echo ""
echo "========================================"
echo "Setup Complete! ✓"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Create the database (run this in a new terminal):"
echo "   psql -U postgres -d postgres -c \"CREATE DATABASE cptsd_toolkit;\""
echo "   psql -U postgres -d postgres -c \"CREATE USER cptsd_user WITH PASSWORD 'cptsd_password';\""
echo "   psql -U postgres -d postgres -c \"GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;\""
echo ""
echo "2. Setup database tables:"
echo "   psql -U cptsd_user -d cptsd_toolkit -f scripts/create_public_db.sql"
echo ""
echo "3. Start the development server:"
echo "   pnpm dev"
echo ""
echo "4. Open http://localhost:3000 in your browser"
echo ""
