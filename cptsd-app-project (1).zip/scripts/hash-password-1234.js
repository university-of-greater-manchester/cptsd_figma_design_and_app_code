const bcrypt = require('bcrypt');

const password = '1234';
const saltRounds = 10;

bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
  if (err) {
    console.error('Error hashing password:', err);
    process.exit(1);
  }
  
  console.log('Password: 1234');
  console.log('Hashed Password:', hashedPassword);
  console.log('\nSQL Update Statement:');
  console.log(`UPDATE "user" SET "password" = '${hashedPassword}' WHERE "email" = 'kjb8377@hotmail.com';`);
});
