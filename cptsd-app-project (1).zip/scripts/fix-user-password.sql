-- Update password in both public and neon_auth schemas
-- This fixes the "invalid email or password" error by ensuring the password is set in the correct table

-- First, check which user exists in neon_auth (this is the one Better Auth uses by default)
SELECT id, email, password FROM neon_auth."user" WHERE email = 'kjb8377@hotmail.com';

-- Update the password in neon_auth schema (this is the primary auth table)
UPDATE neon_auth."user" 
SET "password" = '$2b$10$1zo//rVS0xWvbtMiQl0ZQeXEY6.om0KWlUwf4Apx6jUwvMxCQ2NlC' 
WHERE "email" = 'kjb8377@hotmail.com';

-- Verify the update
SELECT id, email, password FROM neon_auth."user" WHERE email = 'kjb8377@hotmail.com';
