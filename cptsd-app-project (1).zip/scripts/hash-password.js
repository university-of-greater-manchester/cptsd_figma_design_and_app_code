const bcrypt = require('bcrypt');

const password = "KJButt8377@";

// Hash the password using bcrypt (same as Better Auth)
bcrypt.hash(password, 10, (err, hash) => {
  if (err) {
    console.error("Error hashing password:", err);
    process.exit(1);
  }
  
  console.log("=== PASSWORD HASH ===");
  console.log("Original Password:", password);
  console.log("Hashed Password:", hash);
  console.log("");
  console.log("=== SQL UPDATE STATEMENT ===");
  console.log(`UPDATE "user" SET "password" = '${hash}' WHERE "email" = 'kjb8377@hotmail.com';`);
  console.log("");
  console.log("Copy the SQL statement above and execute it in your Neon database console.");
});
