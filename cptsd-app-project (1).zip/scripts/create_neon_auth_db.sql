-- ============================================================================
-- NEON_AUTH DATABASE CREATION SCRIPT
-- ============================================================================
-- This script creates the neon_auth schema and all authentication-related tables
-- Required for Better Auth integration with the CPTSD Support application
-- ============================================================================

-- Create schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS neon_auth;

-- ============================================================================
-- USER TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.user (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT,
    email TEXT NOT NULL UNIQUE,
    emailVerified BOOLEAN DEFAULT FALSE,
    image TEXT,
    role TEXT,
    banned BOOLEAN DEFAULT FALSE,
    banReason TEXT,
    banExpires TIMESTAMP WITH TIME ZONE,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_user_email ON neon_auth.user(email);

-- ============================================================================
-- SESSION TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.session (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT NOT NULL UNIQUE,
    userId UUID NOT NULL REFERENCES neon_auth.user(id) ON DELETE CASCADE,
    expiresAt TIMESTAMP WITH TIME ZONE NOT NULL,
    ipAddress TEXT,
    userAgent TEXT,
    activeOrganizationId TEXT,
    impersonatedBy TEXT,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for session lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_session_token ON neon_auth.session(token);
CREATE INDEX IF NOT EXISTS idx_neon_auth_session_user_id ON neon_auth.session(userId);
CREATE INDEX IF NOT EXISTS idx_neon_auth_session_expires_at ON neon_auth.session(expiresAt);

-- ============================================================================
-- ACCOUNT TABLE (OAuth/Provider Integration)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.account (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    userId UUID NOT NULL REFERENCES neon_auth.user(id) ON DELETE CASCADE,
    accountId TEXT NOT NULL,
    providerId TEXT NOT NULL,
    accessToken TEXT,
    refreshToken TEXT,
    idToken TEXT,
    accessTokenExpiresAt TIMESTAMP WITH TIME ZONE,
    refreshTokenExpiresAt TIMESTAMP WITH TIME ZONE,
    scope TEXT,
    password TEXT,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for account lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_account_user_id ON neon_auth.account(userId);
CREATE INDEX IF NOT EXISTS idx_neon_auth_account_provider ON neon_auth.account(providerId, accountId);

-- ============================================================================
-- VERIFICATION TABLE (Email/SMS Verification Tokens)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.verification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identifier TEXT NOT NULL,
    value TEXT NOT NULL,
    expiresAt TIMESTAMP WITH TIME ZONE NOT NULL,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index for verification lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_verification_identifier ON neon_auth.verification(identifier);
CREATE INDEX IF NOT EXISTS idx_neon_auth_verification_expires_at ON neon_auth.verification(expiresAt);

-- ============================================================================
-- ORGANIZATION TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.organization (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    logo TEXT,
    metadata TEXT,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on slug for faster lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_organization_slug ON neon_auth.organization(slug);

-- ============================================================================
-- MEMBER TABLE (Organization Members)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.member (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organizationId UUID NOT NULL REFERENCES neon_auth.organization(id) ON DELETE CASCADE,
    userId UUID NOT NULL REFERENCES neon_auth.user(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for member lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_member_org_id ON neon_auth.member(organizationId);
CREATE INDEX IF NOT EXISTS idx_neon_auth_member_user_id ON neon_auth.member(userId);
CREATE INDEX IF NOT EXISTS idx_neon_auth_member_org_user ON neon_auth.member(organizationId, userId);

-- ============================================================================
-- INVITATION TABLE (Organization Invitations)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.invitation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organizationId UUID NOT NULL REFERENCES neon_auth.organization(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    inviterId UUID NOT NULL REFERENCES neon_auth.user(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    expiresAt TIMESTAMP WITH TIME ZONE NOT NULL,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for invitation lookups
CREATE INDEX IF NOT EXISTS idx_neon_auth_invitation_org_id ON neon_auth.invitation(organizationId);
CREATE INDEX IF NOT EXISTS idx_neon_auth_invitation_email ON neon_auth.invitation(email);
CREATE INDEX IF NOT EXISTS idx_neon_auth_invitation_expires_at ON neon_auth.invitation(expiresAt);

-- ============================================================================
-- JWKS TABLE (JSON Web Key Sets for Token Signing)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.jwks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    publicKey TEXT NOT NULL,
    privateKey TEXT NOT NULL,
    expiresAt TIMESTAMP WITH TIME ZONE NOT NULL,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on expiration for key rotation
CREATE INDEX IF NOT EXISTS idx_neon_auth_jwks_expires_at ON neon_auth.jwks(expiresAt);

-- ============================================================================
-- PROJECT_CONFIG TABLE (Better Auth Configuration)
-- ============================================================================
CREATE TABLE IF NOT EXISTS neon_auth.project_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    endpoint_id TEXT,
    email_and_password JSONB,
    social_providers JSONB,
    email_provider JSONB,
    plugin_configs JSONB,
    webhook_config JSONB,
    trusted_origins JSONB,
    allow_localhost BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- END OF NEON_AUTH DATABASE SCRIPT
-- ============================================================================
