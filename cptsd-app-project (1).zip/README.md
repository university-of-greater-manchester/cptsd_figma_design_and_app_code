# CPTSD Toolkit

A comprehensive mental health support application designed specifically for individuals managing Complex Post-Traumatic Stress Disorder (CPTSD). The toolkit provides evidence-based grounding techniques, journaling capabilities, and personalized coping strategies.

## 🎯 Features

### Authentication & User Management
- ✅ Email + Password authentication with Better Auth
- ✅ Secure password hashing using bcrypt
- ✅ Password reset functionality via email links
- ✅ Session management with 7-day expiration
- ✅ User profiles with personalized settings

### Grounding Exercises
- 🫁 **Box Breathing** - Controlled breathing technique for immediate calming
- 🔢 **5-4-3-2-1 Grounding** - Sensory awareness exercise
- 🧘 **Body Scan** - Progressive relaxation and body awareness
- 🤍 **Self-Compassion** - Mindfulness-based self-compassion practice
- 🎵 **Sound Awareness** - Auditory grounding and focus technique

### Core Features
- 📝 **Daily Check-in** - Track mental health status and mood throughout the day
- 📔 **Journal** - Private journaling with timestamps and mood tracking
- 🛡️ **Coping Strategies** - Build and manage personalized coping techniques
- 📊 **Pattern Awareness** - Identify triggers and recognize patterns
- 📚 **Resource Library** - Access to mental health resources and reading materials
- 🆘 **Safety Planning** - Create crisis plans and emergency contacts
- 📞 **Support Contacts** - Store and quickly access support resources

### User Experience
- 📱 Mobile-first responsive design
- 🌙 Theme-aware interface matching CPTSD-friendly aesthetic
- 🧭 Intuitive navigation with quick-access bottom bar
- ♿ Accessible UI following WCAG guidelines
- ⚡ Fast loading with Next.js 16 optimization

## 🏗️ Tech Stack

### Frontend
- **Framework**: Next.js 16 with App Router
- **UI Library**: React 19
- **Styling**: Tailwind CSS 4 with custom theme
- **Components**: shadcn/ui components with Radix UI
- **Charts**: Recharts for data visualization

### Backend
- **Runtime**: Node.js
- **Authentication**: Better Auth
- **ORM**: Drizzle ORM
- **Database**: PostgreSQL 12+
- **Server Actions**: Next.js Server Actions for secure backend operations

### Infrastructure
- **Package Manager**: pnpm
- **Database Driver**: pg (node-postgres)
- **Utilities**: Lucide React (icons), Sonner (notifications)

## 📋 Prerequisites

### System Requirements
- **Node.js**: v18.0.0 or higher
- **npm/pnpm**: Latest version
- **PostgreSQL**: v12 or higher
- **RAM**: 2GB minimum
- **Storage**: 500MB for installation

### Required Software
- Git (for version control)
- A code editor (VS Code, Sublime, etc.)
- PostgreSQL client (psql or GUI like DBeaver)

## 🚀 Quick Start

### 1. Clone Repository
```bash
git clone <repository-url> cptsd-toolkit
cd cptsd-toolkit
```

### 2. Install Dependencies
```bash
pnpm install
```

### 3. Setup Database
```bash
# Create PostgreSQL database
psql -U postgres

# In psql prompt:
CREATE DATABASE cptsd_toolkit;
CREATE USER cptsd_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;
\q

# Run migrations
psql -U cptsd_user -d cptsd_toolkit -f scripts/create_public_db.sql
```

### 4. Configure Environment
Create `.env.local` in the project root:
```bash
DATABASE_URL=postgresql://cptsd_user:secure_password@localhost:5432/cptsd_toolkit
BETTER_AUTH_SECRET=your_generated_secret_key
NODE_ENV=development
```

Generate `BETTER_AUTH_SECRET`:
```bash
# macOS/Linux
openssl rand -base64 32

# Windows (PowerShell)
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

### 5. Run Development Server
```bash
pnpm dev
```

Visit http://localhost:3000 to access the application.

## 📁 Project Structure

```
cptsd-toolkit/
├── app/                          # Next.js app directory
│   ├── api/auth/                # Better Auth endpoints
│   ├── sign-in/                 # Sign-in page
│   ├── sign-up/                 # Sign-up page
│   ├── forgot-password/         # Password recovery
│   ├── reset-password/          # Reset password page
│   ├── dashboard/               # Main dashboard
│   ├── grounding/               # Grounding exercises
│   ├── journal/                 # Journal functionality
│   ├── profile/                 # User profile
│   ├── coping-strategies/       # Coping strategies
│   ├── check-in/                # Daily check-in
│   ├── pattern-tracking/        # Pattern awareness
│   ├── library/                 # Resources library
│   ├── safety-plan/             # Safety planning
│   ├── actions/                 # Server actions
│   ├── layout.tsx               # Root layout
│   └── page.tsx                 # Landing page
├── components/                   # Reusable React components
│   ├── auth-form.tsx            # Login/signup form
│   ├── layout-wrapper.tsx       # App wrapper
│   ├── bottom-nav-bar.tsx       # Navigation bar
│   ├── side-menu.tsx            # Side navigation
│   └── ui/                      # shadcn components
├── lib/                          # Utility functions
│   ├── auth.ts                  # Better Auth config
│   ├── auth-client.ts           # Auth client setup
│   ├── utils.ts                 # Helper functions
│   └── db/
│       ├── index.ts             # Drizzle setup
│       └── schema.ts            # Database schema
├── public/                       # Static assets
├── scripts/                      # Utility scripts
│   ├── create_public_db.sql     # Database setup
│   ├── setup.sh                 # macOS/Linux setup
│   └── setup.bat                # Windows setup
├── docs/
│   ├── LOCAL_DEPLOYMENT_GUIDE.md # Deployment guide
│   └── PASSWORD_RESET.md        # Password reset docs
├── .env.local                   # Environment variables (gitignored)
├── package.json                 # Dependencies
├── tsconfig.json                # TypeScript config
├── next.config.mjs              # Next.js config
└── README.md                    # This file
```

## 🗄️ Database Schema

### Authentication Tables (Better Auth)
- **user**: User accounts and profiles
- **session**: Active user sessions
- **account**: OAuth and credential providers
- **verification**: Email verification tokens

### Application Tables
- **daily_check_in**: Mental health check-ins
- **grounding_exercise**: Grounding session logs
- **journal_entry**: Journal entries
- **coping_strategy**: User's coping techniques
- **trigger_tracker**: PTSD trigger documentation
- **safety_plan_items**: Crisis planning items
- **support_contact**: Emergency contacts

### Authorization Tables
- **role**: User roles (admin, user, therapist)
- **permission**: System permissions
- **user_role**: User role assignments
- **role_permission**: Role-permission mappings

## 🔐 Security Features

- ✅ Passwords hashed with bcrypt (10 rounds)
- ✅ Session tokens with 7-day expiration
- ✅ CSRF protection with origin validation
- ✅ SQL injection prevention with parameterized queries
- ✅ Environment variable management for secrets
- ✅ HTTPS support in production
- ✅ Secure cookie attributes (sameSite, secure flags)
- ✅ Input validation and sanitization

## 📱 Responsive Design

The app is fully responsive and tested on:
- 📱 Mobile devices (320px - 480px)
- 📱 Tablets (480px - 768px)
- 💻 Desktops (768px+)
- 🖥️ Large screens (1920px+)

## 🧪 Testing

### Manual Testing
1. Sign up with a new account
2. Complete daily check-in
3. Try all grounding exercises
4. Test password reset flow
5. Verify journal entry creation
6. Test navigation on mobile

### Debugging
The app uses `console.log("[v0] ...")` for debugging. Check browser console for messages.

## 📦 Available Scripts

```bash
# Development
pnpm dev              # Start development server (http://localhost:3000)
pnpm build            # Create production build
pnpm start            # Run production server
pnpm lint             # Check code style with ESLint

# Database
psql -U postgres      # Connect to PostgreSQL
```

## 🚢 Deployment

### Deploy to Vercel (Recommended)

1. Push to GitHub repository
2. Connect GitHub to Vercel
3. Set environment variables in Vercel dashboard:
   - `DATABASE_URL`
   - `BETTER_AUTH_SECRET`
4. Deploy with one click

### Deploy to Other Platforms

See `docs/LOCAL_DEPLOYMENT_GUIDE.md` for detailed platform-specific instructions.

## 🐛 Troubleshooting

### Issue: Database connection fails
**Solution**: Verify PostgreSQL is running and credentials are correct
```bash
psql -U cptsd_user -d cptsd_toolkit -h localhost
```

### Issue: Port 3000 already in use
**Solution**: Kill process on port 3000 or use a different port
```bash
# macOS/Linux
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Issue: Dependencies installation fails
**Solution**: Clear cache and reinstall
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Issue: BETTER_AUTH_SECRET missing error
**Solution**: Generate and add to .env.local
```bash
# Generate secret
openssl rand -base64 32

# Add to .env.local
BETTER_AUTH_SECRET=<generated_secret>
```

## 📖 Documentation

- 📘 [Local Deployment Guide](docs/LOCAL_DEPLOYMENT_GUIDE.md) - Step-by-step local setup
- 🔐 [Password Reset Documentation](docs/PASSWORD_RESET.md) - Password reset flow details
- 📊 [Database Schema](scripts/create_public_db.sql) - Database structure
- 🔌 [Environment Variables](docs/ENV_VARIABLES.md) - Configuration reference

## 🤝 Contributing

To contribute to this project:

1. Create a feature branch: `git checkout -b feature/your-feature`
2. Commit changes: `git commit -m "Add your feature"`
3. Push to branch: `git push origin feature/your-feature`
4. Create a Pull Request

## 📝 License

This project is licensed under the MIT License - see LICENSE file for details.

## 🆘 Support

If you encounter issues:

1. Check the [Troubleshooting](#-troubleshooting) section
2. Review [Local Deployment Guide](docs/LOCAL_DEPLOYMENT_GUIDE.md)
3. Check existing GitHub issues
4. Create a new issue with detailed information

## 🙏 Acknowledgments

- Better Auth for authentication framework
- Next.js team for the React framework
- Tailwind CSS for utility-first styling
- PostgreSQL community for the database
- All contributors and supporters

## 📞 Contact

For questions or support:
- 📧 Email: support@cptsd-toolkit.com
- 🐦 Twitter: @cptsdtoolkit
- 💬 Discord: [Join our community](https://discord.gg/cptsd-toolkit)

---

**Last Updated**: June 11, 2026  
**Version**: 1.0.0  
**Status**: ✅ Production Ready
