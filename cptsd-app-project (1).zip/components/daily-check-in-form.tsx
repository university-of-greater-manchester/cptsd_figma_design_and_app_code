"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Smile, Meh, Frown, Angry, Heart } from "lucide-react"
import { cn } from "@/lib/utils"

interface DailyCheckInFormProps {
  onSubmit: (data: {
    moodScore: number
    energyLevel: number
    anxietyLevel: number
    sleepQuality: number
    notes: string
    triggers: string
  }) => Promise<void>
  isLoading?: boolean
}

const moodOptions = [
  { value: 1, icon: Angry, label: "Very Bad", color: "text-red-500" },
  { value: 2, icon: Frown, label: "Bad", color: "text-orange-500" },
  { value: 3, icon: Meh, label: "Okay", color: "text-yellow-500" },
  { value: 4, icon: Smile, label: "Good", color: "text-green-500" },
  { value: 5, icon: Heart, label: "Great", color: "text-primary" },
]

export function DailyCheckInForm({ onSubmit, isLoading }: DailyCheckInFormProps) {
  const [moodScore, setMoodScore] = useState(3)
  const [energyLevel, setEnergyLevel] = useState(3)
  const [anxietyLevel, setAnxietyLevel] = useState(3)
  const [sleepQuality, setSleepQuality] = useState(3)
  const [notes, setNotes] = useState("")
  const [triggers, setTriggers] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit({
      moodScore,
      energyLevel,
      anxietyLevel,
      sleepQuality,
      notes,
      triggers,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-2 py-2">
      {/* Mood Selection */}
      <div className="flex gap-4 items-start">
        <p className="text-sm font-semibold text-foreground min-w-fit pt-1">Mood</p>
        <div className="flex gap-1">
          {moodOptions.map((mood) => (
            <button
              key={mood.value}
              type="button"
              onClick={() => setMoodScore(mood.value)}
              className={cn(
                "flex flex-col items-center gap-0.5 p-1 rounded-lg transition-all",
                moodScore === mood.value
                  ? "ring-2 ring-primary bg-primary/5"
                  : "hover:bg-foreground/5"
              )}
              title={mood.label}
            >
              <mood.icon
                className={cn(
                  "h-5 w-5 transition-colors",
                  moodScore === mood.value ? mood.color : "text-foreground/40"
                )}
              />
            </button>
          ))}
        </div>
      </div>

      {/* Energy Level */}
      <div className="flex gap-4 items-center">
        <p className="text-sm font-semibold text-foreground min-w-fit">Energy</p>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setEnergyLevel(level)}
              className={cn(
                "h-7 w-7 rounded-full text-xs font-semibold transition-all",
                energyLevel === level
                  ? "bg-primary text-white ring-2 ring-primary/50"
                  : "bg-foreground/10 text-foreground hover:bg-foreground/20"
              )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Anxiety Level */}
      <div className="flex gap-4 items-center">
        <p className="text-sm font-semibold text-foreground min-w-fit">Anxiety</p>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setAnxietyLevel(level)}
              className={cn(
                "h-7 w-7 rounded-full text-xs font-semibold transition-all",
                anxietyLevel === level
                  ? "bg-primary text-white ring-2 ring-primary/50"
                  : "bg-foreground/10 text-foreground hover:bg-foreground/20"
              )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Sleep Quality */}
      <div className="flex gap-4 items-center">
        <p className="text-sm font-semibold text-foreground min-w-fit">Sleep</p>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setSleepQuality(level)}
              className={cn(
                "h-7 w-7 rounded-full text-xs font-semibold transition-all",
                sleepQuality === level
                  ? "bg-primary text-white ring-2 ring-primary/50"
                  : "bg-foreground/10 text-foreground hover:bg-foreground/20"
              )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Triggers */}
      <div className="pt-1">
        <label htmlFor="triggers" className="text-sm font-semibold text-foreground block mb-1">
          Triggers
        </label>
        <Textarea
          id="triggers"
          placeholder="What triggered you today?"
          value={triggers}
          onChange={(e) => setTriggers(e.target.value)}
          className="min-h-14 resize-none text-sm"
        />
      </div>

      {/* Notes */}
      <div className="pt-1">
        <label htmlFor="notes" className="text-sm font-semibold text-foreground block mb-1">
          Notes
        </label>
        <Textarea
          id="notes"
          placeholder="How was your day?"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="min-h-14 resize-none text-sm"
        />
      </div>

      <Button
        type="submit"
        disabled={isLoading}
        className="h-11 w-full text-base font-semibold mt-4"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          "Complete Check-in"
        )}
      </Button>
    </form>
  )
}
