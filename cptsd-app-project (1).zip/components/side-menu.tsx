"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { authClient } from "@/lib/auth-client"
import {
  Home,
  User,
  Settings,
  HelpCircle,
  LogOut,
} from "lucide-react"

interface SideMenuProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  userName?: string
  userImage?: string | null
}

const menuItems = [
  { href: "/dashboard", icon: Home, label: "Home" },
  { href: "/profile", icon: User, label: "Profile" },
  { href: "/settings", icon: Settings, label: "Settings" },
  { href: "/help", icon: HelpCircle, label: "Help & Support" },
]

export function SideMenu({ open, onOpenChange, userName = "User", userImage }: SideMenuProps) {
  const router = useRouter()
  const [isLoggingOut, setIsLoggingOut] = useState(false)

  const handleSignOut = async () => {
    setIsLoggingOut(true)
    await authClient.signOut()
    router.push("/sign-in")
    router.refresh()
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-72 p-0 bg-background" showCloseButton={false}>
        <SheetHeader className="border-b border-border bg-primary/20 p-6">
          <div className="flex items-center gap-3">
            {userImage ? (
              <img
                src={userImage}
                alt={userName}
                className="h-12 w-12 rounded-full object-cover flex-shrink-0"
              />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary flex-shrink-0">
                <User className="h-6 w-6 text-primary-foreground" />
              </div>
            )}
            <div>
              <SheetTitle className="text-left text-base font-semibold text-foreground">{userName}</SheetTitle>
              <Link
                href="/profile"
                onClick={() => onOpenChange(false)}
                className="text-sm text-foreground/60 hover:text-primary transition-colors cursor-pointer"
              >
                View Profile
              </Link>
            </div>
          </div>
        </SheetHeader>

        <nav className="flex flex-col gap-1 p-4">
          {menuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => onOpenChange(false)}
              className="flex items-center gap-3 rounded-xl px-4 py-3 text-foreground transition-colors hover:bg-foreground/10"
            >
              <item.icon className="h-5 w-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          ))}
          <button
            onClick={handleSignOut}
            disabled={isLoggingOut}
            className="flex items-center gap-3 rounded-xl px-4 py-3 text-foreground transition-colors hover:bg-foreground/10 disabled:opacity-50 w-full text-left"
          >
            <LogOut className="h-5 w-5" />
            <span className="text-sm font-medium">{isLoggingOut ? "Signing out..." : "Sign Out"}</span>
          </button>
        </nav>
      </SheetContent>
    </Sheet>
  )
}
