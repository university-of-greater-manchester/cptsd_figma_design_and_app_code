'use client'

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, LucideIcon } from 'lucide-react'

interface BackButtonProps {
  fallbackRoute?: string
  icon?: LucideIcon
}

export function BackButton({ fallbackRoute = '/dashboard', icon: Icon }: BackButtonProps) {
  const router = useRouter()

  const handleBack = () => {
    // Check if we can go back
    if (typeof window !== 'undefined' && window.history.length > 1) {
      // Use native browser back
      window.history.back()
    } else {
      // Fallback to specified route
      router.push(fallbackRoute)
    }
  }

  return (
    <div className="flex items-center gap-3">
      <Button
        variant="ghost"
        size="icon"
        onClick={handleBack}
        className="h-10 w-10 text-foreground hover:text-primary hover:bg-primary/10 transition-colors duration-200 active:bg-primary/20"
      >
        <ArrowLeft className="h-5 w-5" />
      </Button>
      {Icon && <Icon className="h-5 w-5 text-primary" />}
    </div>
  )
}
