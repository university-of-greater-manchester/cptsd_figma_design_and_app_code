'use client'

import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { BottomNavBar } from '@/components/bottom-nav-bar'

export function LayoutWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  
  useEffect(() => {
    setMounted(true)
  }, [])
  
  // Hide nav on public/auth pages
  const isPublicPage = 
    pathname === '/' ||
    pathname === '/sign-in' || 
    pathname === '/sign-up' ||
    pathname === '/forgot-password' ||
    pathname === '/reset-password'
  
  // Show bottom nav on authenticated pages only
  const showBottomNav = !isPublicPage
  
  return (
    <div className="flex flex-col h-screen w-full overflow-hidden">
      {children}
      {mounted && showBottomNav && <BottomNavBar />}
    </div>
  )
}
