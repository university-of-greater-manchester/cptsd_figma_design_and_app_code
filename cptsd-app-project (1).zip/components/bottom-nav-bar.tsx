"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useRef } from "react"
import { 
  Home, 
  CheckCircle, 
  Heart, 
  Shield, 
  TrendingUp, 
  BookMarked,
  BarChart3,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { cn } from "@/lib/utils"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

const navItems = [
  { 
    href: "/dashboard", 
    icon: Home, 
    label: "Home",
  },
  { 
    href: "/check-in", 
    icon: CheckCircle, 
    label: "Daily Check-in",
  },
  { 
    href: "/grounding", 
    icon: Heart, 
    label: "Pause & Support",
  },
  { 
    href: "/profile", 
    icon: Shield, 
    label: "Personal Safety",
  },
  { 
    href: "/pattern-awareness", 
    icon: TrendingUp, 
    label: "Pattern Awareness",
  },
  { 
    href: "/library", 
    icon: BookMarked, 
    label: "Library",
  },
  { 
    href: "/dashboard", 
    icon: BarChart3, 
    label: "Dashboard",
  },
]

export function BottomNavBar() {
  const pathname = usePathname()
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollContainerRef.current) {
      const scrollAmount = 80
      scrollContainerRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <TooltipProvider>
      <nav className="flex-shrink-0 border-t border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-20 items-center gap-1 px-2">
          {/* Left Scroll Arrow */}
          <button
            onClick={() => scroll("left")}
            className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-lg text-foreground/60 hover:text-foreground hover:bg-foreground/5 transition-all"
            aria-label="Scroll left"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          {/* Scrollable Nav Items */}
          <div
            ref={scrollContainerRef}
            className="flex-1 flex items-center gap-1 overflow-x-auto scrollbar-hide scroll-smooth"
          >
            {navItems.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + "/")
              return (
                <Tooltip key={item.href}>
                  <TooltipTrigger asChild>
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center justify-center rounded-lg p-2 transition-all flex-shrink-0",
                        isActive
                          ? "text-primary bg-primary/10"
                          : "text-foreground/60 hover:text-foreground hover:bg-foreground/5"
                      )}
                    >
                      <item.icon className="h-6 w-6" />
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-xs">
                    {item.label}
                  </TooltipContent>
                </Tooltip>
              )
            })}
          </div>

          {/* Right Scroll Arrow */}
          <button
            onClick={() => scroll("right")}
            className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-lg text-foreground/60 hover:text-foreground hover:bg-foreground/5 transition-all"
            aria-label="Scroll right"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </nav>
    </TooltipProvider>
  )
}
