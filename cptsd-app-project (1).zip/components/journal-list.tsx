"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Loader2, BookOpen, Trash2 } from "lucide-react"
import type { JournalEntry } from "@/lib/db/schema"
import { cn } from "@/lib/utils"

const moodColors: Record<string, string> = {
  happy: "bg-green-100 text-green-700",
  sad: "bg-blue-100 text-blue-700",
  anxious: "bg-yellow-100 text-yellow-700",
  calm: "bg-teal-100 text-teal-700",
  angry: "bg-red-100 text-red-700",
  neutral: "bg-gray-100 text-gray-700",
}

interface JournalListProps {
  entries: JournalEntry[]
  onCreateEntry: (data: { title: string; content: string; mood: string }) => Promise<void>
  onDeleteEntry: (id: number) => Promise<void>
  isCreating?: boolean
}

export function JournalList({ entries, onCreateEntry, onDeleteEntry, isCreating }: JournalListProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [mood, setMood] = useState("neutral")
  const [deletingId, setDeletingId] = useState<number | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onCreateEntry({ title, content, mood })
    setTitle("")
    setContent("")
    setMood("neutral")
    setIsDialogOpen(false)
  }

  const handleDelete = async (id: number) => {
    setDeletingId(id)
    await onDeleteEntry(id)
    setDeletingId(null)
  }

  const moods = ["happy", "calm", "neutral", "anxious", "sad", "angry"]

  return (
    <div className="space-y-4">
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button className="w-full gap-2 rounded-xl">
            <Plus className="h-5 w-5" />
            New Journal Entry
          </Button>
        </DialogTrigger>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Journal Entry</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title (optional)</Label>
              <Input
                id="title"
                placeholder="Give your entry a title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="rounded-xl"
              />
            </div>

            <div className="space-y-2">
              <Label>How are you feeling?</Label>
              <div className="flex flex-wrap gap-2">
                {moods.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMood(m)}
                    className={cn(
                      "rounded-full px-4 py-2 text-sm font-medium capitalize transition-all",
                      mood === m
                        ? moodColors[m] + " ring-2 ring-offset-2"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    )}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Your thoughts</Label>
              <Textarea
                id="content"
                placeholder="Write about your day, feelings, thoughts..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                required
                className="min-h-40 resize-none rounded-xl"
              />
            </div>

            <Button type="submit" disabled={isCreating} className="w-full rounded-xl">
              {isCreating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Entry"
              )}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {entries.length === 0 ? (
        <Card className="flex flex-col items-center justify-center p-8 text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground/50" />
          <h3 className="mt-4 text-lg font-semibold">No journal entries yet</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Start writing to track your thoughts and feelings
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {entries.map((entry) => (
            <Card key={entry.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {entry.title && (
                      <h3 className="font-semibold text-foreground">{entry.title}</h3>
                    )}
                    {entry.mood && (
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-xs font-medium capitalize",
                          moodColors[entry.mood] || moodColors.neutral
                        )}
                      >
                        {entry.mood}
                      </span>
                    )}
                  </div>
                  <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">
                    {entry.content}
                  </p>
                  <p className="mt-2 text-xs text-muted-foreground/70">
                    {new Date(entry.createdAt).toLocaleDateString("en-US", {
                      weekday: "short",
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(entry.id)}
                  disabled={deletingId === entry.id}
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                >
                  {deletingId === entry.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
