import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Heart } from "lucide-react"

export default async function HomePage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect("/dashboard")

  return (
    <main className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Hero Section */}
      <section className="flex-1 flex flex-col items-center justify-center px-6 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary shadow-lg">
          <Heart className="h-10 w-10 text-primary-foreground" />
        </div>
        <h1 className="mt-6 text-3xl font-bold tracking-tight text-foreground">
          CPTSD Toolkit
        </h1>
        <p className="mt-3 max-w-sm text-foreground/70">
          Your personal companion for healing and self-discovery. Track your journey, build resilience, and find peace.
        </p>
        <div className="mt-8 flex w-full max-w-xs flex-col gap-3">
          <Link href="/sign-up">
            <Button className="h-12 w-full rounded-xl text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90">
              Get Started
            </Button>
          </Link>
          <Link href="/sign-in">
            <Button variant="outline" className="h-12 w-full rounded-xl text-base font-semibold border-primary text-primary hover:bg-primary/10">
              Sign In
            </Button>
          </Link>
        </div>
      </section>
    </main>
  )
}
