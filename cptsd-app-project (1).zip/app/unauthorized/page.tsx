"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

export default function UnauthorizedPage() {
  const router = useRouter()

  return (
    <div className="h-screen w-full flex flex-col items-center justify-center bg-background gap-6 px-4">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Access Denied
        </h1>
        <p className="text-foreground/70 text-lg mb-8">
          You do not have permission to access this page or perform this action.
        </p>
      </div>

      <div className="flex gap-4">
        <Link href="/">
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            Go to Home
          </Button>
        </Link>
        <Button 
          variant="outline" 
          className="border-border text-foreground hover:bg-foreground/10"
          onClick={() => router.back()}
        >
          Go Back
        </Button>
      </div>

      <div className="mt-12 p-6 bg-card rounded-lg max-w-md text-center">
        <p className="text-sm text-card-foreground/70">
          If you believe this is an error, please contact support or your
          administrator.
        </p>
      </div>
    </div>
  )
}
