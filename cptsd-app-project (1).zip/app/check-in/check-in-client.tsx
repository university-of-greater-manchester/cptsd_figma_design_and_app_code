"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { DailyCheckInForm } from "@/components/daily-check-in-form"
import { createDailyCheckIn } from "@/app/actions/user-actions"
import { ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"
import { BackButton } from "@/components/back-button"

export function CheckInClient() {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [isComplete, setIsComplete] = useState(false)

  const handleSubmit = async (data: {
    moodScore: number
    energyLevel: number
    anxietyLevel: number
    sleepQuality: number
    notes: string
    triggers: string
  }) => {
    startTransition(async () => {
      try {
        await createDailyCheckIn(data)
        setIsComplete(true)
      } catch (error) {
        console.error("Failed to save check-in:", error)
      }
    })
  }

  if (isComplete) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-card/30">
          <CheckCircle className="h-10 w-10 text-primary" />
        </div>
        <h2 className="mt-6 text-2xl font-bold text-foreground">Check-in Complete!</h2>
        <p className="mt-2 text-center text-muted-foreground">
          Great job taking time to check in with yourself today.
        </p>
        <div className="mt-8 flex gap-3">
          <Button variant="outline" onClick={() => router.push("/dashboard")} className="rounded-xl">
            Go to Dashboard
          </Button>
          <Button onClick={() => router.push("/journal")} className="rounded-xl">
            Write in Journal
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-4 px-4">
          <BackButton fallbackRoute="/dashboard" icon={CheckCircle} />
          <h1 className="text-lg font-semibold text-foreground">Daily Check-in</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-foreground">How are you today?</h2>
          <p className="mt-1 text-muted-foreground">
            Take a moment to reflect on how you are feeling
          </p>
        </div>

        <DailyCheckInForm onSubmit={handleSubmit} isLoading={isPending} />
      </main>
    </div>
  )
}
