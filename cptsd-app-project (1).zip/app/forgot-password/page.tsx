"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { forgotPassword } from "@/app/actions/password-reset-actions"
import { Loader2, Heart, ArrowLeft } from "lucide-react"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      if (!email) {
        setError("Please enter your email address")
        setIsLoading(false)
        return
      }

      const result = await forgotPassword(email)
      
      if (result.success) {
        setSuccess(true)
        setEmail("")
      } else {
        setError(result.message)
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="flex-shrink-0 flex flex-col items-center justify-center px-6 pt-8 pb-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-primary">
          <Heart className="h-8 w-8 text-primary-foreground" />
        </div>
        <h1 className="mt-4 text-2xl font-bold text-foreground">CPTSD Toolkit</h1>
      </div>

      {/* Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-20">
        <div className="w-full max-w-sm">
          {success ? (
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <h2 className="text-xl font-semibold text-foreground">Check Your Email</h2>
                <p className="text-sm text-foreground/70">
                  We&apos;ve sent a password reset link to <span className="font-semibold">{email}</span>. 
                  Click the link to reset your password.
                </p>
              </div>

              <div className="rounded-lg bg-primary/10 p-4 space-y-2 text-sm text-foreground/80">
                <p className="font-semibold">Didn&apos;t receive an email?</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Check your spam folder</li>
                  <li>Make sure you entered the correct email address</li>
                  <li>Try requesting a new reset link</li>
                </ul>
              </div>

              <Button
                onClick={() => setSuccess(false)}
                className="w-full h-12 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 text-base font-semibold"
              >
                Send Another Email
              </Button>

              <div className="text-center">
                <Link href="/sign-in" className="text-sm text-primary hover:underline font-medium flex items-center justify-center gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Sign In
                </Link>
              </div>
            </div>
          ) : (
            <>
              <div className="mb-6 space-y-2">
                <h2 className="text-xl font-semibold text-foreground">Reset Your Password</h2>
                <p className="text-sm text-foreground/70">
                  Enter your email address and we&apos;ll send you a link to reset your password.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-foreground">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="mt-2 bg-card border-border text-card-foreground placeholder:text-card-foreground/50"
                    disabled={isLoading}
                  />
                </div>

                {error && (
                  <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={isLoading || !email}
                  className="h-12 w-full rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 text-base font-semibold"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    "Send Reset Link"
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <Link href="/sign-in" className="text-sm text-primary hover:underline font-medium flex items-center justify-center gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Sign In
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
