"use client"

import { useState } from "react"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SideMenu } from "@/components/side-menu"
import {
  Menu,
  Bell,
  CheckCircle,
  Heart,
  Shield,
  TrendingUp,
  BookMarked,
  BarChart3,
} from "lucide-react"

interface DashboardClientProps {
  user: {
    id: string
    name: string
    email: string
    image?: string | null
  }
}

const quickActions = [
  {
    href: "/check-in",
    icon: CheckCircle,
    label: "Daily Check-in",
    description: "Track your mood and wellbeing",
  },
  {
    href: "/grounding",
    icon: Heart,
    label: "Pause & Support",
    description: "Tools and support to help you through difficult moments",
  },
  {
    href: "/profile",
    icon: Shield,
    label: "Personal Safety",
    description: "Support & planning",
  },
  {
    href: "/pattern-awareness",
    icon: TrendingUp,
    label: "Pattern Awareness",
    description: "Recognise your patterns over time",
  },
  {
    href: "/library",
    icon: BookMarked,
    label: "Library",
    description: "Educational content and resources",
  },
  {
    href: "/dashboard",
    icon: BarChart3,
    label: "Dashboard",
    description: "Overview and your progress",
  },
]

export function DashboardClient({ user }: DashboardClientProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const greeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Good Morning"
    if (hour < 18) return "Good Afternoon"
    return "Good Evening"
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMenuOpen(true)}
            className="h-10 w-10 text-foreground hover:bg-foreground/10"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">CPTSD Toolkit</h1>
          <Button variant="ghost" size="icon" className="h-10 w-10 text-foreground hover:bg-foreground/10 transition-colors duration-200 active:bg-foreground/20">
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden px-3 py-3 flex flex-col">
        {/* Welcome Section */}
        <section className="mb-2 flex-shrink-0">
          <h2 className="text-lg font-bold text-foreground">
            {greeting()}, {user.name.split(" ")[0]}
          </h2>
          <p className="mt-0.5 text-foreground/70 text-xs">
            How are you feeling today?
          </p>
        </section>

        {/* Quick Actions Grid - 6 Cards in 2x3 */}
        <section className="flex-1 overflow-hidden">
          <div className="grid grid-cols-2 gap-2 h-full">
            {quickActions.map((action) => (
              <Link key={action.href} href={action.href} className="flex">
                <Card className="flex flex-col items-center justify-center p-3 w-full bg-card text-card-foreground hover:shadow-lg transition-all rounded-2xl">
                  <action.icon className="h-7 w-7 mb-2 text-primary" />
                  <span className="text-xs font-semibold text-center line-clamp-2">
                    {action.label}
                  </span>
                  <span className="text-[10px] text-center opacity-75 line-clamp-1 mt-1">
                    {action.description}
                  </span>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      </main>

      <SideMenu
        open={isMenuOpen}
        onOpenChange={setIsMenuOpen}
        userName={user.name}
        userImage={user.image}
      />
    </div>
  )
}
