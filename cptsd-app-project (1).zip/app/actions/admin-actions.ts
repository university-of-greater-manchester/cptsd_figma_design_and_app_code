"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { userRole, role, user, auditLog } from "@/lib/db/schema"
import { checkPermission, logAuditTrail, enforcePermission } from "@/lib/rbac"
import { eq } from "drizzle-orm"
import { headers } from "next/headers"

// ============================================================================
// AUTH HELPER
// ============================================================================

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

async function getRequest() {
  const req = (await headers()).get("x-forwarded-for") || "unknown"
  return {
    ipAddress: req,
    userAgent: (await headers()).get("user-agent") || "unknown",
  }
}

// ============================================================================
// ROLE MANAGEMENT (Admin Only)
// ============================================================================

/**
 * Assign role to user (requires users:manage permission)
 */
export async function assignRoleToUser(
  targetUserId: string,
  roleName: string
) {
  const adminId = await getUserId()
  const reqInfo = await getRequest()

  // RBAC: Enforce permission
  await enforcePermission(adminId, "users:manage")

  // Get role ID
  const roleRecord = await db
    .select()
    .from(role)
    .where(eq(role.name, roleName))
    .limit(1)

  if (!roleRecord) throw new Error("Role not found")

  // Assign role
  const result = await db
    .insert(userRole)
    .values({
      userId: targetUserId,
      roleId: roleRecord[0].id,
      grantedBy: adminId,
    })
    .returning()

  // Audit: Log the action
  await logAuditTrail(
    adminId,
    "assign_role",
    "users",
    targetUserId,
    { role: roleName, targetUser: targetUserId },
    reqInfo.ipAddress,
    reqInfo.userAgent
  )

  return result[0]
}

/**
 * Revoke role from user (requires users:manage permission)
 */
export async function revokeRoleFromUser(
  targetUserId: string,
  roleName: string
) {
  const adminId = await getUserId()
  const reqInfo = await getRequest()

  // RBAC: Enforce permission
  await enforcePermission(adminId, "users:manage")

  // Get role ID
  const roleRecord = await db
    .select()
    .from(role)
    .where(eq(role.name, roleName))
    .limit(1)

  if (!roleRecord) throw new Error("Role not found")

  // Revoke role
  await db
    .delete(userRole)
    .where(
      eq(userRole.userId, targetUserId) &&
        eq(userRole.roleId, roleRecord[0].id)
    )

  // Audit: Log the action
  await logAuditTrail(
    adminId,
    "revoke_role",
    "users",
    targetUserId,
    { role: roleName, targetUser: targetUserId },
    reqInfo.ipAddress,
    reqInfo.userAgent
  )
}

/**
 * Get all users with their roles (requires users:manage permission)
 */
export async function getAllUsersWithRoles() {
  const adminId = await getUserId()

  // RBAC: Enforce permission
  await enforcePermission(adminId, "users:manage")

  const users = await db
    .select({
      id: user.id,
      name: user.name,
      email: user.email,
    })
    .from(user)

  // Get roles for each user
  const usersWithRoles = await Promise.all(
    users.map(async (u) => {
      const roles = await db
        .select({ name: role.name })
        .from(userRole)
        .innerJoin(role, eq(userRole.roleId, role.id))
        .where(eq(userRole.userId, u.id))

      return {
        ...u,
        roles: roles.map((r) => r.name),
      }
    })
  )

  // Audit: Log the action
  const reqInfo = await getRequest()
  await logAuditTrail(
    adminId,
    "view_users",
    "users",
    undefined,
    { userCount: usersWithRoles.length },
    reqInfo.ipAddress,
    reqInfo.userAgent
  )

  return usersWithRoles
}

/**
 * Get audit logs (requires audit:read permission)
 */
export async function getAuditLogsForUser(targetUserId: string) {
  const userId = await getUserId()
  const reqInfo = await getRequest()

  // RBAC: Enforce permission
  await enforcePermission(userId, "audit:read")

  const logs = await db
    .select()
    .from(auditLog)
    .where(eq(auditLog.userId, targetUserId))
    .orderBy(auditLog.createdAt)
    .limit(100)

  // Audit: Log the action
  await logAuditTrail(
    userId,
    "view_audit_logs",
    "audit",
    targetUserId,
    { targetUser: targetUserId, count: logs.length },
    reqInfo.ipAddress,
    reqInfo.userAgent
  )

  return logs
}

/**
 * Delete user (admin only, requires users:manage permission)
 */
export async function deleteUser(targetUserId: string) {
  const adminId = await getUserId()
  const reqInfo = await getRequest()

  // RBAC: Enforce permission
  await enforcePermission(adminId, "users:manage")

  // Get user details before deletion for audit log
  const userRecord = await db
    .select()
    .from(user)
    .where(eq(user.id, targetUserId))
    .limit(1)

  // Delete user (cascades to all related data)
  await db.delete(user).where(eq(user.id, targetUserId))

  // Audit: Log the action
  await logAuditTrail(
    adminId,
    "delete_user",
    "users",
    targetUserId,
    { user: userRecord[0]?.email || "unknown" },
    reqInfo.ipAddress,
    reqInfo.userAgent
  )
}
