"use server"

import { db } from "@/lib/db"
import { librarySection, libraryChapter } from "@/lib/db/schema"
import { eq } from "drizzle-orm"

export async function getLibrarySections() {
  try {
    const sections = await db
      .select()
      .from(librarySection)
      .orderBy(librarySection.order)
    console.log("[v0] Fetched sections:", sections)
    return sections || []
  } catch (error) {
    console.error("[v0] Error fetching library sections:", error)
    return []
  }
}

export async function getChaptersBySection(sectionId: number) {
  try {
    const chapters = await db
      .select()
      .from(libraryChapter)
      .where(eq(libraryChapter.sectionId, sectionId))
      .orderBy(libraryChapter.orderIndex)
    console.log("[v0] Fetched chapters for section", sectionId, ":", chapters)
    return chapters || []
  } catch (error) {
    console.error("[v0] Error fetching chapters:", error)
    return []
  }
}

export async function getChapterById(chapterId: number) {
  try {
    const chapter = await db
      .select()
      .from(libraryChapter)
      .where(eq(libraryChapter.id, chapterId))
      .limit(1)
    console.log("[v0] Fetched chapter", chapterId, ":", chapter)
    return chapter[0] || null
  } catch (error) {
    console.error("[v0] Error fetching chapter:", error)
    return null
  }
}

export async function getAllChapters() {
  try {
    const chapters = await db
      .select()
      .from(libraryChapter)
      .orderBy(libraryChapter.orderIndex)
    console.log("[v0] Fetched all chapters:", chapters)
    return chapters || []
  } catch (error) {
    console.error("[v0] Error fetching all chapters:", error)
    return []
  }
}
