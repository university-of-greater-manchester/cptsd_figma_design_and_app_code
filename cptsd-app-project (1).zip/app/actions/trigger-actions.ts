"use server"

import { db } from "@/lib/db"
import { triggerTracker } from "@/lib/db/schema"
import { auth } from "@/lib/auth"
import { desc, eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

export async function createTrigger(data: {
  triggerDescription: string
  intensity: number
  response?: string
  supportUsed?: string
  location?: string
  timeOfDay?: string
  notes?: string
}) {
  const userId = await getUserId()
  
  const result = await db
    .insert(triggerTracker)
    .values({
      userId,
      ...data,
    })
    .returning()

  revalidatePath("/pattern-awareness")
  return result[0]
}

export async function getTriggers(userId: string) {
  const triggers = await db
    .select()
    .from(triggerTracker)
    .where(eq(triggerTracker.userId, userId))
    .orderBy(desc(triggerTracker.trackedAt))
  return triggers
}

export async function getTriggersByDateRange(userId: string, startDate: Date, endDate: Date) {
  const triggers = await db
    .select()
    .from(triggerTracker)
    .where(
      (qb) => [
        eq(triggerTracker.userId, userId),
        qb.and(
          qb.gte(triggerTracker.trackedAt, startDate),
          qb.lte(triggerTracker.trackedAt, endDate)
        ),
      ]
    )
    .orderBy(desc(triggerTracker.trackedAt))
  return triggers
}

export async function deleteTrigger(triggerId: number) {
  const userId = await getUserId()
  
  await db
    .delete(triggerTracker)
    .where((qb) => [
      eq(triggerTracker.id, triggerId),
      eq(triggerTracker.userId, userId),
    ])

  revalidatePath("/pattern-awareness")
}

export async function getTriggerStats(userId: string) {
  const triggers = await db
    .select()
    .from(triggerTracker)
    .where(eq(triggerTracker.userId, userId))

  const totalTriggers = triggers.length
  const avgIntensity =
    triggers.reduce((sum, t) => sum + (t.intensity || 0), 0) / (totalTriggers || 1)
  const highIntensityCount = triggers.filter((t) => (t.intensity || 0) >= 7).length

  return {
    totalTriggers,
    avgIntensity: Math.round(avgIntensity * 10) / 10,
    highIntensityCount,
  }
}
