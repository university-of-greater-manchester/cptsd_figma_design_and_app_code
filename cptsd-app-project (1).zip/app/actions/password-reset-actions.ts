"use server"

import { authClient } from "@/lib/auth-client"

export async function forgotPassword(email: string) {
  try {
    // Better Auth's forgetPassword method handles email verification and token generation
    const result = await authClient.forgetPassword({
      email,
      redirectURL: `${process.env.BETTER_AUTH_URL || "http://localhost:3000"}/reset-password`,
    })

    return {
      success: true,
      message: "Password reset email sent. Please check your inbox.",
    }
  } catch (error) {
    console.error("[v0] Forgot password error:", error)
    return {
      success: false,
      message: "Failed to send reset email. Please try again.",
    }
  }
}

export async function resetPassword(token: string, password: string, confirmPassword: string) {
  try {
    if (password !== confirmPassword) {
      return {
        success: false,
        message: "Passwords do not match",
      }
    }

    if (password.length < 8) {
      return {
        success: false,
        message: "Password must be at least 8 characters long",
      }
    }

    // Better Auth's resetPassword method validates token and updates password
    const result = await authClient.resetPassword({
      token,
      password,
    })

    return {
      success: true,
      message: "Password reset successfully. You can now sign in with your new password.",
    }
  } catch (error) {
    console.error("[v0] Reset password error:", error)
    return {
      success: false,
      message: "Failed to reset password. The link may have expired. Please request a new one.",
    }
  }
}
