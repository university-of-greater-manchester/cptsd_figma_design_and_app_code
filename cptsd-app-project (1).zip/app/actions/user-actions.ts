"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import {
  userProfile,
  journalEntry,
  dailyCheckIn,
  groundingExercise,
  copingStrategy,
} from "@/lib/db/schema"
import { checkPermission, logAuditTrail, getUserRoles, buildDataFilters } from "@/lib/rbac"
import { and, desc, eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

// ============================================================================
// AUTH HELPER
// ============================================================================

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

async function getRequest() {
  const req = (await headers()).get("x-forwarded-for") || "unknown"
  return {
    ipAddress: req,
    userAgent: (await headers()).get("user-agent") || "unknown",
  }
}

// ============================================================================
// USER PROFILE CRUD
// ============================================================================

export async function getProfile() {
  const userId = await getUserId()
  
  // RBAC: Check permission
  const hasPermission = await checkPermission(userId, "profile:read")
  if (!hasPermission) throw new Error("Unauthorized: Cannot read profile")
  
  // Audit: Log the action
  const reqInfo = await getRequest()
  await logAuditTrail(userId, "read_profile", "profile", undefined, {}, reqInfo.ipAddress, reqInfo.userAgent)
  
  const profiles = await db
    .select()
    .from(userProfile)
    .where(eq(userProfile.userId, userId))
    .limit(1)
  return profiles[0] || null
}

export async function createProfile(data: {
  displayName?: string
  bio?: string
  avatarUrl?: string
  theme?: string
  notificationsEnabled?: boolean
}) {
  const userId = await getUserId()
  
  // RBAC: Check permission
  const hasPermission = await checkPermission(userId, "profile:update")
  if (!hasPermission) throw new Error("Unauthorized: Cannot update profile")
  
  const reqInfo = await getRequest()
  
  const result = await db
    .insert(userProfile)
    .values({
      userId,
      displayName: data.displayName,
      bio: data.bio,
      avatarUrl: data.avatarUrl,
      theme: data.theme,
      notificationsEnabled: data.notificationsEnabled,
    })
    .returning()
  
  // Audit: Log the action
  await logAuditTrail(userId, "create_profile", "profile", String(result[0]?.id), data, reqInfo.ipAddress, reqInfo.userAgent)
  
  revalidatePath("/profile")
  return result[0]
}

export async function updateProfile(data: {
  displayName?: string
  bio?: string
  avatarUrl?: string
  theme?: string
  notificationsEnabled?: boolean
}) {
  const userId = await getUserId()
  const result = await db
    .update(userProfile)
    .set({
      ...data,
      updatedAt: new Date(),
    })
    .where(eq(userProfile.userId, userId))
    .returning()
  revalidatePath("/profile")
  return result[0]
}

export async function upsertProfile(data: {
  displayName?: string
  bio?: string
  avatarUrl?: string
  theme?: string
  notificationsEnabled?: boolean
}) {
  const existing = await getProfile()
  if (existing) {
    return updateProfile(data)
  }
  return createProfile(data)
}

// ============================================================================
// JOURNAL ENTRIES CRUD
// ============================================================================

export async function getJournalEntries() {
  const userId = await getUserId()
  return db
    .select()
    .from(journalEntry)
    .where(eq(journalEntry.userId, userId))
    .orderBy(desc(journalEntry.createdAt))
}

export async function getJournalEntry(id: number) {
  const userId = await getUserId()
  const entries = await db
    .select()
    .from(journalEntry)
    .where(and(eq(journalEntry.id, id), eq(journalEntry.userId, userId)))
    .limit(1)
  return entries[0] || null
}

export async function createJournalEntry(data: {
  title: string
  content: string
  mood?: string
  tags?: string
}) {
  const userId = await getUserId()
  const result = await db
    .insert(journalEntry)
    .values({
      userId,
      ...data,
    })
    .returning()
  revalidatePath("/journal")
  return result[0]
}

export async function updateJournalEntry(
  id: number,
  data: {
    title?: string
    content?: string
    mood?: string
    tags?: string
  }
) {
  const userId = await getUserId()
  const result = await db
    .update(journalEntry)
    .set({
      ...data,
      updatedAt: new Date(),
    })
    .where(and(eq(journalEntry.id, id), eq(journalEntry.userId, userId)))
    .returning()
  revalidatePath("/journal")
  return result[0]
}

export async function deleteJournalEntry(id: number) {
  const userId = await getUserId()
  await db
    .delete(journalEntry)
    .where(and(eq(journalEntry.id, id), eq(journalEntry.userId, userId)))
  revalidatePath("/journal")
}

// ============================================================================
// DAILY CHECK-INS CRUD
// ============================================================================

export async function getDailyCheckIns(limit = 30) {
  const userId = await getUserId()
  return db
    .select()
    .from(dailyCheckIn)
    .where(eq(dailyCheckIn.userId, userId))
    .orderBy(desc(dailyCheckIn.date))
    .limit(limit)
}

export async function getTodayCheckIn() {
  const userId = await getUserId()
  const today = new Date().toISOString().split("T")[0] // YYYY-MM-DD format

  const checkIns = await db
    .select()
    .from(dailyCheckIn)
    .where(and(eq(dailyCheckIn.userId, userId), eq(dailyCheckIn.date, today)))
    .limit(1)

  return checkIns[0] || null
}

export async function createDailyCheckIn(data: {
  moodScore?: number
  energyLevel?: number
  anxietyLevel?: number
  sleepHours?: string
  notes?: string
}) {
  const userId = await getUserId()
  const today = new Date().toISOString().split("T")[0]
  const result = await db
    .insert(dailyCheckIn)
    .values({
      userId,
      date: today,
      ...data,
    })
    .returning()
  revalidatePath("/dashboard")
  revalidatePath("/check-in")
  return result[0]
}

export async function updateDailyCheckIn(
  id: number,
  data: {
    moodScore?: number
    energyLevel?: number
    anxietyLevel?: number
    sleepHours?: string
    notes?: string
  }
) {
  const userId = await getUserId()
  const result = await db
    .update(dailyCheckIn)
    .set(data)
    .where(and(eq(dailyCheckIn.id, id), eq(dailyCheckIn.userId, userId)))
    .returning()
  revalidatePath("/dashboard")
  revalidatePath("/check-in")
  return result[0]
}

// ============================================================================
// GROUNDING EXERCISES CRUD
// ============================================================================

export async function getGroundingExercises(limit = 20) {
  const userId = await getUserId()
  return db
    .select()
    .from(groundingExercise)
    .where(eq(groundingExercise.userId, userId))
    .orderBy(desc(groundingExercise.completedAt))
    .limit(limit)
}

export async function createGroundingExercise(data: {
  exerciseType: string
  durationSeconds?: number
  effectivenessRating?: number
  notes?: string
}) {
  const userId = await getUserId()
  const result = await db
    .insert(groundingExercise)
    .values({
      userId,
      ...data,
    })
    .returning()
  revalidatePath("/grounding")
  return result[0]
}

// ============================================================================
// COPING STRATEGIES CRUD
// ============================================================================

export async function getCopingStrategies() {
  const userId = await getUserId()
  return db
    .select()
    .from(copingStrategy)
    .where(eq(copingStrategy.userId, userId))
    .orderBy(desc(copingStrategy.createdAt))
}

export async function createCopingStrategy(data: {
  name: string
  description?: string
  category?: string
}) {
  const userId = await getUserId()
  const result = await db
    .insert(copingStrategy)
    .values({
      userId,
      ...data,
    })
    .returning()
  revalidatePath("/coping")
  return result[0]
}

export async function updateCopingStrategy(
  id: number,
  data: {
    name?: string
    description?: string
    category?: string
    isFavorite?: boolean
  }
) {
  const userId = await getUserId()
  const result = await db
    .update(copingStrategy)
    .set(data)
    .where(and(eq(copingStrategy.id, id), eq(copingStrategy.userId, userId)))
    .returning()
  revalidatePath("/coping")
  return result[0]
}

export async function deleteCopingStrategy(id: number) {
  const userId = await getUserId()
  await db
    .delete(copingStrategy)
    .where(and(eq(copingStrategy.id, id), eq(copingStrategy.userId, userId)))
  revalidatePath("/coping")
}

// ============================================================================
// GROUNDING FAVORITES CRUD
// ============================================================================

export async function getGroundingFavorites() {
  const userId = await getUserId()
  const { groundingFavorite } = await import("@/lib/db/schema")
  return db
    .select()
    .from(groundingFavorite)
    .where(eq(groundingFavorite.userId, userId))
    .orderBy(groundingFavorite.orderIndex)
}

export async function addGroundingFavorite(data: {
  exerciseName: string
  exerciseDescription: string
  category: string
}) {
  const userId = await getUserId()
  const { groundingFavorite } = await import("@/lib/db/schema")
  
  const result = await db
    .insert(groundingFavorite)
    .values({
      userId,
      ...data,
      orderIndex: 0,
    })
    .returning()
  
  revalidatePath("/grounding")
  return result[0]
}

export async function removeGroundingFavorite(exerciseName: string) {
  const userId = await getUserId()
  const { groundingFavorite } = await import("@/lib/db/schema")
  
  await db
    .delete(groundingFavorite)
    .where(
      and(
        eq(groundingFavorite.userId, userId),
        eq(groundingFavorite.exerciseName, exerciseName)
      )
    )
  
  revalidatePath("/grounding")
}

export async function isGroundingFavorite(exerciseName: string) {
  const userId = await getUserId()
  const { groundingFavorite } = await import("@/lib/db/schema")
  
  const result = await db
    .select()
    .from(groundingFavorite)
    .where(
      and(
        eq(groundingFavorite.userId, userId),
        eq(groundingFavorite.exerciseName, exerciseName)
      )
    )
    .limit(1)
  
  return result.length > 0
}
