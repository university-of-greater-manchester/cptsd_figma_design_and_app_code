'use client'

import { useState } from 'react'
import { Bell, Plus, TrendingUp, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { BackButton } from '@/components/back-button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { createTrigger } from '@/app/actions/trigger-actions'
import { cn } from '@/lib/utils'

type Trigger = {
  id: number
  userId: string
  triggerDescription: string
  intensity: number | null
  response: string | null
  supportUsed: string | null
  location: string | null
  timeOfDay: string | null
  notes: string | null
  trackedAt: Date | null
}

interface PatternAwarenessClientProps {
  initialTriggers: Trigger[]
  stats: {
    totalTriggers: number
    avgIntensity: number
    highIntensityCount: number
  }
}

export function PatternAwarenessClient({
  initialTriggers,
  stats,
}: PatternAwarenessClientProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    triggerDescription: '',
    intensity: 5,
    response: '',
    supportUsed: '',
    location: '',
    timeOfDay: '',
    notes: '',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      await createTrigger({
        triggerDescription: formData.triggerDescription,
        intensity: formData.intensity,
        response: formData.response || undefined,
        supportUsed: formData.supportUsed || undefined,
        location: formData.location || undefined,
        timeOfDay: formData.timeOfDay || undefined,
        notes: formData.notes || undefined,
      })
      setFormData({
        triggerDescription: '',
        intensity: 5,
        response: '',
        supportUsed: '',
        location: '',
        timeOfDay: '',
        notes: '',
      })
      setIsDialogOpen(false)
    } catch (error) {
      console.error('Failed to create trigger:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-4">
          <BackButton fallbackRoute="/dashboard" icon={TrendingUp} />
          <h1 className="text-lg font-semibold text-foreground">Pattern Awareness</h1>
          <Button variant="ghost" size="icon" className="h-10 w-10 text-foreground hover:bg-foreground/10 transition-colors duration-200 active:bg-foreground/20">
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto px-4 py-3 flex flex-col">
        {/* Stats - No Cards */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="text-center">
            <p className="text-xs text-foreground/60 mb-0.5">Total</p>
            <p className="text-xl font-bold text-primary">{stats.totalTriggers}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-foreground/60 mb-0.5">Avg Intensity</p>
            <p className="text-xl font-bold text-primary">{stats.avgIntensity.toFixed(1)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-foreground/60 mb-0.5">High</p>
            <p className="text-xl font-bold text-primary">{stats.highIntensityCount}</p>
          </div>
        </div>

        {/* Triggers List - No Cards */}
        <div className="flex-1 flex flex-col gap-1.5 min-h-0 mb-3">
          {initialTriggers.length > 0 ? (
            initialTriggers.map(trigger => (
              <div
                key={trigger.id}
                className="p-2 rounded-lg hover:bg-foreground/5 border-b border-border/50"
              >
                <div className="flex items-start gap-2">
                  <TrendingUp className="h-4 w-4 flex-shrink-0 text-primary mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-xs line-clamp-2 text-foreground">
                      {trigger.triggerDescription}
                    </p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="text-xs font-medium px-1.5 py-0.5 bg-primary/20 text-primary rounded text-xs">
                        {trigger.intensity}/10
                      </span>
                    </div>
                    {trigger.notes && (
                      <p className="text-xs text-foreground/50 mt-0.5 line-clamp-1">
                        {trigger.notes}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center flex-1">
              <TrendingUp className="h-10 w-10 text-foreground/20 mb-2" />
              <p className="text-foreground/60 text-xs">No triggers tracked yet</p>
            </div>
          )}
        </div>
      </main>

      {/* Add Button */}
      <div className="flex-shrink-0 border-t border-border bg-background p-3">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full h-10 bg-primary text-primary-foreground text-sm">
              <Plus className="h-4 w-4 mr-1" />
              Log Trigger
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-background border-border max-h-[90vh] overflow-y-auto p-4">
            <DialogHeader>
              <DialogTitle className="text-foreground text-base">Log Trigger</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-2.5">
              {/* Trigger Description */}
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">
                  What triggered you?
                </label>
                <Input
                  placeholder="Describe..."
                  value={formData.triggerDescription}
                  onChange={(e) =>
                    setFormData({ ...formData, triggerDescription: e.target.value })
                  }
                  required
                  className="h-8 text-sm border-0 bg-foreground/5 rounded"
                />
              </div>

              {/* Intensity - Compact Buttons */}
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">
                  Intensity: <span className="font-normal text-foreground/60">1 (Low) - 10 (High)</span>
                </label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setFormData({ ...formData, intensity: level })}
                      className={cn(
                        "h-7 w-7 rounded-full text-xs font-semibold transition-all",
                        formData.intensity === level
                          ? "bg-primary text-white ring-2 ring-primary/50"
                          : "bg-foreground/10 text-foreground hover:bg-foreground/20"
                      )}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              {/* Response */}
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">
                  How did you respond?
                </label>
                <Textarea
                  placeholder="Describe your response..."
                  value={formData.response}
                  onChange={(e) =>
                    setFormData({ ...formData, response: e.target.value })
                  }
                  className="min-h-14 resize-none text-sm"
                />
              </div>

              {/* Support Used */}
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">
                  Support used
                </label>
                <Input
                  placeholder="What helped..."
                  value={formData.supportUsed}
                  onChange={(e) =>
                    setFormData({ ...formData, supportUsed: e.target.value })
                  }
                  className="h-8 text-sm border-0 bg-foreground/5 rounded"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">
                  Notes
                </label>
                <Textarea
                  placeholder="Additional notes..."
                  value={formData.notes}
                  onChange={(e) =>
                    setFormData({ ...formData, notes: e.target.value })
                  }
                  className="min-h-12 resize-none text-sm"
                />
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1 h-9 text-sm"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="flex-1 h-9 text-sm bg-primary text-primary-foreground"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Log'
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
