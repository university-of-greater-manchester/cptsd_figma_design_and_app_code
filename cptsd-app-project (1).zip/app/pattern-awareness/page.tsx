import { getTriggers, getTriggerStats } from "@/app/actions/trigger-actions"
import { PatternAwarenessClient } from "./pattern-awareness-client"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { headers } from "next/headers"

export default async function PatternAwarenessPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  const triggers = await getTriggers(session.user.id)
  const stats = await getTriggerStats(session.user.id)

  return (
    <PatternAwarenessClient initialTriggers={triggers} stats={stats} />
  )
}
