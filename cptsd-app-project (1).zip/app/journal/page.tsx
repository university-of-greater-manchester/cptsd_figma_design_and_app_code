import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { JournalClient } from "./journal-client"
import { getJournalEntries } from "@/app/actions/user-actions"

export default async function JournalPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  let entries: Awaited<ReturnType<typeof getJournalEntries>> = []
  try {
    entries = await getJournalEntries()
  } catch {
    // Database not connected yet - show empty state
  }

  return <JournalClient initialEntries={entries} />
}
