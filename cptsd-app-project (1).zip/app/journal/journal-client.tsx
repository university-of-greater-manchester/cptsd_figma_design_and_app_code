"use client"

import { useState, useTransition } from "react"
import { Button } from "@/components/ui/button"
import { JournalList } from "@/components/journal-list"
import { createJournalEntry, deleteJournalEntry } from "@/app/actions/user-actions"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import type { JournalEntry } from "@/lib/db/schema"

interface JournalClientProps {
  initialEntries: JournalEntry[]
}

export function JournalClient({ initialEntries }: JournalClientProps) {
  const [entries, setEntries] = useState(initialEntries)
  const [isPending, startTransition] = useTransition()

  const handleCreate = async (data: { title: string; content: string; mood: string }) => {
    startTransition(async () => {
      try {
        const newEntry = await createJournalEntry(data)
        if (newEntry) {
          setEntries([newEntry, ...entries])
        }
      } catch (error) {
        console.error("Failed to create entry:", error)
      }
    })
  }

  const handleDelete = async (id: number) => {
    try {
      await deleteJournalEntry(id)
      setEntries(entries.filter((e) => e.id !== id))
    } catch (error) {
      console.error("Failed to delete entry:", error)
    }
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-4 px-4">
          <BackButton fallbackRoute="/dashboard" />
          <h1 className="text-lg font-semibold text-foreground">Journal</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-foreground">Your Journal</h2>
          <p className="mt-1 text-muted-foreground">
            Write down your thoughts and feelings
          </p>
        </div>

        <JournalList
          entries={entries}
          onCreateEntry={handleCreate}
          onDeleteEntry={handleDelete}
          isCreating={isPending}
        />
      </main>
    </div>
  )
}
