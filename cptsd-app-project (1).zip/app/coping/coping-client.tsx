"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Heart,
  Users,
  Dumbbell,
  Brain,
  Music,
  Palette,
  BookOpen,
  Coffee,
} from "lucide-react"
import { BackButton } from "@/components/back-button"

const strategies = [
  {
    category: "Physical",
    icon: Dumbbell,
    items: [
      "Go for a walk",
      "Do stretching exercises",
      "Take a warm shower",
      "Practice deep breathing",
      "Exercise or yoga",
    ],
  },
  {
    category: "Mental",
    icon: Brain,
    items: [
      "Write in your journal",
      "Practice mindfulness",
      "Challenge negative thoughts",
      "Use positive affirmations",
      "Visualize a safe place",
    ],
  },
  {
    category: "Social",
    icon: Users,
    items: [
      "Call a trusted friend",
      "Spend time with a pet",
      "Join a support group",
      "Reach out to a therapist",
      "Connect with loved ones",
    ],
  },
  {
    category: "Creative",
    icon: Palette,
    items: [
      "Draw or paint",
      "Listen to calming music",
      "Play an instrument",
      "Write poetry or stories",
      "Create a collage",
    ],
  },
  {
    category: "Self-Care",
    icon: Heart,
    items: [
      "Get enough sleep",
      "Eat nourishing food",
      "Practice self-compassion",
      "Set healthy boundaries",
      "Take breaks when needed",
    ],
  },
  {
    category: "Soothing",
    icon: Coffee,
    items: [
      "Drink herbal tea",
      "Use aromatherapy",
      "Take a warm bath",
      "Wrap in a cozy blanket",
      "Light a candle",
    ],
  },
]

export function CopingClient() {
  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-4 px-4">
          <BackButton fallbackRoute="/dashboard" />
          <h1 className="text-lg font-semibold text-foreground">Coping Strategies</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-foreground">Your Coping Toolkit</h2>
          <p className="mt-1 text-muted-foreground">
            Strategies to help you manage difficult moments
          </p>
        </div>

        <div className="space-y-4">
          {strategies.map((category) => (
            <Card key={category.category} className="overflow-hidden">
              <div className="flex items-center gap-3 border-b border-border p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-card">
                  <category.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">{category.category}</h3>
              </div>
              <ul className="divide-y divide-border">
                {category.items.map((item, index) => (
                  <li key={index} className="flex items-center gap-3 p-4">
                    <div className="h-2 w-2 rounded-full bg-primary/50" />
                    <span className="text-sm text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
