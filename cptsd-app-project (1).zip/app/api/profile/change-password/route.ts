import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { account } from "@/lib/db/schema"
import { eq } from "drizzle-orm"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const session = await auth.api.getSession({ headers: await headers() })
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { currentPassword, newPassword } = await request.json()

    if (!currentPassword || !newPassword) {
      return NextResponse.json(
        { error: "Current and new passwords are required" },
        { status: 400 }
      )
    }

    // Get current account with password
    const userAccounts = await db
      .select()
      .from(account)
      .where(eq(account.userId, session.user.id))

    if (!userAccounts || userAccounts.length === 0) {
      return NextResponse.json(
        { error: "Account not found" },
        { status: 404 }
      )
    }

    const currentAcct = userAccounts[0]

    // Verify current password
    if (!currentAcct.password) {
      return NextResponse.json(
        { error: "No password set. Please use password reset." },
        { status: 400 }
      )
    }

    // Compare passwords using bcrypt
    const passwordMatch = await bcrypt.compare(currentPassword, currentAcct.password)

    if (!passwordMatch) {
      return NextResponse.json(
        { error: "Current password is incorrect" },
        { status: 401 }
      )
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10)

    // Update password in database
    await db
      .update(account)
      .set({ password: hashedPassword })
      .where(eq(account.userId, session.user.id))

    return NextResponse.json({ success: true, message: "Password updated successfully" })
  } catch (error) {
    console.error("Password change error:", error)
    return NextResponse.json(
      { error: "Failed to change password" },
      { status: 500 }
    )
  }
}
