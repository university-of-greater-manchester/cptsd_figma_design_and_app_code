import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { user as userTable } from "@/lib/db/schema"
import { eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

export async function POST(request: NextRequest) {
  try {
    const session = await auth.api.getSession({ headers: await headers() })
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File
    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Convert image to base64 for storage
    const buffer = await file.arrayBuffer()
    const base64 = Buffer.from(buffer).toString("base64")
    const dataUrl = `data:image/png;base64,${base64}`

    // Update user image in database
    await db
      .update(userTable)
      .set({ image: dataUrl })
      .where(eq(userTable.id, session.user.id))

    // Revalidate the profile pages to reflect the new image
    revalidatePath("/profile")
    revalidatePath("/profile/upload-picture")

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Picture upload error:", error)
    return NextResponse.json(
      { error: "Failed to upload picture" },
      { status: 500 }
    )
  }
}
