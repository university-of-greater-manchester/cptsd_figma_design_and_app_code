"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { resetPassword } from "@/app/actions/password-reset-actions"
import { Loader2, Heart, ArrowLeft, CheckCircle } from "lucide-react"

function ResetPasswordContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get("token")
  
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (!token) {
      setError("Invalid reset link. Please request a new password reset.")
    }
  }, [token])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      if (!token) {
        setError("Invalid reset link")
        setIsLoading(false)
        return
      }

      if (!password || !confirmPassword) {
        setError("Please enter both password fields")
        setIsLoading(false)
        return
      }

      if (password !== confirmPassword) {
        setError("Passwords do not match")
        setIsLoading(false)
        return
      }

      if (password.length < 8) {
        setError("Password must be at least 8 characters long")
        setIsLoading(false)
        return
      }

      const result = await resetPassword(token, password, confirmPassword)

      if (result.success) {
        setSuccess(true)
        // Redirect to sign-in after 3 seconds
        setTimeout(() => {
          router.push("/sign-in")
        }, 3000)
      } else {
        setError(result.message)
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="flex-shrink-0 flex flex-col items-center justify-center px-6 pt-8 pb-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-primary">
          <Heart className="h-8 w-8 text-primary-foreground" />
        </div>
        <h1 className="mt-4 text-2xl font-bold text-foreground">CPTSD Toolkit</h1>
      </div>

      {/* Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-20">
        <div className="w-full max-w-sm">
          {success ? (
            <div className="space-y-6 text-center">
              <div className="flex justify-center">
                <div className="rounded-full bg-primary/10 p-4">
                  <CheckCircle className="h-12 w-12 text-primary" />
                </div>
              </div>
              
              <div className="space-y-2">
                <h2 className="text-xl font-semibold text-foreground">Password Reset Successfully</h2>
                <p className="text-sm text-foreground/70">
                  Your password has been reset. You can now sign in with your new password.
                </p>
              </div>

              <p className="text-xs text-foreground/50">
                Redirecting to sign in in a few seconds...
              </p>

              <Link
                href="/sign-in"
                className="inline-flex items-center justify-center gap-2 text-sm text-primary hover:underline font-medium"
              >
                <ArrowLeft className="h-4 w-4" />
                Go to Sign In
              </Link>
            </div>
          ) : !token ? (
            <div className="space-y-6 text-center">
              <div className="rounded-lg bg-destructive/10 p-4">
                <p className="text-sm text-destructive font-medium">
                  Invalid Reset Link
                </p>
                <p className="text-xs text-destructive/80 mt-2">
                  The password reset link is invalid or has expired.
                </p>
              </div>

              <Link
                href="/forgot-password"
                className="inline-flex items-center justify-center gap-2 text-sm text-primary hover:underline font-medium"
              >
                <ArrowLeft className="h-4 w-4" />
                Request New Reset Link
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6 space-y-2">
                <h2 className="text-xl font-semibold text-foreground">Create New Password</h2>
                <p className="text-sm text-foreground/70">
                  Enter your new password below. Make it strong and secure.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="password" className="text-foreground">
                    New Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="mt-2 bg-card border-border text-card-foreground placeholder:text-card-foreground/50"
                    disabled={isLoading}
                    minLength={8}
                  />
                  <p className="text-xs text-foreground/50 mt-1">
                    Minimum 8 characters
                  </p>
                </div>

                <div>
                  <Label htmlFor="confirmPassword" className="text-foreground">
                    Confirm Password
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    className="mt-2 bg-card border-border text-card-foreground placeholder:text-card-foreground/50"
                    disabled={isLoading}
                    minLength={8}
                  />
                </div>

                {error && (
                  <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                    {error}
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={isLoading || !password || !confirmPassword}
                  className="h-12 w-full rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 text-base font-semibold"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Resetting Password...
                    </>
                  ) : (
                    "Reset Password"
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <Link href="/sign-in" className="text-sm text-primary hover:underline font-medium flex items-center justify-center gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Sign In
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={
      <div className="flex h-screen flex-col bg-background items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    }>
      <ResetPasswordContent />
    </Suspense>
  )
}
