"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { authClient } from "@/lib/auth-client"
import { User, Mail, Bell, Moon, Shield, LogOut, Loader2, AlertCircle, CheckCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { BackButton } from "@/components/back-button"

interface ProfileClientProps {
  user: {
    id: string
    name: string
    email: string
    image?: string | null
  }
}

export function ProfileClient({ user }: ProfileClientProps) {
  const router = useRouter()
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const [showPasswordReset, setShowPasswordReset] = useState(false)
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [passwordSuccess, setPasswordSuccess] = useState("")
  const [isChangingPassword, setIsChangingPassword] = useState(false)

  const handleSignOut = async () => {
    setIsLoggingOut(true)
    await authClient.signOut()
    router.push("/sign-in")
    router.refresh()
  }

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault()
    setPasswordError("")
    setPasswordSuccess("")

    // Validation
    if (!currentPassword) {
      setPasswordError("Please enter your current password")
      return
    }
    if (!newPassword) {
      setPasswordError("Please enter a new password")
      return
    }
    if (!confirmPassword) {
      setPasswordError("Please confirm your password")
      return
    }
    if (newPassword.length < 8) {
      setPasswordError("New password must be at least 8 characters")
      return
    }
    if (newPassword !== confirmPassword) {
      setPasswordError("Passwords do not match")
      return
    }

    setIsChangingPassword(true)
    try {
      const response = await fetch("/api/profile/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      })

      if (response.ok) {
        setPasswordSuccess("Password updated successfully!")
        setCurrentPassword("")
        setNewPassword("")
        setConfirmPassword("")
        setTimeout(() => {
          setShowPasswordReset(false)
          setPasswordSuccess("")
        }, 2000)
      } else {
        const data = await response.json()
        setPasswordError(data.error || "Failed to change password")
      }
    } catch (error) {
      setPasswordError("An error occurred. Please try again.")
    } finally {
      setIsChangingPassword(false)
    }
  }

  const settingsItems = [
    { icon: Bell, label: "Notifications", href: "/settings/notifications" },
    { icon: Moon, label: "Appearance", href: "/settings/appearance" },
    { icon: Shield, label: "Privacy & Security", href: "/settings/privacy" },
  ]

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-4 px-4">
          <BackButton fallbackRoute="/dashboard" icon={User} />
          <h1 className="text-lg font-semibold text-foreground">Profile</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-3">
        {/* Profile Header - Clickable Picture */}
        <Link
          href="/profile/upload-picture"
          className="flex items-center gap-3 mb-4 rounded-lg hover:bg-foreground/5 active:bg-foreground/10 p-2 transition-colors -m-2"
        >
          {user.image ? (
            <img
              src={user.image}
              alt={user.name}
              className="h-16 w-16 rounded-full object-cover flex-shrink-0"
            />
          ) : (
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary flex-shrink-0 hover:bg-primary/90 transition-colors">
              <User className="h-8 w-8 text-primary-foreground" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h2 className="text-base font-bold text-foreground truncate">{user.name}</h2>
            <p className="text-xs text-foreground/60">Click to change picture</p>
          </div>
        </Link>

        {/* Account Info */}
        <div className="space-y-2 mb-4">
          <p className="text-xs font-semibold text-foreground/60 uppercase tracking-wide">Account</p>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-foreground block">Full Name</label>
            <Input
              value={user.name}
              readOnly
              className="h-8 text-sm border-0 bg-foreground/5 rounded"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-foreground block">Email</label>
            <Input
              value={user.email}
              readOnly
              className="h-8 text-sm border-0 bg-foreground/5 rounded"
            />
          </div>
        </div>

        {/* Password Reset Section */}
        <div className="space-y-2 mb-4">
          <button
            onClick={() => setShowPasswordReset(!showPasswordReset)}
            className="text-xs font-semibold text-foreground/60 uppercase tracking-wide hover:text-foreground transition-colors"
          >
            {showPasswordReset ? "Hide" : "Security"}
          </button>

          {showPasswordReset && (
            <form onSubmit={handlePasswordReset} className="space-y-2 bg-foreground/5 p-3 rounded-lg">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-foreground block">
                  Current Password
                </label>
                <Input
                  type="password"
                  placeholder="Enter current password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="h-8 text-sm border-0 bg-background rounded"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-foreground block">
                  New Password
                </label>
                <Input
                  type="password"
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="h-8 text-sm border-0 bg-background rounded"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-foreground block">
                  Confirm Password
                </label>
                <Input
                  type="password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="h-8 text-sm border-0 bg-background rounded"
                />
              </div>

              {passwordError && (
                <div className="flex gap-2 items-start p-2 bg-destructive/10 rounded text-destructive text-xs">
                  <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <p>{passwordError}</p>
                </div>
              )}

              {passwordSuccess && (
                <div className="flex gap-2 items-start p-2 bg-green-500/10 rounded text-green-600 text-xs">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <p>{passwordSuccess}</p>
                </div>
              )}

              <Button
                type="submit"
                disabled={isChangingPassword}
                className="w-full h-8 text-xs bg-primary text-primary-foreground"
              >
                {isChangingPassword ? (
                  <>
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Password"
                )}
              </Button>
            </form>
          )}
        </div>

        {/* Settings */}
        <div className="space-y-2 mb-4">
          <p className="text-xs font-semibold text-foreground/60 uppercase tracking-wide">Settings</p>
          <div className="space-y-1">
            {settingsItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors hover:bg-foreground/5 active:bg-foreground/10"
              >
                <item.icon className="h-4 w-4 text-foreground/60 flex-shrink-0" />
                <span className="text-sm font-medium text-foreground">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Sign Out */}
        <Button
          variant="outline"
          onClick={handleSignOut}
          disabled={isLoggingOut}
          className="w-full gap-2 h-10 text-sm border-destructive/50 text-destructive hover:bg-destructive/10 rounded"
        >
          {isLoggingOut ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <LogOut className="h-4 w-4" />
          )}
          {isLoggingOut ? "Signing out..." : "Sign Out"}
        </Button>
      </main>
    </div>
  )
}
