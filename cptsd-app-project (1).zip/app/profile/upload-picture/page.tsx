import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { UploadPictureClient } from "../upload-picture-client"

export const metadata = {
  title: "Change Picture",
  description: "Upload and adjust your profile picture",
}

export default async function UploadPicturePage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <UploadPictureClient userId={session.user.id} currentImage={session.user.image} />
}
