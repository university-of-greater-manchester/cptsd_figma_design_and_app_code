"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Upload, RotateCw, Loader2, CheckCircle, AlertCircle, ZoomIn, ZoomOut } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { cn } from "@/lib/utils"

interface UploadPictureClientProps {
  userId: string
  currentImage?: string | null
}

export function UploadPictureClient({ userId, currentImage }: UploadPictureClientProps) {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string>(currentImage || "")
  const [scale, setScale] = useState(1)
  const [offsetX, setOffsetX] = useState(0)
  const [offsetY, setOffsetY] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle")
  const [uploadMessage, setUploadMessage] = useState("")

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setSelectedFile(file)
    const reader = new FileReader()
    reader.onload = (event) => {
      setPreviewUrl(event.target?.result as string)
      setScale(1)
      setOffsetX(0)
      setOffsetY(0)
    }
    reader.readAsDataURL(file)
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return
    const deltaX = e.clientX - dragStart.x
    const deltaY = e.clientY - dragStart.y
    setOffsetX((prev) => prev + deltaX)
    setOffsetY((prev) => prev + deltaY)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleZoom = (direction: "in" | "out") => {
    setScale((prev) => {
      const newScale = direction === "in" ? prev + 0.1 : prev - 0.1
      return Math.max(1, Math.min(3, newScale))
    })
  }

  const handleSave = async () => {
    if (!previewUrl) return

    setIsUploading(true)
    setUploadStatus("idle")
    try {
      const canvas = canvasRef.current
      if (!canvas) return

      const ctx = canvas.getContext("2d")
      if (!ctx) return

      const img = new Image()
      img.crossOrigin = "anonymous"
      img.onload = async () => {
        canvas.width = 512
        canvas.height = 512

        ctx.beginPath()
        ctx.arc(256, 256, 256, 0, Math.PI * 2)
        ctx.clip()

        const centerX = 256
        const centerY = 256
        ctx.translate(centerX, centerY)
        ctx.scale(scale, scale)
        ctx.drawImage(img, -img.width / 2 + offsetX / scale, -img.height / 2 + offsetY / scale)

        canvas.toBlob(async (blob) => {
          if (!blob) return

          const formData = new FormData()
          formData.append("file", blob, "profile-picture.png")

          const response = await fetch("/api/profile/upload-picture", {
            method: "POST",
            body: formData,
          })

          if (response.ok) {
            setUploadStatus("success")
            setUploadMessage("Picture saved successfully!")
            // Refresh data and wait for it to complete before navigating back
            await new Promise(resolve => setTimeout(resolve, 500))
            router.refresh()
            await new Promise(resolve => setTimeout(resolve, 1000))
            router.back()
          } else {
            const data = await response.json()
            setUploadStatus("error")
            setUploadMessage(data.error || "Failed to upload picture")
            setIsUploading(false)
          }
        }, "image/png")
      }
      img.src = previewUrl
    } catch (error) {
      setUploadStatus("error")
      setUploadMessage("An error occurred during upload")
      setIsUploading(false)
    }
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between">
          <BackButton fallbackRoute="/profile" />
          <h1 className="text-lg font-semibold text-foreground">Change Picture</h1>
          <div className="w-10" />
        </div>
      </header>

      <main className="flex-1 overflow-hidden px-4 py-2 flex flex-col">
        {/* Preview Circle */}
        <div className="flex justify-center mb-2">
          <div className="relative h-28 w-28 rounded-full border-2 border-primary/30 overflow-hidden bg-foreground/5 flex items-center justify-center flex-shrink-0">
            {previewUrl ? (
              <img
                src={previewUrl}
                alt="Preview"
                className="w-full h-full object-cover"
                style={{
                  transform: `scale(${scale}) translate(${offsetX}px, ${offsetY}px)`,
                  transformOrigin: "center",
                }}
              />
            ) : (
              <Upload className="h-7 w-7 text-foreground/40" />
            )}
          </div>
        </div>

        {/* Upload Input */}
        <Input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* Upload Button */}
        {!previewUrl ? (
          <Button
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-9 text-sm bg-primary text-primary-foreground"
          >
            <Upload className="h-4 w-4 mr-1.5" />
            Browse Picture
          </Button>
        ) : (
          <>
            {/* Image Editor */}
            <div className="flex-1 flex flex-col bg-foreground/5 rounded-lg p-2 mb-2 min-h-0">
              <p className="text-xs font-medium text-foreground/60 mb-1">Drag to adjust</p>
              <div
                className="flex-1 relative overflow-hidden rounded-lg bg-black/5 cursor-move flex items-center justify-center min-h-0"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                <img
                  src={previewUrl}
                  alt="Adjustable"
                  className="max-w-full max-h-full"
                  style={{
                    transform: `scale(${scale}) translate(${offsetX}px, ${offsetY}px)`,
                    transformOrigin: "center",
                    transition: isDragging ? "none" : "transform 0.2s",
                  }}
                  draggable={false}
                />
              </div>
            </div>

            {/* Zoom Controls - Icon Buttons */}
            <div className="flex gap-1 mb-2">
              <Button
                variant="outline"
                onClick={() => handleZoom("out")}
                disabled={scale <= 1}
                className="flex-1 h-8 p-0"
                size="sm"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => handleZoom("in")}
                disabled={scale >= 3}
                className="flex-1 h-8 p-0"
                size="sm"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setScale(1)
                  setOffsetX(0)
                  setOffsetY(0)
                }}
                className="flex-1 h-8 p-0"
                size="sm"
              >
                <RotateCw className="h-4 w-4" />
              </Button>
            </div>

            {/* Status Messages */}
            {uploadStatus === "success" && (
              <div className="flex gap-2 items-center p-1.5 bg-green-500/10 rounded text-green-600 text-xs mb-2">
                <CheckCircle className="h-3.5 w-3.5 flex-shrink-0" />
                <p>{uploadMessage}</p>
              </div>
            )}

            {uploadStatus === "error" && (
              <div className="flex gap-2 items-start p-1.5 bg-destructive/10 rounded text-destructive text-xs mb-2">
                <AlertCircle className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
                <p>{uploadMessage}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="flex-1 h-9 text-sm"
              >
                Choose Another
              </Button>
              <Button
                onClick={handleSave}
                disabled={isUploading}
                className="flex-1 h-9 text-sm bg-primary text-primary-foreground"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Picture"
                )}
              </Button>
            </div>
          </>
        )}
      </main>

      {/* Hidden canvas for processing */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  )
}
