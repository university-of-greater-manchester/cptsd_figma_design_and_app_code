import { getLibrarySections, getAllChapters } from "@/app/actions/library-actions"
import { LibraryClient } from "./library-client"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { headers } from "next/headers"

export default async function LibraryPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  const sections = await getLibrarySections()
  const chapters = await getAllChapters()

  console.log("[v0] LibraryPage - sections:", sections, "chapters:", chapters)

  return <LibraryClient sections={sections || []} chapters={chapters || []} />
}
