'use client'

import { useState } from 'react'
import { Book, Bell, BookMarked } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { BackButton } from '@/components/back-button'
import Link from 'next/link'

type LibrarySection = {
  id: number
  name: string
  description: string | null
  icon: string | null
  order: number | null
  createdAt: Date | null
}

type LibraryChapter = {
  id: number
  sectionId: number | null
  title: string
  description: string | null
  content: string | null
  pageCount: number | null
  orderIndex: number | null
  createdAt: Date | null
}

interface LibraryClientProps {
  sections: LibrarySection[]
  chapters: LibraryChapter[]
}

export function LibraryClient({ sections, chapters }: LibraryClientProps) {
  const [selectedSectionId, setSelectedSectionId] = useState<number | null>(
    sections[0]?.id || null
  )

  const filteredChapters = selectedSectionId
    ? chapters.filter(ch => ch.sectionId === selectedSectionId)
    : chapters

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-4">
          <BackButton fallbackRoute="/dashboard" icon={BookMarked} />
          <h1 className="text-lg font-semibold text-foreground">Library</h1>
          <Button variant="ghost" size="icon" className="h-10 w-10 text-foreground hover:bg-foreground/10 transition-colors duration-200 active:bg-foreground/20">
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto px-4 py-4 flex flex-col">
        {/* Section Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
          {sections && sections.length > 0 ? (
            sections.map(section => (
              <button
                key={section.id}
                onClick={() => setSelectedSectionId(section.id)}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all font-medium text-sm ${
                  selectedSectionId === section.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-card text-card-foreground hover:bg-primary/20'
                }`}
              >
                {section.name}
              </button>
            ))
          ) : (
            <p className="text-foreground/60 text-sm">No sections available</p>
          )}
        </div>

        {/* Chapters Grid */}
        <div className="grid grid-cols-1 gap-3 flex-1">
          {filteredChapters && filteredChapters.length > 0 ? (
            filteredChapters.map(chapter => (
              <Card
                key={chapter.id}
                className="bg-card text-card-foreground p-4 hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <Book className="h-6 w-6 flex-shrink-0 text-primary mt-1" />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm line-clamp-2">{chapter.title}</h3>
                    {chapter.description && (
                      <p className="text-xs text-card-foreground/70 mt-1 line-clamp-2">
                        {chapter.description}
                      </p>
                    )}
                    {chapter.pageCount && (
                      <p className="text-xs text-card-foreground/60 mt-2">
                        {chapter.pageCount} pages
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Book className="h-12 w-12 text-foreground/20 mb-3" />
              <p className="text-foreground/60 text-sm">No chapters available</p>
              <p className="text-foreground/40 text-xs mt-2">Add content to get started</p>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
