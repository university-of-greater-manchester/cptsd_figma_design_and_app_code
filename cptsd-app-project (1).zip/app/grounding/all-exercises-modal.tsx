"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Star, X } from "lucide-react"
import Link from "next/link"
import { addGroundingFavorite, removeGroundingFavorite, isGroundingFavorite } from "@/app/actions/user-actions"

interface Exercise {
  id: string
  title: string
  description: string
  category: string
  duration: string
  href: string
}

const allExercises: Exercise[] = [
  {
    id: "5-4-3-2-1",
    title: "5-4-3-2-1 Technique",
    description: "Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste",
    category: "Grounding",
    duration: "5 min",
    href: "/grounding/5-4-3-2-1",
  },
  {
    id: "box-breathing",
    title: "Box Breathing",
    description: "Breathe in for 4, hold for 4, out for 4, hold for 4",
    category: "Breathing",
    duration: "3 min",
    href: "/grounding/box-breathing",
  },
  {
    id: "body-scan",
    title: "Body Scan",
    description: "Focus attention on each part of your body from toes to head",
    category: "Body",
    duration: "10 min",
    href: "/grounding/body-scan",
  },
  {
    id: "safe-place",
    title: "Safe Place Visualisation",
    description: "Imagine a place where you feel completely safe and calm",
    category: "Visualisation",
    duration: "8 min",
    href: "#",
  },
  {
    id: "cold-water",
    title: "Cold Water Technique",
    description: "Hold ice or run cold water over your wrists to help ground yourself",
    category: "Grounding",
    duration: "2 min",
    href: "#",
  },
]

interface AllExercisesModalProps {
  onClose: () => void
}

export function AllExercisesModal({ onClose }: AllExercisesModalProps) {
  const [isFavorite, setIsFavorite] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState<Record<string, boolean>>({})

  useEffect(() => {
    const loadFavorites = async () => {
      const favorites: Record<string, boolean> = {}
      for (const exercise of allExercises) {
        try {
          const isFav = await isGroundingFavorite(exercise.title)
          favorites[exercise.id] = isFav
        } catch (error) {
          console.error("Error checking favorite:", error)
        }
      }
      setIsFavorite(favorites)
    }
    loadFavorites()
  }, [])

  const toggleFavorite = async (exercise: Exercise) => {
    setLoading((prev) => ({ ...prev, [exercise.id]: true }))
    try {
      if (isFavorite[exercise.id]) {
        await removeGroundingFavorite(exercise.title)
      } else {
        await addGroundingFavorite({
          exerciseName: exercise.title,
          exerciseDescription: exercise.description,
          category: exercise.category,
        })
      }
      setIsFavorite((prev) => ({
        ...prev,
        [exercise.id]: !prev[exercise.id],
      }))
    } catch (error) {
      console.error("Error toggling favorite:", error)
    } finally {
      setLoading((prev) => ({ ...prev, [exercise.id]: false }))
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-4">
          <h1 className="text-lg font-semibold text-foreground">All Grounding Exercises</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-10 w-10 text-foreground/60 hover:bg-foreground/10"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-3 pb-20">
        <div className="space-y-2">
          {allExercises.map((exercise) => (
            <Link
              key={exercise.id}
              href={exercise.href}
              onClick={(e) => {
                if (exercise.href === "#") {
                  e.preventDefault()
                }
              }}
              className="block rounded-lg border border-primary/50 bg-accent/10 p-3 transition-all hover:bg-accent/20 active:bg-accent/30"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className="text-xs text-foreground/70 mb-0.5">{exercise.category}</p>
                  <h4 className="text-sm font-semibold text-primary mb-0.5">
                    {exercise.title}
                  </h4>
                  <p className="text-xs text-foreground/80 leading-tight">
                    {exercise.description}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.preventDefault()
                    toggleFavorite(exercise)
                  }}
                  disabled={loading[exercise.id]}
                  className="flex-shrink-0 mt-0.5 transition-opacity hover:opacity-80 disabled:opacity-50"
                >
                  <Star
                    className={`h-4 w-4 ${
                      isFavorite[exercise.id]
                        ? "text-primary fill-primary"
                        : "text-foreground/40"
                    }`}
                  />
                </button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
