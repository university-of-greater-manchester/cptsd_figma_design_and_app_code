import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { SelfCompassionExercise } from "./self-compassion"

export const metadata = {
  title: "Self-Compassion",
  description: "Guided self-compassion exercise for kindness and healing",
}

export default async function SelfCompassionPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <SelfCompassionExercise />
}
