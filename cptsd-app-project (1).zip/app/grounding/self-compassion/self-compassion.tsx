"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { SideMenu } from "@/components/side-menu"
import { Menu } from "lucide-react"

const compassionPhrases = [
  "This moment is hard. That's real, and it's okay.",
  "Suffering is part of being human. You are not alone in this.",
  "You are doing the best you can with what you have right now.",
  "May I be gentle with myself today.",
  "May I give myself the kindness I would give someone I love.",
]

export function SelfCompassionExercise() {
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0)
  const [showButton, setShowButton] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [journalEntry, setJournalEntry] = useState("")
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const currentPhrase = compassionPhrases[currentPhraseIndex]

  const handlePhraseStart = () => {
    // 5-second delay before showing button
    setTimeout(() => {
      setShowButton(true)
    }, 5000)
  }

  const handleHearThis = () => {
    if (currentPhraseIndex < compassionPhrases.length - 1) {
      setCurrentPhraseIndex(currentPhraseIndex + 1)
      setShowButton(false)
      handlePhraseStart()
    } else {
      setIsComplete(true)
    }
  }

  // Initialize the first phrase's timer on mount
  useState(() => {
    handlePhraseStart()
  })

  if (isComplete) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background px-6 pb-20">
        <div className="text-center mb-8">
          <div className="mb-6 text-5xl">💝</div>
          <h2 className="text-2xl font-bold text-foreground">You showed up for yourself</h2>
          <p className="mt-3 text-base text-foreground/70">today.</p>
          <p className="text-base text-foreground/70">That matters.</p>
        </div>

        {/* Journal Entry */}
        <div className="w-full max-w-sm mb-6">
          <label className="block text-sm font-semibold text-foreground mb-2">
            One kind thing to remember:
          </label>
          <Textarea
            placeholder="Write something kind to yourself..."
            value={journalEntry}
            onChange={(e) => setJournalEntry(e.target.value)}
            className="min-h-20 resize-none text-sm rounded-lg bg-primary/10 border-primary/30 text-foreground placeholder:text-foreground/40"
          />
        </div>

        {/* Buttons */}
        <div className="space-y-2 w-full max-w-sm">
          <Button
            asChild
            className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg"
          >
            <Link href="/grounding">Do Another</Link>
          </Button>
          <Button
            asChild
            variant="outline"
            className="w-full h-11 border-primary text-primary hover:bg-primary/10 rounded-lg"
          >
            <Link href="/grounding">Return to Exercises</Link>
          </Button>
        </div>
      </div>
    )
  }

  const progressPercent = ((currentPhraseIndex + 1) / compassionPhrases.length) * 100

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            onClick={() => setIsMenuOpen(true)}
            variant="ghost"
            size="icon"
            className="text-foreground/70 hover:text-foreground hover:bg-foreground/5"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">Self-Compassion</h1>
          <BackButton fallbackRoute="/grounding" />
        </div>
        {/* Progress Bar */}
        <div className="h-1 w-full bg-primary/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-24">
        {/* Hand Illustration */}
        <div className="mb-8 text-6xl">🤍</div>

        {/* Phrase Container */}
        <div className="max-w-sm mb-8 text-center">
          <p className="text-xs font-medium text-foreground/60 uppercase tracking-wide mb-6">
            Step {currentPhraseIndex + 1} of {compassionPhrases.length}
          </p>
          <p className="text-2xl text-foreground font-semibold leading-relaxed mb-2">
            {currentPhrase}
          </p>
          <p className="text-xs text-foreground/60 mt-4">
            {!showButton && "Take a moment to let this in..."}
          </p>
        </div>

        {/* "I Hear This" Button - Appears After Delay */}
        {showButton && (
          <Button
            onClick={handleHearThis}
            className="h-11 px-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg font-semibold animate-fade-in"
          >
            {currentPhraseIndex === compassionPhrases.length - 1
              ? "I Hear This"
              : "I Hear This"}
          </Button>
        )}

        <style>{`
          @keyframes fadeIn {
            from {
              opacity: 0;
              transform: translateY(10px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          .animate-fade-in {
            animation: fadeIn 0.5s ease-out;
          }
        `}</style>
      </main>

      <SideMenu open={isMenuOpen} onOpenChange={setIsMenuOpen} />
    </div>
  )
}
