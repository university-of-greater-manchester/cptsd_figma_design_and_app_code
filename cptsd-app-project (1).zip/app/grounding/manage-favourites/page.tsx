import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { ManageFavouritesClient } from "./manage-favourites-client"

export default async function ManageFavouritesPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <ManageFavouritesClient />
}
