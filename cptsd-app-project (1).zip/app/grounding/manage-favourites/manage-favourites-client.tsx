"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Star, Menu } from "lucide-react"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { addGroundingFavorite, removeGroundingFavorite, getGroundingFavorites } from "@/app/actions/user-actions"

interface Exercise {
  id: string
  title: string
  category: string
  description: string
}

const allExercises: Exercise[] = [
  {
    id: "5-4-3-2-1",
    title: "5-4-3-2-1 Technique",
    category: "Grounding",
    description: "Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste",
  },
  {
    id: "box-breathing",
    title: "Box Breathing",
    category: "Breathing",
    description: "Breathe in for 4, hold for 4, out for 4, hold for 4",
  },
  {
    id: "body-scan",
    title: "Body Scan",
    category: "Body",
    description: "Focus attention on each part of your body from toes to head",
  },
  {
    id: "safe-place",
    title: "Safe Place Visualisation",
    category: "Visualisation",
    description: "Imagine a place where you feel completely safe and calm",
  },
  {
    id: "cold-water",
    title: "Cold Water Technique",
    category: "Grounding",
    description: "Hold ice or run cold water over your wrists to help ground yourself",
  },
  {
    id: "progressive-muscle",
    title: "Progressive Muscle Relaxation",
    category: "Body",
    description: "Systematically tense and release muscle groups throughout your body",
  },
  {
    id: "4-7-8-breathing",
    title: "4-7-8 Breathing",
    category: "Breathing",
    description: "Breathe in for 4, hold for 7, exhale for 8 to calm your nervous system",
  },
]

export function ManageFavouritesClient() {
  const [isFavorite, setIsFavorite] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState<Record<string, boolean>>({})

  useEffect(() => {
    const loadFavorites = async () => {
      try {
        const favorites = await getGroundingFavorites()
        const favoriteMap: Record<string, boolean> = {}
        
        allExercises.forEach((exercise) => {
          const isFav = favorites.some((fav: any) => {
            const favName = fav.exerciseName || fav.exercise_name
            return favName === exercise.title
          })
          favoriteMap[exercise.id] = isFav
        })
        
        setIsFavorite(favoriteMap)
      } catch (error) {
        console.error("Error loading favorites:", error)
      }
    }
    
    loadFavorites()
  }, [])

  const toggleFavorite = async (exercise: Exercise) => {
    setLoading((prev) => ({ ...prev, [exercise.id]: true }))
    try {
      if (isFavorite[exercise.id]) {
        await removeGroundingFavorite(exercise.title)
      } else {
        await addGroundingFavorite({
          exerciseName: exercise.title,
          exerciseDescription: exercise.description,
          category: exercise.category,
        })
      }
      setIsFavorite((prev) => ({
        ...prev,
        [exercise.id]: !prev[exercise.id],
      }))
    } catch (error) {
      console.error("Error toggling favorite:", error)
    } finally {
      setLoading((prev) => ({ ...prev, [exercise.id]: false }))
    }
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-3 px-4">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 text-foreground/60 hover:bg-foreground/10"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <BackButton fallbackRoute="/grounding" />
          <h1 className="text-lg font-semibold text-foreground">Manage Favourites</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-3 flex flex-col pb-20">
        {/* Instructions */}
        <p className="text-xs text-foreground/70 mb-3">
          Tap the star icon to add or remove exercises from your favourites.
        </p>

        {/* Exercises List */}
        <div className="space-y-2">
          {allExercises.map((exercise) => (
            <div
              key={exercise.id}
              className="flex items-center justify-between rounded-lg border border-primary/30 bg-primary/5 p-3 transition-all hover:bg-primary/10"
            >
              <div>
                <h4 className="text-sm font-semibold text-primary">{exercise.title}</h4>
                <p className="text-xs text-foreground/70">{exercise.category}</p>
              </div>
              <button
                onClick={() => toggleFavorite(exercise)}
                disabled={loading[exercise.id]}
                className="flex-shrink-0 transition-opacity hover:opacity-80 disabled:opacity-50"
              >
                <Star
                  className={`h-5 w-5 ${
                    isFavorite[exercise.id]
                      ? "text-primary fill-primary"
                      : "text-foreground/40"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
