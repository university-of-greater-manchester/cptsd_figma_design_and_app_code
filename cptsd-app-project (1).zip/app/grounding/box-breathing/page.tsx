import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { BoxBreathingExercise } from "./box-breathing"

export const metadata = {
  title: "Box Breathing",
  description: "Guided box breathing exercise for grounding",
}

export default async function BoxBreathingPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <BoxBreathingExercise />
}
