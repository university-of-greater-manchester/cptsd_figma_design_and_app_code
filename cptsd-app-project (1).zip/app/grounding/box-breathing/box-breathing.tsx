"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { SideMenu } from "@/components/side-menu"
import { Menu } from "lucide-react"

type Phase = "inhale" | "hold-1" | "exhale" | "hold-2"

export function BoxBreathingExercise() {
  const [phase, setPhase] = useState<Phase>("inhale")
  const [countdown, setCountdown] = useState(4)
  const [isRunning, setIsRunning] = useState(true)
  const [cycle, setCycle] = useState(1)
  const [isComplete, setIsComplete] = useState(false)
  const [boxProgress, setBoxProgress] = useState(0) // 0-4 for which side is drawing
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const phaseLabels = {
    inhale: "Breathe In",
    "hold-1": "Hold",
    exhale: "Breathe Out",
    "hold-2": "Hold",
  }

  const phaseDescriptions = {
    inhale: "Watch the line draw. Breathe in slowly.",
    "hold-1": "Hold your breath gently.",
    exhale: "Watch the line draw. Breathe out slowly.",
    "hold-2": "Hold for a moment.",
  }

  useEffect(() => {
    if (!isRunning || isComplete) return

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev > 1) {
          return prev - 1
        } else {
          // Move to next phase
          setPhase((currentPhase) => {
            let nextPhase: Phase
            if (currentPhase === "inhale") {
              nextPhase = "hold-1"
              setBoxProgress(1)
            } else if (currentPhase === "hold-1") {
              nextPhase = "exhale"
              setBoxProgress(2)
            } else if (currentPhase === "exhale") {
              nextPhase = "hold-2"
              setBoxProgress(3)
            } else {
              nextPhase = "inhale"
              setBoxProgress(0)
              setCycle((c) => {
                if (c >= 3) {
                  setIsComplete(true)
                  return c
                }
                return c + 1
              })
            }
            return nextPhase
          })
          return 4
        }
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [isRunning, isComplete])

  if (isComplete) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background px-6 pb-20">
        <div className="text-center">
          <div className="mb-6 text-5xl">✨</div>
          <h2 className="text-2xl font-bold text-foreground">Well done.</h2>
          <p className="mt-3 text-base text-foreground/70">Your body is safe right now.</p>
          <div className="mt-8 space-y-2">
            <Button
              asChild
              className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg"
            >
              <Link href="/grounding">Do Another</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="w-full h-11 border-primary text-primary hover:bg-primary/10 rounded-lg"
            >
              <Link href="/grounding">Return to Exercises</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setIsMenuOpen(true)}
            variant="ghost"
            size="icon"
            className="text-foreground/70 hover:text-foreground hover:bg-foreground/5"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">Box Breathing</h1>
          <BackButton fallbackRoute="/grounding" />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-24">
        {/* Animated Box with Counter Inside */}
        <div className="relative flex items-center justify-center mb-8">
          <svg
            width="180"
            height="180"
            viewBox="0 0 180 180"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Top line (inhale) */}
            <line
              x1="20"
              y1="20"
              x2="160"
              y2="20"
              stroke="#b5a47d"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={boxProgress >= 1 ? "140" : "0"}
              strokeDashoffset="0"
              style={{
                animation:
                  phase === "inhale" && boxProgress === 0
                    ? "drawLine 4s ease-in-out forwards"
                    : "none",
              }}
            />
            {/* Right line (hold) */}
            <line
              x1="160"
              y1="20"
              x2="160"
              y2="160"
              stroke="#b5a47d"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={boxProgress >= 2 ? "140" : "0"}
              strokeDashoffset="0"
              style={{
                animation:
                  phase === "hold-1" && boxProgress === 1
                    ? "drawLine 4s ease-in-out forwards"
                    : "none",
              }}
            />
            {/* Bottom line (exhale) */}
            <line
              x1="160"
              y1="160"
              x2="20"
              y2="160"
              stroke="#b5a47d"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={boxProgress >= 3 ? "140" : "0"}
              strokeDashoffset="0"
              style={{
                animation:
                  phase === "exhale" && boxProgress === 2
                    ? "drawLine 4s ease-in-out forwards"
                    : "none",
              }}
            />
            {/* Left line (hold) */}
            <line
              x1="20"
              y1="160"
              x2="20"
              y2="20"
              stroke="#b5a47d"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={boxProgress >= 4 ? "140" : "0"}
              strokeDashoffset="0"
              style={{
                animation:
                  phase === "hold-2" && boxProgress === 3
                    ? "drawLine 4s ease-in-out forwards"
                    : "none",
              }}
            />

            <style>{`
              @keyframes drawLine {
                from {
                  stroke-dashoffset: 140;
                }
                to {
                  stroke-dashoffset: 0;
                }
              }
            `}</style>
          </svg>

          {/* Counter Inside Box */}
          <div className="absolute flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 border border-primary">
            <span className="text-3xl font-bold text-primary">{countdown}</span>
          </div>
        </div>

        {/* Phase Label */}
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          {phaseLabels[phase]}
        </h2>
        <p className="text-center text-sm text-foreground/70 mb-6 max-w-xs">
          {phaseDescriptions[phase]}
        </p>

        {/* Cycle Indicator */}
        <div className="flex gap-2 mb-8">
          {[1, 2, 3, 4].map((c) => (
            <div
              key={c}
              className={`h-2 rounded-full transition-all ${
                c <= cycle ? "w-6 bg-primary" : "w-2 bg-primary/30"
              }`}
            />
          ))}
        </div>

        {/* Pause/Resume Button */}
        <Button
          onClick={() => setIsRunning(!isRunning)}
          variant="outline"
          className="border-primary text-primary hover:bg-primary/10 rounded-lg"
        >
          {isRunning ? "Pause" : "Resume"}
        </Button>
      </main>

      {/* Footer Text */}
      <div className="flex-shrink-0 text-center px-4 py-4 text-xs text-foreground/50">
        Cycle {cycle} of 3 • Duration: ~3 min
      </div>

      <SideMenu open={isMenuOpen} onOpenChange={setIsMenuOpen} />
    </div>
  )
}
