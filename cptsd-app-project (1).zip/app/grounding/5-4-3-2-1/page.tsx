import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { GroundingExercise } from "./grounding-5-4-3-2-1"

export const metadata = {
  title: "5-4-3-2-1 Grounding",
  description: "Guided 5-4-3-2-1 grounding exercise using your senses",
}

export default async function Grounding54321Page() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <GroundingExercise />
}
