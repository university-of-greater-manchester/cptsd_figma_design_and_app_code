"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { SideMenu } from "@/components/side-menu"
import { Menu } from "lucide-react"

type Sense = "sight" | "touch" | "hear" | "smell" | "taste"

const senseConfig: Record<
  Sense,
  { label: string; count: number; prompt: string; description: string }
> = {
  sight: {
    label: "See",
    count: 5,
    prompt: "Name 5 things you can see",
    description: "Look around and notice 5 things in your space.",
  },
  touch: {
    label: "Feel",
    count: 4,
    prompt: "Notice 4 things you can feel",
    description: "Your chair, feet, fabric, skin, air on your face.",
  },
  hear: {
    label: "Hear",
    count: 3,
    prompt: "Find 3 sounds around you",
    description: "Listen for near and far sounds.",
  },
  smell: {
    label: "Smell",
    count: 2,
    prompt: "Notice 2 smells",
    description: "Even faint ones count.",
  },
  taste: {
    label: "Taste",
    count: 1,
    prompt: "What taste is in your mouth?",
    description: "Notice without judgment.",
  },
}

export function GroundingExercise() {
  const senseOrder: Sense[] = ["sight", "touch", "hear", "smell", "taste"]
  const [currentSenseIndex, setCurrentSenseIndex] = useState(0)
  const [tappedItems, setTappedItems] = useState<number[]>([])
  const [isComplete, setIsComplete] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const currentSense = senseOrder[currentSenseIndex] as Sense
  const config = senseConfig[currentSense]
  const tappedCount = tappedItems.length
  const isAllTapped = tappedCount === config.count

  const handleTap = () => {
    if (tappedCount < config.count) {
      setTappedItems([...tappedItems, tappedCount])
    }
  }

  const handleNext = () => {
    if (currentSenseIndex < senseOrder.length - 1) {
      setCurrentSenseIndex(currentSenseIndex + 1)
      setTappedItems([])
    } else {
      setIsComplete(true)
    }
  }

  if (isComplete) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background px-6 pb-20">
        <div className="text-center">
          <div className="mb-6 text-5xl">🌿</div>
          <h2 className="text-2xl font-bold text-foreground">You are here.</h2>
          <p className="mt-2 text-lg text-foreground/70">You are present.</p>
          <p className="text-lg text-foreground/70">You are safe.</p>
          <div className="mt-8 space-y-2">
            <Button
              asChild
              className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg"
            >
              <Link href="/grounding">Do Another</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="w-full h-11 border-primary text-primary hover:bg-primary/10 rounded-lg"
            >
              <Link href="/grounding">Return to Exercises</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const progressPercent = ((currentSenseIndex + 1) / senseOrder.length) * 100

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            onClick={() => setIsMenuOpen(true)}
            variant="ghost"
            size="icon"
            className="text-foreground/70 hover:text-foreground hover:bg-foreground/5"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">5-4-3-2-1 Grounding</h1>
          <BackButton fallbackRoute="/grounding" />
        </div>
        {/* Progress Bar */}
        <div className="h-1 w-full bg-primary/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-24">
        {/* Sense Label */}
        <div className="mb-4 text-center">
          <p className="text-sm font-medium text-foreground/60 uppercase tracking-wide">
            Step {currentSenseIndex + 1} of {senseOrder.length}
          </p>
          <h2 className="mt-2 text-3xl font-bold text-foreground">{config.label}</h2>
        </div>

        {/* Prompt */}
        <p className="text-xl text-foreground font-semibold text-center mb-4 max-w-sm">
          {config.prompt}
        </p>
        <p className="text-sm text-foreground/70 text-center mb-8 max-w-sm">
          {config.description}
        </p>

        {/* Tappable Circles */}
        <div className="flex justify-center gap-4 mb-8 flex-wrap max-w-sm">
          {Array.from({ length: config.count }).map((_, index) => (
            <button
              key={index}
              onClick={handleTap}
              disabled={index < tappedCount}
              className={`h-16 w-16 rounded-full border-2 transition-all ${
                index < tappedCount
                  ? "bg-primary border-primary text-primary-foreground"
                  : "border-primary/30 bg-primary/5 hover:border-primary/50 hover:shadow-md"
              }`}
            >
              {index < tappedCount && (
                <span className="text-2xl font-bold">✓</span>
              )}
            </button>
          ))}
        </div>

        {/* Tapped Count */}
        <p className="text-sm text-foreground/70 mb-8">
          {tappedCount} of {config.count} noticed
        </p>

        {/* Next Button */}
        <Button
          onClick={handleNext}
          disabled={!isAllTapped}
          className={`h-11 px-8 rounded-lg font-semibold transition-all ${
            isAllTapped
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-primary/30 text-primary/50 cursor-not-allowed"
          }`}
        >
          {currentSenseIndex === senseOrder.length - 1 ? "Finish" : "Next Sense"}
        </Button>
      </main>

      <SideMenu open={isMenuOpen} onOpenChange={setIsMenuOpen} />
    </div>
  )
}
