import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { MoreSupportToolsClient } from "./more-support-tools-client"

export default async function MoreSupportToolsPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <MoreSupportToolsClient />
}
