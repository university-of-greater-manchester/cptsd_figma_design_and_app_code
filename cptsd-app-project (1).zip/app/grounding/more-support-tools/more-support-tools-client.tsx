"use client"

import { Button } from "@/components/ui/button"
import { Wind, Music, Palette, BookOpen, Sun, Moon, Menu } from "lucide-react"
import Link from "next/link"
import { BackButton } from "@/components/back-button"

interface SelfCareCategory {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  duration: string
  href: string
}

const selfCareActivities: SelfCareCategory[] = [
  {
    id: "breathing",
    title: "Breathing Exercises",
    description: "Guided breathing to reduce anxiety",
    icon: <Wind className="h-8 w-8" />,
    duration: "5-10 min",
    href: "#",
  },
  {
    id: "meditation",
    title: "Meditation",
    description: "Calming meditation sessions",
    icon: <Music className="h-8 w-8" />,
    duration: "10-20 min",
    href: "#",
  },
  {
    id: "grounding",
    title: "Grounding Techniques",
    description: "5-4-3-2-1 sensory grounding",
    icon: <Palette className="h-8 w-8" />,
    duration: "5 min",
    href: "/grounding",
  },
  {
    id: "morning",
    title: "Morning Routine",
    description: "Start your day mindfully",
    icon: <Sun className="h-8 w-8" />,
    duration: "15 min",
    href: "#",
  },
  {
    id: "sleep",
    title: "Sleep Preparation",
    description: "Wind down for better sleep",
    icon: <Moon className="h-8 w-8" />,
    duration: "20 min",
    href: "#",
  },
]

export function MoreSupportToolsClient() {
  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-3 px-4">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 text-foreground/60 hover:bg-foreground/10"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <BackButton fallbackRoute="/grounding" />
          <h1 className="text-lg font-semibold text-foreground">Self-Care Activities</h1>
        </div>
      </header>

      <main className="flex-1 overflow-hidden px-4 py-2 flex flex-col pb-20">
        {/* Intro Text */}
        <div className="mb-1.5 flex-shrink-0">
          <p className="text-xs text-foreground/80 leading-tight">
            Explore various self-care activities to support your mental health and wellbeing.
          </p>
        </div>

        {/* Activities Grid */}
        <div className="space-y-1.5">
          {selfCareActivities.map((activity) => (
            <Link
              key={activity.id}
              href={activity.href}
              onClick={(e) => {
                if (activity.href === "#") {
                  e.preventDefault()
                }
              }}
              className="block rounded-lg border border-primary/30 bg-accent/20 p-2 transition-all hover:bg-accent/30 active:bg-accent/40"
            >
              <div className="flex items-start gap-2">
                <div className="flex-shrink-0 text-primary/70">{activity.icon}</div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xs font-semibold text-primary">{activity.title}</h3>
                  <p className="text-xs text-foreground/70 leading-tight">{activity.description}</p>
                  <span className="inline-block mt-0.5 px-2 py-0.5 bg-primary/20 text-primary rounded text-xs font-semibold">
                    {activity.duration}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
