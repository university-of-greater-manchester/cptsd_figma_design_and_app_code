"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Wind, Eye, Ear, Hand, Heart, Star, Menu } from "lucide-react"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { AllExercisesModal } from "./all-exercises-modal"
import { getGroundingFavorites } from "@/app/actions/user-actions"

interface Favorite {
  id: number
  user_id: string
  exercise_name: string
  exercise_description: string
  category: string
  order_index: number
  created_at: string
}

const staticExercises = [
  {
    id: "box-breathing",
    title: "Box Breathing",
    description: "Breathe in for 4, hold for 4, out for 4, hold for 4",
    icon: Wind,
    duration: "3 min",
    href: "/grounding/box-breathing",
  },
  {
    id: "5-4-3-2-1",
    title: "5-4-3-2-1 Technique",
    description: "Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste",
    icon: Eye,
    duration: "5 min",
    href: "/grounding/5-4-3-2-1",
  },
  {
    id: "body-scan",
    title: "Body Scan",
    description: "Focus attention on each part of your body from toes to head",
    icon: Hand,
    duration: "10 min",
    href: "/grounding/body-scan",
  },
  {
    id: "sounds",
    title: "Sound Awareness",
    description: "Focus on sounds around you",
    icon: Ear,
    duration: "3 min",
    href: "/grounding/sound-awareness",
  },
  {
    id: "self-compassion",
    title: "Self-Compassion",
    description: "Speak kindly to yourself",
    icon: Heart,
    duration: "5 min",
    href: "/grounding/self-compassion",
  },
]

export function GroundingClient() {
  const [showAllExercises, setShowAllExercises] = useState(false)
  const [favorites, setFavorites] = useState<Favorite[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadFavorites = async () => {
      try {
        const data = await getGroundingFavorites()
        setFavorites(data)
      } catch (error) {
        console.error("Error loading favorites:", error)
      } finally {
        setLoading(false)
      }
    }
    loadFavorites()

    // Refresh favorites when the page comes into focus
    const handleFocus = () => {
      loadFavorites()
    }

    window.addEventListener("focus", handleFocus)
    return () => window.removeEventListener("focus", handleFocus)
  }, [])

  // Get favorites to display (first 4)
  const displayedFavorites = favorites.slice(0, 4)

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex h-16 items-center gap-3 px-4">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 text-foreground/60 hover:bg-foreground/10"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <BackButton fallbackRoute="/dashboard" />
          <h1 className="text-lg font-semibold text-foreground">Pause & Support</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-3 flex flex-col pb-20">
        {/* Support Section */}
        <div className="rounded-lg border border-primary/40 bg-primary/5 p-3 mb-3 flex-shrink-0">
          <p className="text-xs text-foreground/70 mb-1">Support is available:</p>
          <Link href="#" className="text-sm font-semibold text-primary hover:underline">
            Get support in general
          </Link>
        </div>

        {/* Grounding Techniques Description */}
        <div className="mb-3 flex-shrink-0">
          <h2 className="text-base font-semibold text-primary mb-2">Grounding Techniques</h2>
          <p className="text-sm text-foreground/80 leading-snug">
            These tools can help you steady your thoughts, body, or emotions when things feel intense.
          </p>
        </div>

        {/* Favorites Section Header */}
        <h3 className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-3 flex-shrink-0">
          Favourites
        </h3>

        {/* Favorites Cards */}
        <div className="space-y-3 mb-3">
          {loading ? (
            <p className="text-xs text-foreground/60">Loading favorites...</p>
          ) : displayedFavorites.length > 0 ? (
            displayedFavorites.map((favorite, index) => (
              <div
                key={favorite.id}
                className="block rounded-lg border border-primary/40 bg-primary/10 p-3 transition-all hover:bg-primary/20 active:bg-primary/30"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <p className="text-xs text-foreground/70 mb-1">Favourite {index + 1}</p>
                    <h4 className="text-sm font-semibold text-primary mb-1">
                      {(favorite as any).exerciseName}
                    </h4>
                    <p className="text-xs text-foreground/80 leading-snug">
                      {(favorite as any).exerciseDescription}
                    </p>
                  </div>
                  <Star className="h-5 w-5 text-primary fill-primary flex-shrink-0 mt-0.5" />
                </div>
              </div>
            ))
          ) : (
            <p className="text-xs text-foreground/60">
              No favorites yet. Add some from manage favorites.
            </p>
          )}
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={() => setShowAllExercises(true)}
            className="w-full h-11 bg-accent/80 hover:bg-accent/90 text-foreground rounded-lg text-sm font-semibold border-0"
          >
            <span className="mr-2">≡</span>
            All Grounding Exercises
          </Button>
          <Button
            asChild
            variant="outline"
            className="w-full h-11 border-primary/40 text-primary hover:bg-primary/10 rounded-lg text-sm font-semibold"
          >
            <Link href="/grounding/manage-favourites">
              <span className="mr-2">⚖</span>
              Manage Favourites
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            className="w-full h-11 border-primary/40 text-primary hover:bg-primary/10 rounded-lg text-sm font-semibold"
          >
            <Link href="/grounding/more-support-tools">
              <span className="mr-2">♡</span>
              More Support Tools
            </Link>
          </Button>
        </div>
      </main>

      {/* All Exercises Modal */}
      {showAllExercises && <AllExercisesModal onClose={() => setShowAllExercises(false)} />}
    </div>
  )
}
