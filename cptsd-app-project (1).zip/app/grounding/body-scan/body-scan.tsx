"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { SideMenu } from "@/components/side-menu"
import { Menu } from "lucide-react"

const bodyRegions = [
  { id: "head", label: "Head & Face", prompt: "Is there tension in your jaw or forehead? Just notice." },
  { id: "neck", label: "Neck & Shoulders", prompt: "Are your shoulders lifted? Let them drop gently." },
  { id: "chest", label: "Chest", prompt: "Notice your breath here. No need to change it." },
  { id: "arms", label: "Arms & Hands", prompt: "Feel the weight of your arms. Are your fists clenched?" },
  { id: "stomach", label: "Stomach", prompt: "Notice if your belly is tight. Breathe into it softly." },
  { id: "hips", label: "Hips & Lower Back", prompt: "Let this area feel heavy and supported." },
  { id: "legs", label: "Legs", prompt: "Feel your legs against the surface beneath you." },
  { id: "feet", label: "Feet", prompt: "Feel the ground. You are supported." },
]

export function BodyScanExercise() {
  const [currentRegionIndex, setCurrentRegionIndex] = useState(0)
  const [isAutoAdvancing, setIsAutoAdvancing] = useState(true)
  const [isComplete, setIsComplete] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(60)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    if (!isAutoAdvancing || isComplete) return

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev > 1) {
          return prev - 1
        } else {
          // Auto advance to next region
          if (currentRegionIndex < bodyRegions.length - 1) {
            setCurrentRegionIndex(currentRegionIndex + 1)
            setTimeRemaining(60)
          } else {
            setIsComplete(true)
          }
          return 60
        }
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [isAutoAdvancing, currentRegionIndex, isComplete])

  const currentRegion = bodyRegions[currentRegionIndex]
  const progressPercent = ((currentRegionIndex + 1) / bodyRegions.length) * 100

  const handleContinue = () => {
    if (currentRegionIndex < bodyRegions.length - 1) {
      setCurrentRegionIndex(currentRegionIndex + 1)
      setTimeRemaining(60)
    } else {
      setIsComplete(true)
    }
  }

  if (isComplete) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background px-6 pb-20">
        <div className="text-center">
          <div className="mb-6 text-5xl">💙</div>
          <h2 className="text-2xl font-bold text-foreground">You just checked in</h2>
          <p className="mt-3 text-base text-foreground/70">with yourself.</p>
          <p className="mt-2 text-base text-foreground/70">That takes courage.</p>
          <div className="mt-8 space-y-2">
            <Button
              asChild
              className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg"
            >
              <Link href="/grounding">Do Another</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="w-full h-11 border-primary text-primary hover:bg-primary/10 rounded-lg"
            >
              <Link href="/grounding">Return to Exercises</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            onClick={() => setIsMenuOpen(true)}
            variant="ghost"
            size="icon"
            className="text-foreground/70 hover:text-foreground hover:bg-foreground/5"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">Body Scan</h1>
          <BackButton fallbackRoute="/grounding" />
        </div>
        {/* Progress Bar */}
        <div className="h-1 w-full bg-primary/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-24">
        {/* Step Counter */}
        <p className="text-sm font-medium text-foreground/60 uppercase tracking-wide mb-4">
          Region {currentRegionIndex + 1} of {bodyRegions.length}
        </p>

        {/* Body Outline Visualization */}
        <svg
          width="120"
          height="200"
          viewBox="0 0 120 200"
          className="mb-8"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Head */}
          <circle
            cx="60"
            cy="30"
            r="15"
            fill={currentRegionIndex === 0 ? "#b5a47d" : "#b5a47d33"}
            className="transition-colors duration-500"
          />
          {/* Neck */}
          <line x1="60" y1="45" x2="60" y2="55" stroke="#b5a47d66" strokeWidth="3" />
          {/* Torso */}
          <rect
            x="40"
            y="55"
            width="40"
            height="45"
            rx="8"
            fill={
              currentRegionIndex === 1
                ? "#b5a47d"
                : currentRegionIndex === 2
                  ? "#b5a47d"
                  : "#b5a47d33"
            }
            className="transition-colors duration-500"
          />
          {/* Arms */}
          <line x1="40" y1="65" x2="10" y2="60" stroke="#b5a47d66" strokeWidth="3" />
          <line x1="80" y1="65" x2="110" y2="60" stroke="#b5a47d66" strokeWidth="3" />
          {/* Hips */}
          <ellipse
            cx="60"
            cy="110"
            rx="22"
            ry="15"
            fill={currentRegionIndex === 5 ? "#b5a47d" : "#b5a47d33"}
            className="transition-colors duration-500"
          />
          {/* Legs */}
          <line
            x1="50"
            y1="125"
            x2="48"
            y2="180"
            stroke={currentRegionIndex === 6 ? "#b5a47d" : "#b5a47d66"}
            strokeWidth="3"
            className="transition-colors duration-500"
          />
          <line
            x1="70"
            y1="125"
            x2="72"
            y2="180"
            stroke={currentRegionIndex === 6 ? "#b5a47d" : "#b5a47d66"}
            strokeWidth="3"
            className="transition-colors duration-500"
          />
          {/* Feet */}
          <ellipse
            cx="48"
            cy="185"
            rx="8"
            ry="4"
            fill={currentRegionIndex === 7 ? "#b5a47d" : "#b5a47d33"}
            className="transition-colors duration-500"
          />
          <ellipse
            cx="72"
            cy="185"
            rx="8"
            ry="4"
            fill={currentRegionIndex === 7 ? "#b5a47d" : "#b5a47d33"}
            className="transition-colors duration-500"
          />
        </svg>

        {/* Region Label */}
        <h2 className="text-2xl font-bold text-foreground mb-4">{currentRegion.label}</h2>

        {/* Prompt */}
        <p className="text-base text-foreground/70 text-center max-w-sm mb-8 leading-relaxed">
          {currentRegion.prompt}
        </p>

        {/* Auto-Advance Toggle */}
        <button
          onClick={() => setIsAutoAdvancing(!isAutoAdvancing)}
          className="mb-8 text-xs text-foreground/60 hover:text-foreground underline"
        >
          {isAutoAdvancing ? "Click to pause auto-advance" : "Click to enable auto-advance"}
        </button>

        {/* Time Remaining / Continue Button */}
        {isAutoAdvancing ? (
          <div className="text-center">
            <p className="text-3xl font-bold text-primary mb-2">{timeRemaining}</p>
            <p className="text-xs text-foreground/60">seconds remaining</p>
          </div>
        ) : (
          <Button
            onClick={handleContinue}
            className="h-11 px-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg font-semibold"
          >
            {currentRegionIndex === bodyRegions.length - 1 ? "Finish" : "Continue"}
          </Button>
        )}
      </main>

      <SideMenu open={isMenuOpen} onOpenChange={setIsMenuOpen} />
    </div>
  )
}
