import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { BodyScanExercise } from "./body-scan"

export const metadata = {
  title: "Body Scan",
  description: "Guided body scan meditation for awareness and grounding",
}

export default async function BodyScanPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <BodyScanExercise />
}
