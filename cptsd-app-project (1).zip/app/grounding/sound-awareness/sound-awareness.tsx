"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/back-button"
import { SideMenu } from "@/components/side-menu"
import { Menu } from "lucide-react"

const soundPrompts = [
  "Just listen. Don't label anything yet. Let sounds wash over you.",
  "Notice the furthest sound you can hear.",
  "Find a sound that's closer — maybe in the same room.",
  "Notice the nearest sound. Maybe your own breath.",
  "Now hear all three layers at once — far, near, closest.",
  "Let sound remind you: the present moment is happening right now.",
]

export function SoundAwarenessExercise() {
  const [currentPromptIndex, setCurrentPromptIndex] = useState(0)
  const [isAutoAdvancing, setIsAutoAdvancing] = useState(true)
  const [timeRemaining, setTimeRemaining] = useState(30)
  const [isComplete, setIsComplete] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    if (!isAutoAdvancing || isComplete) return

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev > 1) {
          return prev - 1
        } else {
          // Auto advance to next prompt
          if (currentPromptIndex < soundPrompts.length - 1) {
            setCurrentPromptIndex(currentPromptIndex + 1)
            setTimeRemaining(30)
          } else {
            setIsComplete(true)
          }
          return 30
        }
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [isAutoAdvancing, currentPromptIndex, isComplete])

  const progressPercent = ((currentPromptIndex + 1) / soundPrompts.length) * 100

  const handleNext = () => {
    if (currentPromptIndex < soundPrompts.length - 1) {
      setCurrentPromptIndex(currentPromptIndex + 1)
      setTimeRemaining(30)
    } else {
      setIsComplete(true)
    }
  }

  if (isComplete) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background px-6 pb-20">
        <div className="text-center">
          <div className="mb-6 text-5xl">🌙</div>
          <h2 className="text-2xl font-bold text-foreground">The world around you</h2>
          <p className="mt-2 text-lg text-foreground/70">is steady.</p>
          <p className="text-lg text-foreground/70">And so are you.</p>
          <div className="mt-8 space-y-2">
            <Button
              asChild
              className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg"
            >
              <Link href="/grounding">Do Another</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="w-full h-11 border-primary text-primary hover:bg-primary/10 rounded-lg"
            >
              <Link href="/grounding">Return to Exercises</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            onClick={() => setIsMenuOpen(true)}
            variant="ghost"
            size="icon"
            className="text-foreground/70 hover:text-foreground hover:bg-foreground/5"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-foreground">Sound Awareness</h1>
          <BackButton fallbackRoute="/grounding" />
        </div>
        {/* Progress Bar */}
        <div className="h-1 w-full bg-primary/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pb-24 relative">
        {/* Animated Pulsing Circle */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-40 h-40">
            {/* Outer pulse */}
            <div
              className="absolute inset-0 rounded-full border-2 border-primary opacity-30"
              style={{
                animation: "pulse 3s ease-in-out infinite",
              }}
            />
            {/* Middle pulse */}
            <div
              className="absolute inset-4 rounded-full border-2 border-primary opacity-20"
              style={{
                animation: "pulse 3s ease-in-out 0.5s infinite",
              }}
            />
            {/* Inner circle */}
            <div className="absolute inset-8 rounded-full bg-primary opacity-20" />
          </div>
        </div>

        {/* Step Counter */}
        <p className="text-xs font-medium text-foreground/60 uppercase tracking-wide mb-8 relative z-10">
          Step {currentPromptIndex + 1} of {soundPrompts.length}
        </p>

        {/* Prompt Text */}
        <p className="text-xl text-foreground text-center max-w-sm mb-12 leading-relaxed font-light relative z-10">
          {soundPrompts[currentPromptIndex]}
        </p>

        {/* Pause/Resume Toggle */}
        <button
          onClick={() => setIsAutoAdvancing(!isAutoAdvancing)}
          className="mb-8 text-xs text-foreground/60 hover:text-foreground underline relative z-10"
        >
          {isAutoAdvancing ? "Pause" : "Resume"}
        </button>

        {/* Time or Continue Button */}
        {isAutoAdvancing ? (
          <div className="text-center relative z-10">
            <p className="text-4xl font-light text-primary mb-2">{timeRemaining}</p>
            <p className="text-xs text-foreground/60">seconds</p>
          </div>
        ) : (
          <Button
            onClick={handleNext}
            className="h-11 px-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg font-semibold relative z-10"
          >
            {currentPromptIndex === soundPrompts.length - 1 ? "Finish" : "Next"}
          </Button>
        )}
      </main>

      <SideMenu open={isMenuOpen} onOpenChange={setIsMenuOpen} />
    </div>
  )
}
