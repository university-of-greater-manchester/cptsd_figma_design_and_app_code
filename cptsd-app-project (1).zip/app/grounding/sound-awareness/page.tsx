import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { SoundAwarenessExercise } from "./sound-awareness"

export const metadata = {
  title: "Sound Awareness",
  description: "Guided sound awareness meditation for mindfulness",
}

export default async function SoundAwarenessPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return <SoundAwarenessExercise />
}
