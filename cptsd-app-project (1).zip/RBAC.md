# RBAC (Role-Based Access Control) System

This document explains the three-layer RBAC enforcement system implemented in the CPTSD Toolkit app.

## Overview

The app uses a comprehensive RBAC system with three layers of enforcement:

1. **Layer 1: Authorization** - Check if user has permission before performing action
2. **Layer 2: Enforcement** - Protect routes and data access based on roles/permissions
3. **Layer 3: Audit Logging** - Log all actions for compliance and security

## Database Schema

### Core Tables

**role** - Stores role definitions with hierarchy levels
- `id` - Primary key
- `name` - Unique role name (admin, therapist, user)
- `description` - Role description
- `level` - Hierarchy level (1=user, 2=therapist, 3=admin)

**permission** - Stores granular permissions
- `id` - Primary key
- `name` - Unique permission name (e.g., journal:create)
- `resource` - Resource type (journal, profile, users, audit)
- `action` - Action type (create, read, update, delete, manage)

**role_permission** - Junction table linking roles to permissions
- `role_id` - Foreign key to role
- `permission_id` - Foreign key to permission

**user_role** - Junction table linking users to roles
- `user_id` - Foreign key to user
- `role_id` - Foreign key to role
- `granted_by` - Admin who granted the role
- `granted_at` - Timestamp

**audit_log** - Stores all user actions for compliance
- `user_id` - User who performed action
- `role` - User's role at time of action
- `action` - Action performed (create_journal, update_profile, etc)
- `resource` - Resource affected (journal, profile, users)
- `resource_id` - ID of resource affected
- `details` - JSON details of the action
- `ip_address` - IP address of request
- `user_agent` - User agent string

## Default Roles & Permissions

### User Role (Level 1)
- Can create own journal entries
- Can read own journal entries
- Can update own journal entries
- Can delete own journal entries
- Can read own profile
- Can update own profile

### Therapist Role (Level 2)
- Can read all users' journal entries
- Can read all users' profiles
- Can view audit logs

### Admin Role (Level 3)
- Full system access
- Can manage users and roles
- Can view all audit logs
- Can delete users

## Usage

### Layer 1: Authorization - Check Permissions

```typescript
import { checkPermission } from "@/lib/rbac"

// Check if user has permission (returns boolean)
const hasPermission = await checkPermission(userId, "journal:create")
if (!hasPermission) {
  throw new Error("Unauthorized")
}
```

### Layer 2: Enforcement - Protect Actions

```typescript
import { enforcePermission } from "@/lib/rbac"

// Enforce permission (throws if unauthorized)
await enforcePermission(userId, "profile:update")
```

### Layer 3: Audit Logging - Log Actions

```typescript
import { logAuditTrail } from "@/lib/rbac"

// Log the action for compliance
await logAuditTrail(
  userId,
  "create_journal",
  "journal",
  journalId,
  { title, mood },
  ipAddress,
  userAgent
)
```

### Protected Server Actions

All server actions in `/app/actions/` should follow this pattern:

```typescript
"use server"

import { enforcePermission, logAuditTrail } from "@/lib/rbac"

export async function createJournal(data: JournalData) {
  const userId = await getUserId()
  const reqInfo = await getRequest()

  // Layer 2: Enforce permission
  await enforcePermission(userId, "journal:create")

  // Perform action
  const result = await db.insert(journalEntry).values({ ...data, userId })

  // Layer 3: Audit log
  await logAuditTrail(
    userId,
    "create_journal",
    "journal",
    result[0].id,
    data,
    reqInfo.ipAddress,
    reqInfo.userAgent
  )

  return result
}
```

### Protected Routes

Use the `withProtectedPage` wrapper for page-level protection:

```typescript
import { withProtectedPage } from "@/lib/protected-page"

export default function MyPage() {
  return withProtectedPage(
    async (userId) => {
      return (
        <div>
          <h1>My Page</h1>
        </div>
      )
    },
    { requiredPermission: "profile:read" }
  )
}
```

### Admin Functions

```typescript
import { assignRoleToUser, getAllUsersWithRoles } from "@/app/actions/admin-actions"

// Assign role (requires users:manage permission)
await assignRoleToUser("user-id", "therapist")

// Get all users with roles
const users = await getAllUsersWithRoles()

// View audit logs for user
const logs = await getAuditLogsForUser("user-id")
```

## Error Handling

### Unauthorized Access

When a user lacks required permissions, the system redirects to `/unauthorized` showing:
- Clear error message
- Link to go home
- Link to go back

### 404 Dead Ends

All unbuilt routes and 404s render a fallback UI with:
- Clear error message
- Home button
- Go Back link

## Audit Trail & Compliance

All sensitive actions are logged to the `audit_log` table:

- Action timestamp
- User ID and role
- Resource affected
- IP address and user agent
- Action details (JSON)

Use `getAuditLogsForUser()` to retrieve logs for compliance audits.

## Best Practices

1. **Always check permissions** - Every action touching user data should check permissions
2. **Log sensitive actions** - Create, update, delete, and access to protected data
3. **Use role hierarchy** - Admin > Therapist > User
4. **Protect both routes and data** - Check permissions at both route level and data access level
5. **Never trust client input** - Always verify permissions server-side
6. **Monitor audit logs** - Regularly review logs for security issues
7. **Principle of least privilege** - Assign minimum required permissions to roles

## Adding New Permissions

To add a new permission:

1. Create permission in database:
```sql
INSERT INTO permission (name, resource, action, description) VALUES 
  ('resource:action', 'resource', 'action', 'Description');
```

2. Update role_permission mapping:
```sql
INSERT INTO role_permission (role_id, permission_id)
SELECT r.id, p.id FROM role r, permission p 
WHERE r.name = 'role_name' AND p.name = 'resource:action';
```

3. Use in code:
```typescript
await enforcePermission(userId, "resource:action")
```

## Security Considerations

- Session tokens are stored securely in httpOnly cookies
- Permissions are checked server-side, never on client
- Audit logs are immutable (never modified)
- User roles can only be changed by admin users
- All DB queries are parameterized to prevent SQL injection
- No user can escalate their own privileges
