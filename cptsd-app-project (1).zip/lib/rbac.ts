import { db } from "./db"
import { userRole, rolePermission, permission, role, auditLog } from "./db/schema"
import { eq, and } from "drizzle-orm"

/**
 * Layer 1: Authorization - Check if user has permission
 */
export async function checkPermission(
  userId: string,
  requiredPermission: string
): Promise<boolean> {
  try {
    // Get user's roles
    const userRoles = await db
      .select({ roleId: userRole.roleId })
      .from(userRole)
      .where(eq(userRole.userId, userId))

    if (userRoles.length === 0) return false

    const roleIds = userRoles.map((r) => r.roleId)

    // Check if any of user's roles have the required permission
    const hasPermission = await db
      .select()
      .from(rolePermission)
      .innerJoin(
        permission,
        eq(rolePermission.permissionId, permission.id)
      )
      .where(
        and(
          rolePermission.roleId.inArray(roleIds),
          eq(permission.name, requiredPermission)
        )
      )
      .limit(1)

    return hasPermission.length > 0
  } catch (error) {
    console.error("[RBAC] Permission check failed:", error)
    return false
  }
}

/**
 * Layer 1: Get user's roles
 */
export async function getUserRoles(userId: string): Promise<string[]> {
  try {
    const userRoles = await db
      .select({ name: role.name })
      .from(userRole)
      .innerJoin(role, eq(userRole.roleId, role.id))
      .where(eq(userRole.userId, userId))

    return userRoles.map((r) => r.name)
  } catch (error) {
    console.error("[RBAC] Get user roles failed:", error)
    return []
  }
}

/**
 * Layer 1: Get user's permissions
 */
export async function getUserPermissions(userId: string): Promise<string[]> {
  try {
    const permissions = await db
      .select({ name: permission.name })
      .from(userRole)
      .innerJoin(role, eq(userRole.roleId, role.id))
      .innerJoin(rolePermission, eq(role.id, rolePermission.roleId))
      .innerJoin(permission, eq(rolePermission.permissionId, permission.id))
      .where(eq(userRole.userId, userId))

    return permissions.map((p) => p.name)
  } catch (error) {
    console.error("[RBAC] Get permissions failed:", error)
    return []
  }
}

/**
 * Layer 2: Enforce permission - throw error if unauthorized
 */
export async function enforcePermission(
  userId: string,
  requiredPermission: string
): Promise<void> {
  const hasPermission = await checkPermission(userId, requiredPermission)
  if (!hasPermission) {
    throw new Error(
      `Unauthorized: Missing required permission '${requiredPermission}'`
    )
  }
}

/**
 * Layer 2: Check if user is at least a certain role level
 */
export async function hasMinimumRoleLevel(
  userId: string,
  minimumLevel: number
): Promise<boolean> {
  try {
    const userRole = await db
      .select({ level: role.level })
      .from(userRole)
      .innerJoin(role, eq(userRole.roleId, role.id))
      .where(eq(userRole.userId, userId))
      .orderBy(role.level)
      .limit(1)

    if (userRole.length === 0) return false
    return userRole[0].level >= minimumLevel
  } catch (error) {
    console.error("[RBAC] Role level check failed:", error)
    return false
  }
}

/**
 * Layer 3: Audit logging - Log all actions for compliance
 */
export async function logAuditTrail(
  userId: string,
  action: string,
  resource: string,
  resourceId?: string,
  details?: Record<string, any>,
  ipAddress?: string,
  userAgent?: string
): Promise<void> {
  try {
    // Get user's role
    const userRoles = await getUserRoles(userId)
    const userRole = userRoles[0] || "unknown"

    await db.insert(auditLog).values({
      userId,
      role: userRole,
      action,
      resource,
      resourceId,
      details: details ? JSON.stringify(details) : undefined,
      ipAddress,
      userAgent,
    })
  } catch (error) {
    console.error("[RBAC] Audit logging failed:", error)
    // Don't throw - logging failure shouldn't break the application
  }
}

/**
 * Layer 2: Data-level enforcement - Filter data based on user permissions
 */
export function buildDataFilters(
  userId: string,
  userPermissions: string[],
  resource: string
) {
  // If user has 'read_all' permission, no filtering needed
  if (userPermissions.includes(`${resource}:read_all`)) {
    return null // No filter, return all data
  }

  // Otherwise, only return user's own data
  return { userId }
}

/**
 * Layer 2: Middleware - Protect routes based on permissions
 */
export async function requirePermission(
  userId: string,
  permission: string,
  action: string,
  resource: string
) {
  // Check authorization
  await enforcePermission(userId, permission)

  // Log the action
  await logAuditTrail(userId, action, resource)
}

/**
 * Get audit logs for a user or all users
 */
export async function getAuditLogs(userId?: string, limit = 50) {
  try {
    let query = db.select().from(auditLog)

    if (userId) {
      query = query.where(eq(auditLog.userId, userId))
    }

    return await query.orderBy(auditLog.createdAt).limit(limit)
  } catch (error) {
    console.error("[RBAC] Get audit logs failed:", error)
    return []
  }
}
