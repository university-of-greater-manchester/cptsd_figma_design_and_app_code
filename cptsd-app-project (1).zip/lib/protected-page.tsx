import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { checkPermission, getUserRoles } from "@/lib/rbac"
import { headers } from "next/headers"

interface ProtectedPageProps {
  requiredPermission?: string
  requiredRole?: string
  minimumRoleLevel?: number
}

/**
 * Higher-order function for protecting pages with RBAC
 */
export async function withProtectedPage(
  callback: (userId: string) => Promise<React.ReactNode>,
  options: ProtectedPageProps = {}
) {
  const session = await auth.api.getSession({ headers: await headers() })

  // Redirect to login if not authenticated
  if (!session?.user) {
    redirect("/sign-in")
  }

  const userId = session.user.id

  // Check permission if required
  if (options.requiredPermission) {
    const hasPermission = await checkPermission(userId, options.requiredPermission)
    if (!hasPermission) {
      redirect("/unauthorized")
    }
  }

  // Check role if required
  if (options.requiredRole) {
    const userRoles = await getUserRoles(userId)
    if (!userRoles.includes(options.requiredRole)) {
      redirect("/unauthorized")
    }
  }

  // Render the page
  return callback(userId)
}

/**
 * Unauthorized page fallback
 */
export function UnauthorizedPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-4">
      <h1 className="text-3xl font-bold text-foreground">Access Denied</h1>
      <p className="text-foreground/70">
        You do not have permission to access this page.
      </p>
      <a href="/" className="text-primary hover:underline">
        Go Home
      </a>
    </div>
  )
}
