import { createAuthClient } from "better-auth/react"

const getBaseURL = () => {
  if (typeof window === 'undefined') return undefined
  
  // In browser, use relative URL for same-origin requests
  return undefined
}

export const authClient = createAuthClient({
  baseURL: getBaseURL(),
})

export const { signIn, signUp, signOut, useSession } = authClient
