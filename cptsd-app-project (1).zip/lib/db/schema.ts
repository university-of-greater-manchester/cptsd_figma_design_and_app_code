import { pgTable, text, timestamp, boolean, integer, serial, date, decimal } from "drizzle-orm/pg-core"

// ============================================================================
// BETTER AUTH TABLES (DO NOT MODIFY)
// ============================================================================

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow(),
})

// ============================================================================
// RBAC TABLES
// ============================================================================

export const role = pgTable("role", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // admin, therapist, user
  description: text("description"),
  level: integer("level").notNull(), // hierarchy level, higher = more privilege
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

export const permission = pgTable("permission", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // journal:create, journal:read, etc
  description: text("description"),
  resource: text("resource").notNull(), // journal, profile, users, etc
  action: text("action").notNull(), // create, read, update, delete, manage
  createdAt: timestamp("created_at").defaultNow(),
})

export const rolePermission = pgTable("role_permission", {
  id: serial("id").primaryKey(),
  roleId: integer("role_id")
    .notNull()
    .references(() => role.id, { onDelete: "cascade" }),
  permissionId: integer("permission_id")
    .notNull()
    .references(() => permission.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow(),
})

export const userRole = pgTable("user_role", {
  id: serial("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  roleId: integer("role_id")
    .notNull()
    .references(() => role.id, { onDelete: "cascade" }),
  grantedBy: text("granted_by"), // userId of admin who granted this role
  grantedAt: timestamp("granted_at").defaultNow(),
})

export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // role at time of action
  action: text("action").notNull(), // create_journal, update_profile, etc
  resource: text("resource").notNull(), // journal, profile, users, etc
  resourceId: text("resource_id"), // ID of the resource affected
  details: text("details"), // JSON stringified details
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
})

// ============================================================================
// APP TABLES - Your custom tables for CPTSD Toolkit
// Column names match database (snake_case)
// ============================================================================

// User profile with extended info
export const userProfile = pgTable("user_profile", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  displayName: text("display_name"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  theme: text("theme").default("light"),
  notificationsEnabled: boolean("notifications_enabled").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Journal entries
export const journalEntry = pgTable("journal_entry", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  mood: text("mood"),
  tags: text("tags"), // stored as array in DB, handled as text[] in queries
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Daily check-ins for mood tracking
export const dailyCheckIn = pgTable("daily_check_in", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  date: date("date").notNull(),
  moodScore: integer("mood_score"),
  energyLevel: integer("energy_level"),
  anxietyLevel: integer("anxiety_level"),
  sleepHours: decimal("sleep_hours", { precision: 3, scale: 1 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
})

// Grounding exercises completed
export const groundingExercise = pgTable("grounding_exercise", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  exerciseType: text("exercise_type").notNull(),
  durationSeconds: integer("duration_seconds"),
  effectivenessRating: integer("effectiveness_rating"),
  notes: text("notes"),
  completedAt: timestamp("completed_at").defaultNow(),
})

// User's saved coping strategies
export const copingStrategy = pgTable("coping_strategy", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  isFavorite: boolean("is_favorite").default(false),
  createdAt: timestamp("created_at").defaultNow(),
})

// ============================================================================
// NEW FEATURE TABLES - Refactor Requirements
// ============================================================================

// Library: Sections for organizing chapters
export const librarySection = pgTable("library_section", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon"),
  order: integer("order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
})

// Library: Chapters within sections
export const libraryChapter = pgTable("library_chapter", {
  id: serial("id").primaryKey(),
  sectionId: integer("section_id").references(() => librarySection.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content"),
  pageCount: integer("page_count"),
  orderIndex: integer("order_index").default(0),
  createdAt: timestamp("created_at").defaultNow(),
})

// Pattern Awareness: Trigger tracking
export const triggerTracker = pgTable("trigger_tracker", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  triggerDescription: text("trigger_description").notNull(),
  intensity: integer("intensity"),
  response: text("response"),
  supportUsed: text("support_used"),
  location: text("location"),
  timeOfDay: text("time_of_day"),
  notes: text("notes"),
  trackedAt: timestamp("tracked_at").defaultNow(),
})

// Personal Safety: Favorite grounding exercises
export const groundingFavorite = pgTable("grounding_favorite", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  exerciseName: text("exercise_name").notNull(),
  exerciseDescription: text("exercise_description"),
  category: text("category"),
  orderIndex: integer("order_index").default(0),
  createdAt: timestamp("created_at").defaultNow(),
})

// Personal Safety: Safety plan items
export const safetyPlanItems = pgTable("safety_plan_items", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  category: text("category").notNull(),
  content: text("content").notNull(),
  priority: integer("priority").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Daily Check-in V2: New format with mood states
export const dailyCheckInV2 = pgTable("daily_checkin_v2", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  date: date("date").notNull(),
  moodState: text("mood_state"),
  capacityLevel: integer("capacity_level"),
  connectionLevel: integer("connection_level"),
  nervousSystemState: text("nervous_system_state"),
  sleepHours: decimal("sleep_hours", { precision: 3, scale: 1 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
})

// Workbook: Fillable worksheets
export const worksheet = pgTable("worksheet", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content"),
  answers: text("answers"),
  isCompleted: boolean("is_completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Support: Professional support contacts
export const supportContact = pgTable("support_contact", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  role: text("role"),
  phone: text("phone"),
  email: text("email"),
  availability: text("availability"),
  notes: text("notes"),
  isCrisisContact: boolean("is_crisis_contact").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Settings: User preferences
export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  pushNotificationsEnabled: boolean("push_notifications_enabled").default(true),
  aiEngagementEnabled: boolean("ai_engagement_enabled").default(true),
  dailyReminderTime: text("daily_reminder_time"),
  theme: text("theme").default("light"),
  language: text("language").default("en"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Type exports for use in the app
export type User = typeof user.$inferSelect
export type Role = typeof role.$inferSelect
export type Permission = typeof permission.$inferSelect
export type UserRole = typeof userRole.$inferSelect
export type AuditLog = typeof auditLog.$inferSelect
export type UserProfile = typeof userProfile.$inferSelect
export type JournalEntry = typeof journalEntry.$inferSelect
export type DailyCheckIn = typeof dailyCheckIn.$inferSelect
export type GroundingExercise = typeof groundingExercise.$inferSelect
export type CopingStrategy = typeof copingStrategy.$inferSelect
export type LibrarySection = typeof librarySection.$inferSelect
export type LibraryChapter = typeof libraryChapter.$inferSelect
export type TriggerTracker = typeof triggerTracker.$inferSelect
export type GroundingFavorite = typeof groundingFavorite.$inferSelect
export type SafetyPlanItems = typeof safetyPlanItems.$inferSelect
export type DailyCheckInV2 = typeof dailyCheckInV2.$inferSelect
export type Worksheet = typeof worksheet.$inferSelect
export type SupportContact = typeof supportContact.$inferSelect
export type UserSettings = typeof userSettings.$inferSelect
