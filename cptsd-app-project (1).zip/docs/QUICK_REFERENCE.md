# CPTSD Toolkit - Quick Reference Guide

## 🚀 30-Second Setup (macOS/Linux)

```bash
# 1. Clone and enter directory
git clone <url> && cd cptsd-toolkit

# 2. Run setup script
bash scripts/setup.sh

# 3. Create database (in another terminal)
psql -U postgres << EOF
CREATE DATABASE cptsd_toolkit;
CREATE USER cptsd_user WITH PASSWORD 'cptsd_password';
GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;
EOF

# 4. Setup tables
psql -U cptsd_user -d cptsd_toolkit -f scripts/create_public_db.sql

# 5. Start server
pnpm dev

# 6. Open http://localhost:3000
```

## 🪟 30-Second Setup (Windows)

```bash
# 1. Clone and enter directory
git clone <url>
cd cptsd-toolkit

# 2. Run setup script
scripts\setup.bat

# 3. Create database (Command Prompt as Admin)
psql -U postgres -c "CREATE DATABASE cptsd_toolkit;"
psql -U postgres -c "CREATE USER cptsd_user WITH PASSWORD 'cptsd_password';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;"

# 4. Setup tables
psql -U cptsd_user -d cptsd_toolkit -f scripts\create_public_db.sql

# 5. Start server
pnpm dev

# 6. Open http://localhost:3000
```

## 📋 Installation Checklist

- [ ] Node.js v18+ installed
- [ ] PostgreSQL 12+ installed
- [ ] pnpm installed
- [ ] Project cloned
- [ ] Dependencies installed (`pnpm install`)
- [ ] Database created
- [ ] Database tables created
- [ ] `.env.local` configured
- [ ] Development server running

## 🔧 Essential Commands

| Command | Purpose |
|---------|---------|
| `pnpm dev` | Start development server |
| `pnpm build` | Create production build |
| `pnpm start` | Run production server |
| `pnpm lint` | Check code style |
| `psql -U postgres` | Connect to PostgreSQL |
| `psql -U cptsd_user -d cptsd_toolkit` | Connect to app database |

## 📁 Important Files

| File | Purpose |
|------|---------|
| `.env.local` | Environment variables (CREATE THIS) |
| `lib/auth.ts` | Better Auth configuration |
| `lib/db/schema.ts` | Database schema definition |
| `scripts/create_public_db.sql` | Database setup script |
| `app/api/auth/[...all]/route.ts` | Auth API endpoints |

## 🔑 Environment Variables Template

```bash
# Copy this to .env.local
DATABASE_URL=postgresql://cptsd_user:your_password@localhost:5432/cptsd_toolkit
BETTER_AUTH_SECRET=your_generated_secret_here
NODE_ENV=development
```

### Generate BETTER_AUTH_SECRET

**macOS/Linux:**
```bash
openssl rand -base64 32
```

**Windows PowerShell:**
```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

## 🗄️ Database Connection Info

```
Host: localhost
Port: 5432
Database: cptsd_toolkit
Username: cptsd_user
Password: cptsd_password (change in production!)
```

## 🔍 Verify Installation

### Check Node.js
```bash
node --version    # Should be v18+
npm --version     # Should be v9+
pnpm --version    # Should be latest
```

### Check PostgreSQL
```bash
psql --version    # Should be v12+

# Connect to database
psql -U cptsd_user -d cptsd_toolkit -c "SELECT COUNT(*) FROM \"user\";"
# Should return: count
#        0
```

### Check App Running
```bash
# Browser: http://localhost:3000
# Should show CPTSD Toolkit landing page

# API: http://localhost:3000/api/auth
# Should return 404 (not found) - that's OK
```

## 🆘 Troubleshooting Quick Links

| Problem | Solution |
|---------|----------|
| PostgreSQL won't start | See "Can't connect to PostgreSQL" in LOCAL_DEPLOYMENT_GUIDE.md |
| Port 3000 in use | Kill process on port 3000 (see guide) |
| Dependencies error | Run `pnpm install` again or clear cache |
| Database connection error | Verify credentials in `.env.local` |
| Auth not working | Ensure `BETTER_AUTH_SECRET` is set |

## 📱 Test the App

1. **Sign Up**: Click "Get Started"
2. **Log In**: Use your credentials
3. **Dashboard**: See daily check-in and features
4. **Grounding**: Click any grounding exercise
5. **Journal**: Create a journal entry
6. **Forgot Password**: Test password reset flow

## 🚀 Next Steps After Setup

1. **Customize Theme**: Edit `app/globals.css`
2. **Add Features**: Create new routes in `app/`
3. **Modify Database**: Edit `lib/db/schema.ts`
4. **Deploy**: Push to GitHub and deploy via Vercel
5. **Backup Database**: Set up PostgreSQL backups

## 📚 Documentation

- 📖 **Full Deployment Guide**: `docs/LOCAL_DEPLOYMENT_GUIDE.md`
- 🔐 **Password Reset Flow**: `docs/PASSWORD_RESET.md`
- 🗄️ **Database Schema**: `scripts/create_public_db.sql`
- 📝 **Project README**: `README.md`

## 🔗 Useful Links

- [Next.js Docs](https://nextjs.org/docs)
- [Better Auth Docs](https://better-auth.com)
- [Drizzle ORM](https://orm.drizzle.team)
- [PostgreSQL Docs](https://www.postgresql.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)

## 💡 Pro Tips

1. **Use `pnpm` not `npm`** - Faster and better dependency management
2. **Check `.env.local` first** - Most errors are environment variable issues
3. **PostgreSQL must be running** - Start with `brew services start postgresql@15` (macOS)
4. **Generate unique secrets** - Use `openssl rand -base64 32` for each environment
5. **Keep dependencies updated** - Run `pnpm update` monthly
6. **Enable VS Code extensions**:
   - Tailwind CSS IntelliSense
   - PostgreSQL support
   - TypeScript Vue Plugin

## 🎯 Architecture Overview

```
Browser (React 19)
    ↓
Next.js API Routes
    ↓
Better Auth (Session Management)
    ↓
Database (PostgreSQL)
    ├── User tables (Better Auth)
    └── App tables (Drizzle ORM)
```

## ⚡ Performance Tips

1. Clear `node_modules` and reinstall if slow
2. Use `pnpm --frozen-lockfile` for CI/CD
3. Enable PostgreSQL query caching
4. Use VSCode with Tailwind extension for faster CSS

## 🔐 Security Reminders

- ✅ Never commit `.env.local` to Git
- ✅ Use strong passwords for PostgreSQL
- ✅ Regenerate `BETTER_AUTH_SECRET` in production
- ✅ Run HTTPS in production
- ✅ Keep dependencies updated
- ✅ Use environment-specific secrets

## 📞 Getting Help

1. Check `LOCAL_DEPLOYMENT_GUIDE.md` Troubleshooting section
2. Review project structure in `README.md`
3. Check PostgreSQL logs
4. Review Next.js build output
5. Create GitHub issue with error details

---

**Version**: 1.0 | **Updated**: June 11, 2026
