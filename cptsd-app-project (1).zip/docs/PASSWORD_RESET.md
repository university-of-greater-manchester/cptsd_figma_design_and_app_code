# Password Reset Feature - Implementation Guide

## Overview
The CPTSD Toolkit now includes a complete password reset/recovery flow that allows users to securely reset their forgotten passwords through email verification.

## Features Implemented

### 1. Sign-In Page Enhancement
- Added "Forgot password?" link below the password field
- Link is visible only on the sign-in page, not on sign-up
- Styled consistently with the app's primary theme color

**Location:** `/sign-in` page

### 2. Forgot Password Page
- Users enter their email address
- Email validation to ensure the user has an account
- Sends a password reset link to the user's email
- Success message with instructions
- Option to send another email or return to sign-in

**Route:** `/forgot-password`
**File:** `app/forgot-password/page.tsx`

### 3. Password Reset Page
- User receives an email with a reset link containing a secure token
- Page displays form to enter new password and confirm password
- Password validation (minimum 8 characters)
- Passwords must match
- Success page with redirect to sign-in
- Error handling for expired or invalid tokens

**Route:** `/reset-password?token=<reset-token>`
**File:** `app/reset-password/page.tsx`

## Technical Implementation

### Database Schema
The feature leverages Better Auth's built-in password reset functionality. Better Auth manages:
- Password reset tokens (temporary, single-use)
- Token expiration
- Email verification
- Password hashing and security

### Server Actions
Located in `app/actions/password-reset-actions.ts`:

#### `forgotPassword(email: string)`
- Validates email exists in system
- Generates secure reset token
- Sends email with reset link
- Returns success/failure status

#### `resetPassword(token: string, password: string, confirmPassword: string)`
- Validates reset token
- Validates password strength (minimum 8 characters)
- Validates passwords match
- Updates user password in database
- Invalidates token after use

### Email Configuration
The email sending is handled by Better Auth. To configure email sending:

1. **Development:** Uses console logging (check terminal for reset link)
2. **Production:** Configure email provider in env variables
   - SendGrid
   - Resend
   - Custom SMTP
   - Other providers supported by Better Auth

### Environment Variables Required
```bash
# Better Auth Configuration
BETTER_AUTH_SECRET=<your-secret>
DATABASE_URL=<neon-database-url>
BETTER_AUTH_URL=<your-app-url>

# Email Provider (choose one)
SENDGRID_API_KEY=<key>
RESEND_API_KEY=<key>
SMTP_HOST=<host>
SMTP_PORT=<port>
SMTP_USER=<user>
SMTP_PASSWORD=<password>
```

## User Flow

### Step 1: Initiate Password Reset
1. User goes to `/sign-in`
2. Clicks "Forgot password?" link
3. Redirected to `/forgot-password`

### Step 2: Enter Email
1. User enters their email address
2. Clicks "Send Reset Link"
3. System verifies email exists
4. Email sent with reset link

### Step 3: Check Email
1. User receives email with subject "Reset your password"
2. Email contains reset link: `{APP_URL}/reset-password?token={TOKEN}`
3. Link is valid for 24 hours (configurable)

### Step 4: Reset Password
1. User clicks link in email
2. Taken to `/reset-password?token=<token>`
3. Enters new password and confirmation
4. Clicks "Reset Password"
5. Password updated successfully
6. Redirected to sign-in after 3 seconds

### Step 5: Sign In
1. User goes to `/sign-in`
2. Signs in with email and new password

## Security Features

✅ **One-time use tokens** - Tokens are invalidated after use
✅ **Token expiration** - Default 24 hours (configurable)
✅ **Password validation** - Minimum 8 characters required
✅ **Email verification** - Only registered emails can reset
✅ **HTTPS only** - Reset links work only over secure connection
✅ **Password hashing** - Passwords hashed using bcrypt (Better Auth)
✅ **CSRF protection** - Built into Better Auth

## Testing the Feature

### Test in Development
1. **Without Email Provider:**
   - Check server console/logs for reset link
   - Manually extract token from logs
   - Visit `/reset-password?token=<token-from-logs>`

2. **With Email Provider:**
   - Sign up for test account
   - Request password reset
   - Check email inbox for reset link
   - Follow link and reset password

### Test Cases
- [ ] User enters invalid email → Error message
- [ ] User enters registered email → Success message
- [ ] User clicks reset link → Form displayed
- [ ] User enters mismatched passwords → Error
- [ ] User enters password too short → Error
- [ ] User enters valid passwords → Success, redirected to sign-in
- [ ] User tries expired token → Error message
- [ ] User tries token twice → Second attempt fails

## Troubleshooting

### Email not sending
- Check email provider is configured in env variables
- Check BETTER_AUTH_URL is set correctly
- Check email provider API key is valid

### Token invalid/expired
- Default expiration is 24 hours
- Check that BETTER_AUTH_SECRET is set and consistent
- User may need to request new reset link

### Page not found errors
- Ensure both `/forgot-password` and `/reset-password` routes exist
- Check that Suspense boundary is in place for `/reset-password`

## Files Modified/Created

```
Created:
- app/forgot-password/page.tsx
- app/reset-password/page.tsx
- app/actions/password-reset-actions.ts

Modified:
- components/auth-form.tsx (added "Forgot password?" link)
```

## Future Enhancements

- [ ] Rate limiting on password reset requests
- [ ] SMS-based password reset option
- [ ] Two-factor authentication integration
- [ ] Password strength indicator
- [ ] Security questions as backup recovery
- [ ] Admin password reset capability
- [ ] Login attempt tracking and lockout
