# CPTSD Toolkit - Local Deployment Guide

## Overview
This guide walks you through setting up the CPTSD Toolkit application on your local laptop. The app uses:
- **Frontend**: Next.js 16 with React 19
- **Backend**: Node.js with Better Auth
- **Database**: PostgreSQL 
- **ORM**: Drizzle ORM
- **Package Manager**: pnpm

---

## Prerequisites

Before you start, ensure you have the following installed on your system:
- **Git** (for version control)
- **Node.js** (version 18 or higher) - includes npm
- **PostgreSQL** (version 12 or higher)
- **pnpm** (Node package manager)

---

## Step 1: Install Prerequisites

### 1.1 Install Node.js

**For Windows:**
1. Download from https://nodejs.org/ (LTS version recommended)
2. Run the installer and follow the installation wizard
3. Accept default settings
4. Verify installation by opening Command Prompt and typing:
   ```bash
   node --version
   npm --version
   ```

**For macOS:**
```bash
# Using Homebrew
brew install node

# Verify installation
node --version
npm --version
```

**For Linux (Ubuntu/Debian):**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

### 1.2 Install pnpm

```bash
npm install -g pnpm

# Verify installation
pnpm --version
```

### 1.3 Install PostgreSQL

**For Windows:**
1. Download from https://www.postgresql.org/download/windows/
2. Run the installer
3. When prompted, set the password for the `postgres` user (remember this!)
4. Keep the default port **5432**
5. Complete the installation

**For macOS:**
```bash
# Using Homebrew
brew install postgresql@15

# Start PostgreSQL service
brew services start postgresql@15

# Verify installation
psql --version
```

**For Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install -y postgresql postgresql-contrib

# Start PostgreSQL service
sudo service postgresql start

# Verify installation
psql --version
```

---

## Step 2: Create PostgreSQL Database

### 2.1 Connect to PostgreSQL

**For Windows (using psql):**
```bash
# Open Command Prompt
psql -U postgres

# When prompted, enter the password you set during installation
```

**For macOS/Linux:**
```bash
sudo -u postgres psql
```

### 2.2 Create the Database

Run the following commands in the PostgreSQL prompt:

```sql
-- Create a new database for CPTSD Toolkit
CREATE DATABASE cptsd_toolkit;

-- Create a database user
CREATE USER cptsd_user WITH PASSWORD 'your_secure_password_here';

-- Grant all privileges to the user
GRANT ALL PRIVILEGES ON DATABASE cptsd_toolkit TO cptsd_user;

-- Connect to the database
\c cptsd_toolkit

-- Grant schema privileges
GRANT ALL ON SCHEMA public TO cptsd_user;

-- Exit psql
\q
```

**Note:** Replace `'your_secure_password_here'` with a strong password you'll use in the connection string.

---

## Step 3: Clone/Download Project Files

### 3.1 Download the Project

**Option A: Using Git (Recommended)**
```bash
# Navigate to where you want to store the project
cd ~/projects

# Clone the repository
git clone <repository-url> cptsd-toolkit
cd cptsd-toolkit
```

**Option B: Download ZIP**
1. Download the project as ZIP from your repository
2. Extract it to a folder on your laptop
3. Open terminal/command prompt in the extracted folder

---

## Step 4: Setup Environment Variables

### 4.1 Create .env.local File

In the project root directory, create a file named `.env.local`:

**For Windows (Command Prompt):**
```bash
echo. > .env.local
```

**For macOS/Linux:**
```bash
touch .env.local
```

### 4.2 Add Environment Variables

Open `.env.local` in your text editor and add:

```bash
# Database Connection String
DATABASE_URL=postgresql://cptsd_user:your_secure_password_here@localhost:5432/cptsd_toolkit

# Better Auth Secret (generate a random 32-character string)
# Generate using: openssl rand -base64 32
BETTER_AUTH_SECRET=your_generated_secret_key_here

# Environment
NODE_ENV=development

# Optional: If deploying to production later
# VERCEL_URL=your-domain.com
# VERCEL_PROJECT_PRODUCTION_URL=your-domain.com
```

### 4.3 Generate BETTER_AUTH_SECRET

Generate a secure secret key using:

**For Windows (PowerShell):**
```powershell
# Using Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

**For macOS/Linux:**
```bash
openssl rand -base64 32
```

Copy the generated string and paste it as the value for `BETTER_AUTH_SECRET` in `.env.local`.

---

## Step 5: Install Dependencies

### 5.1 Install Project Dependencies

In the project root directory, run:

```bash
pnpm install
```

This will install all required packages listed in `package.json`:
- better-auth (authentication)
- drizzle-orm (database ORM)
- next (frontend framework)
- pg (PostgreSQL driver)
- tailwindcss (styling)
- And other dependencies

**Expected time:** 2-5 minutes depending on internet speed

---

## Step 6: Setup Database Schema

### 6.1 Create Database Tables

The application uses Drizzle ORM with PostgreSQL. The schema includes:
- Better Auth tables (user, session, account, verification)
- Application tables (daily_check_in, grounding_exercise, journal_entry, etc.)
- RBAC tables (role, permission, user_role)

Run the SQL setup script:

**Option A: Using psql command line**

```bash
# Windows
psql -U cptsd_user -d cptsd_toolkit -f scripts/create_public_db.sql

# macOS/Linux
psql -U postgres -d cptsd_toolkit -f scripts/create_public_db.sql
```

**Option B: Using SQL Editor**

1. Open a PostgreSQL GUI client (DBeaver, pgAdmin, or similar)
2. Connect to the database using credentials:
   - Host: localhost
   - Port: 5432
   - Database: cptsd_toolkit
   - Username: cptsd_user
   - Password: your_secure_password_here
3. Open the file `scripts/create_public_db.sql`
4. Execute the entire script

### 6.2 Verify Tables Were Created

Connect to the database and verify:

```sql
-- List all tables
\dt

-- You should see tables like: user, session, account, verification, 
-- daily_check_in, grounding_exercise, journal_entry, etc.
```

---

## Step 7: Create Initial Test User (Optional)

### 7.1 Create Test User via Database

For testing, you can create a test user directly:

```sql
-- Insert test user
INSERT INTO "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
VALUES (
  'test-user-001',
  'Test User',
  'test@example.com',
  true,
  NOW(),
  NOW()
);

-- Insert password account (using bcrypt hash for password "Test1234")
INSERT INTO account (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
VALUES (
  'test-account-001',
  'test@example.com',
  'credential',
  'test-user-001',
  '$2b$10$your_bcrypt_hash_here', -- Generate using Node.js
  NOW(),
  NOW()
);
```

Or use the provided Node.js script to generate password hashes:

```bash
node scripts/hash-password.js
```

---

## Step 8: Run the Application

### 8.1 Start Development Server

In the project root directory, run:

```bash
pnpm dev
```

You should see output like:
```
  ▲ Next.js 16.2.6
  - Local:        http://localhost:3000
  - Environments: .env.local

Ready in 2.5s
```

### 8.2 Access the Application

1. Open your web browser
2. Navigate to: **http://localhost:3000**
3. You should see the CPTSD Toolkit landing page

---

## Step 9: Test the Application

### 9.1 Test Sign-Up

1. Click "Get Started" button
2. Fill in the sign-up form:
   - Name: Your Name
   - Email: your-email@example.com
   - Password: At least 8 characters
3. Click "Create Account"
4. You should be redirected to the dashboard

### 9.2 Test Sign-In

1. Sign out or navigate to `/sign-in`
2. Enter your email and password
3. Click "Sign In"
4. You should be logged in and see the dashboard

### 9.3 Test Features

Once logged in, test:
- ✓ Dashboard with daily check-in
- ✓ Grounding exercises (Box Breathing, 5-4-3-2-1, Body Scan, Self-Compassion, Sound Awareness)
- ✓ Journal functionality
- ✓ Bottom navigation bar
- ✓ Forgot password link (forgot-password page)

---

## Step 10: Build for Production

### 10.1 Create Production Build

```bash
pnpm build
```

This creates an optimized production build in the `.next` folder.

### 10.2 Run Production Build

```bash
pnpm start
```

The app will run on the same port (3000) but with optimized production code.

---

## Troubleshooting

### Issue: "Can't connect to PostgreSQL"

**Solution:**
1. Verify PostgreSQL is running:
   - Windows: Check Services (postgresql-x64-15)
   - macOS: `brew services list`
   - Linux: `sudo service postgresql status`
2. Check DATABASE_URL in `.env.local`
3. Verify credentials match what you set during database creation

### Issue: "BETTER_AUTH_SECRET is not set"

**Solution:**
1. Verify `.env.local` file exists in project root
2. Add BETTER_AUTH_SECRET variable
3. Restart the development server

### Issue: "Module not found" errors

**Solution:**
```bash
# Clear node_modules and reinstall
rm -rf node_modules
pnpm install
```

### Issue: Port 3000 already in use

**Solution:**
```bash
# Windows: Find and kill process on port 3000
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# macOS/Linux: Find and kill process
lsof -ti:3000 | xargs kill -9
```

### Issue: Cannot connect to database after server starts

**Solution:**
1. Test database connection directly:
   ```bash
   psql -U cptsd_user -d cptsd_toolkit -h localhost
   ```
2. If connection fails, verify:
   - PostgreSQL is running
   - Database name is correct
   - Username and password are correct
   - DATABASE_URL format is correct

---

## File Structure

```
cptsd-toolkit/
├── app/
│   ├── api/auth/[...all]/        # Better Auth API routes
│   ├── sign-in/                  # Sign-in page
│   ├── sign-up/                  # Sign-up page
│   ├── forgot-password/          # Forgot password page
│   ├── reset-password/           # Password reset page
│   ├── dashboard/                # Main dashboard
│   ├── grounding/                # Grounding exercises
│   ├── journal/                  # Journal functionality
│   └── page.tsx                  # Landing page
├── components/
│   ├── auth-form.tsx             # Login/signup form
│   ├── layout-wrapper.tsx        # App layout wrapper
│   └── ...                       # Other components
├── lib/
│   ├── auth.ts                   # Better Auth configuration
│   ├── auth-client.ts            # Auth client (browser)
│   └── db/
│       ├── index.ts              # Drizzle ORM setup
│       └── schema.ts             # Database schema
├── scripts/
│   ├── create_public_db.sql      # Database setup script
│   └── hash-password.js          # Password hashing utility
├── .env.local                    # Environment variables (CREATE THIS)
├── package.json                  # Dependencies
├── tsconfig.json                 # TypeScript config
└── next.config.mjs               # Next.js config
```

---

## Next Steps

1. **Customize Settings**: Modify the app theme in `app/globals.css`
2. **Add Features**: Create new routes and components as needed
3. **Deploy**: When ready, deploy to Vercel or your hosting provider
4. **Database Backups**: Set up regular PostgreSQL backups
5. **Security**: Keep dependencies updated with `pnpm update`

---

## Useful Commands

```bash
# Development
pnpm dev              # Start development server
pnpm build            # Create production build
pnpm start            # Run production build
pnpm lint             # Check code style

# Database
psql -U postgres      # Connect to PostgreSQL
pnpm db:push          # Push schema changes (if using Drizzle Kit)

# Dependencies
pnpm add package-name # Install new package
pnpm update           # Update all packages
pnpm remove package-name # Remove package
```

---

## Support & Documentation

- **Better Auth Docs**: https://better-auth.com
- **Next.js Docs**: https://nextjs.org/docs
- **Drizzle ORM Docs**: https://orm.drizzle.team
- **PostgreSQL Docs**: https://www.postgresql.org/docs
- **Tailwind CSS Docs**: https://tailwindcss.com/docs

---

## Security Best Practices

1. **Never commit `.env.local`** - Add to `.gitignore`
2. **Use strong passwords** for database user
3. **Generate unique BETTER_AUTH_SECRET** for each environment
4. **Keep dependencies updated** - Run `pnpm update` regularly
5. **Use HTTPS in production** - Never run production without SSL
6. **Regular backups** - Back up PostgreSQL regularly
7. **Limit database access** - Only localhost in development

---

**Last Updated**: June 11, 2026
**Version**: 1.0
