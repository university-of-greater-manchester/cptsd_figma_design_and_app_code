
  # Mobile app interface design

  This is a code bundle for Mobile app interface design. The original project is available at https://www.figma.com/design/K1n5ucu6mIFvpYBTSTp7B4/Mobile-app-interface-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  