import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, MessageSquare, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { toast } from 'sonner';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function Feedback() {
  const navigate = useNavigate();
  const [rating, setRating] = useState('');
  const [feedbackType, setFeedbackType] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    if (!rating || !feedbackType || !message) {
      toast.error('Please complete all fields');
      return;
    }
    toast.success('Thank you for your feedback!');
    setTimeout(() => navigate('/home'), 1500);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Feedback</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
          <div className="flex items-start gap-3">
            <MessageSquare className="h-6 w-6 mt-1" style={{ color: '#153a21' }} />
            <div>
              <h3 className="font-semibold mb-2" style={{ color: '#153a21' }}>We Value Your Input</h3>
              <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
                Your feedback helps us improve CPTSD Toolkit and better serve our community.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-3">
            <Label className="text-white text-lg">How would you rate your experience?</Label>
            <RadioGroup value={rating} onValueChange={setRating}>
              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star.toString())}
                    className="p-2"
                  >
                    <Star
                      className={`h-8 w-8 ${parseInt(rating) >= star ? 'fill-current' : ''}`}
                      style={{ color: '#b5a47d' }}
                    />
                  </button>
                ))}
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <Label className="text-white text-lg">Feedback Type</Label>
            <RadioGroup value={feedbackType} onValueChange={setFeedbackType}>
              <div className="space-y-2">
                {['Bug Report', 'Feature Request', 'General Feedback', 'Complaint', 'Compliment'].map((type) => (
                  <div
                    key={type}
                    className="flex items-center space-x-3 p-3 rounded-lg"
                    style={{
                      backgroundColor: feedbackType === type ? '#b5a47d' : 'transparent',
                      border: '1px solid #b5a47d'
                    }}
                  >
                    <RadioGroupItem value={type} id={type} style={{ borderColor: '#b5a47d' }} />
                    <Label
                      htmlFor={type}
                      className="cursor-pointer flex-1"
                      style={{ color: feedbackType === type ? '#153a21' : '#b5a47d' }}
                    >
                      {type}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <Label className="text-white text-lg">Your Message</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Share your thoughts, suggestions, or concerns..."
              className="min-h-40 border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            Submit Feedback
          </Button>
        </div>

        <div className="mt-6 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <p className="text-white/80 text-sm text-center">
            Your feedback is anonymous and helps us create a better experience for everyone in our community.
          </p>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
