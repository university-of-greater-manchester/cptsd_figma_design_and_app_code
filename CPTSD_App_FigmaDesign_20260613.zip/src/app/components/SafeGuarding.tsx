import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Phone, Plus, X, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

type TabType = 'plan' | 'contacts';

interface ListItem { id: string; value: string; }
interface SafePerson { id: string; name: string; phone: string; }
interface ProfessionalContact { id: string; role: string; name: string; phone: string; }

const ukContacts = [
  {
    category: 'Immediate Danger',
    services: [
      { name: 'Emergency Services', number: '999', note: 'Use when you or someone else is in immediate danger.', url: '' },
    ],
  },
  {
    category: 'Urgent Mental Health Support',
    services: [
      { name: 'NHS 111 Mental Health Support', number: '111', note: 'Call 111 and select the mental health option.', url: 'https://111.nhs.uk' },
    ],
  },
  {
    category: 'Emotional Crisis Support',
    services: [
      { name: 'Samaritans', number: '116 123', note: '24/7 listening support', url: 'https://www.samaritans.org' },
      { name: 'SHOUT', number: 'Text SHOUT to 85258', note: 'Free text support, 24/7', url: 'https://giveusashout.org' },
    ],
  },
  {
    category: 'Trauma & Abuse Support',
    services: [
      { name: 'Refuge', number: '0808 2000 248', note: 'Support for domestic abuse', url: 'https://www.refuge.org.uk' },
    ],
  },
  {
    category: 'Ongoing Mental Health Support',
    services: [
      { name: 'Mind', number: '', note: 'Information and mental health support resources', url: 'https://www.mind.org.uk' },
      { name: 'SANEline', number: '', note: 'Emotional support line', url: 'https://www.sane.org.uk' },
      { name: 'Papyrus HOPELINE UK', number: '0800 068 4141', note: 'Support for young people experiencing suicidal thoughts', url: 'https://www.papyrus-uk.org' },
    ],
  },
];

const professionalRoles = ['Therapist', 'GP', 'Support Worker', 'Crisis Team', 'Social Worker', 'Care Coordinator'];

function makeId() { return Date.now().toString() + Math.random().toString(36).slice(2, 7); }

export function SafeGuarding() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('plan');

  // Early Indicators
  const [earlyIndicators, setEarlyIndicators] = useState<ListItem[]>([{ id: makeId(), value: '' }]);
  // External Triggers
  const [externalTriggers, setExternalTriggers] = useState<ListItem[]>([{ id: makeId(), value: '' }]);
  // Coping Strategies
  const [copingStrategies, setCopingStrategies] = useState(['', '', '']);
  // Safe People
  const [safePeople, setSafePeople] = useState<SafePerson[]>([{ id: makeId(), name: '', phone: '' }]);
  // Safe Place
  const [safePlace, setSafePlace] = useState('');
  // What Helps You Stay Connected
  const [stayConnected, setStayConnected] = useState('');
  // Professional Support
  const [professionals, setProfessionals] = useState<ProfessionalContact[]>([
    { id: makeId(), role: 'Therapist', name: '', phone: '' },
  ]);

  const addListItem = (setter: React.Dispatch<React.SetStateAction<ListItem[]>>) => {
    setter(prev => [...prev, { id: makeId(), value: '' }]);
  };
  const removeListItem = (id: string, setter: React.Dispatch<React.SetStateAction<ListItem[]>>) => {
    setter(prev => prev.filter(item => item.id !== id));
  };
  const updateListItem = (id: string, value: string, setter: React.Dispatch<React.SetStateAction<ListItem[]>>) => {
    setter(prev => prev.map(item => item.id === id ? { ...item, value } : item));
  };

  const addSafePerson = () => setSafePeople(prev => [...prev, { id: makeId(), name: '', phone: '' }]);
  const removeSafePerson = (id: string) => setSafePeople(prev => prev.filter(p => p.id !== id));

  const addProfessional = () => setProfessionals(prev => [...prev, { id: makeId(), role: 'Other', name: '', phone: '' }]);
  const removeProfessional = (id: string) => setProfessionals(prev => prev.filter(p => p.id !== id));
  const updateProfessional = (id: string, field: keyof ProfessionalContact, value: string) => {
    setProfessionals(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const handleSave = () => toast.success('Safety plan saved!');

  const inputStyle = { backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Personal Safety</h1>
      </header>

      {/* Tabs — only Safety Plan and Contacts */}
      <div className="sticky z-40 px-4 py-3 border-b border-white/10 flex gap-2" style={{ backgroundColor: '#153a21', top: '73px' }}>
        {(['plan', 'contacts'] as TabType[]).map(t => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className="flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === t ? '#b5a47d' : 'transparent',
              color: activeTab === t ? '#153a21' : '#b5a47d',
            }}
          >
            {t === 'plan' ? 'Safety Plan' : 'Contacts'}
          </button>
        ))}
      </div>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">

        {/* Safety Plan Tab */}
        {activeTab === 'plan' && (
          <div className="space-y-8">
            {/* Intro */}
            <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
              <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>About Your Safety Plan</h3>
              <p className="text-white/80 text-sm">
                A safety plan is a personal tool to help you notice changes in how you're feeling and choose ways to support your wellbeing and safety.
              </p>
            </div>

            {/* Early Indicators */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Early Indicators</h3>
              <p className="text-white/70 text-sm">What thoughts, feelings or body sensations tell you things may be becoming harder to manage?</p>
              {earlyIndicators.map((item, i) => (
                <div key={item.id} className="flex gap-2">
                  <Input
                    placeholder={`Early indicator ${i + 1}`}
                    value={item.value}
                    onChange={e => updateListItem(item.id, e.target.value, setEarlyIndicators)}
                    className="border-2 flex-1"
                    style={inputStyle}
                  />
                  {earlyIndicators.length > 1 && (
                    <button onClick={() => removeListItem(item.id, setEarlyIndicators)} className="p-2 rounded-lg" style={{ color: '#b5a47d' }}>
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
              <button onClick={() => addListItem(setEarlyIndicators)} className="flex items-center gap-2 text-sm" style={{ color: '#b5a47d' }}>
                <Plus className="h-4 w-4" /> Add another
              </button>
            </div>

            {/* External Triggers */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>External Triggers</h3>
              <p className="text-white/70 text-sm">Are there situations or environments that tend to make things feel more overwhelming?</p>
              {externalTriggers.map((item, i) => (
                <div key={item.id} className="flex gap-2">
                  <Input
                    placeholder={`External trigger ${i + 1}`}
                    value={item.value}
                    onChange={e => updateListItem(item.id, e.target.value, setExternalTriggers)}
                    className="border-2 flex-1"
                    style={inputStyle}
                  />
                  {externalTriggers.length > 1 && (
                    <button onClick={() => removeListItem(item.id, setExternalTriggers)} className="p-2 rounded-lg" style={{ color: '#b5a47d' }}>
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
              <button onClick={() => addListItem(setExternalTriggers)} className="flex items-center gap-2 text-sm" style={{ color: '#b5a47d' }}>
                <Plus className="h-4 w-4" /> Add another
              </button>
            </div>

            {/* Coping Strategies */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Coping Strategies</h3>
              <p className="text-white/70 text-sm">What helps you feel more grounded or steady in the moment?</p>
              {copingStrategies.map((val, i) => (
                <Input
                  key={i}
                  placeholder={`Coping strategy ${i + 1}`}
                  value={val}
                  onChange={e => {
                    const updated = [...copingStrategies];
                    updated[i] = e.target.value;
                    setCopingStrategies(updated);
                  }}
                  className="border-2"
                  style={inputStyle}
                />
              ))}
            </div>

            {/* Safe People */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Safe People</h3>
              <p className="text-white/70 text-sm">Who feels safe or helpful to contact when things feel difficult?</p>
              {safePeople.map((person, i) => (
                <div key={person.id} className="space-y-2 p-3 rounded-lg border border-white/20">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-white/50">Person {i + 1}</span>
                    {safePeople.length > 1 && (
                      <button onClick={() => removeSafePerson(person.id)} style={{ color: '#b5a47d' }}>
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <Input placeholder="Name" value={person.name}
                    onChange={e => setSafePeople(prev => prev.map(p => p.id === person.id ? { ...p, name: e.target.value } : p))}
                    className="border-2" style={inputStyle}
                  />
                  <Input placeholder="Phone number" value={person.phone}
                    onChange={e => setSafePeople(prev => prev.map(p => p.id === person.id ? { ...p, phone: e.target.value } : p))}
                    className="border-2" style={inputStyle}
                  />
                </div>
              ))}
              <button onClick={addSafePerson} className="flex items-center gap-2 text-sm" style={{ color: '#b5a47d' }}>
                <Plus className="h-4 w-4" /> Add another person
              </button>
            </div>

            {/* Safe Place */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Safe Place</h3>
              <Input
                placeholder="Where can you go to feel safe or more at ease?"
                value={safePlace}
                onChange={e => setSafePlace(e.target.value)}
                className="border-2"
                style={inputStyle}
              />
            </div>

            {/* What Helps You Stay Connected */}
            <div className="space-y-3">
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>What Helps You Stay Connected</h3>
              <Textarea
                placeholder="What helps you stay connected to life and yourself?"
                value={stayConnected}
                onChange={e => setStayConnected(e.target.value)}
                className="min-h-28 border-2"
                style={inputStyle}
              />
            </div>

            <Button onClick={handleSave} className="w-full" style={{ backgroundColor: '#b5a47d', color: '#153a21' }}>
              Save Safety Plan
            </Button>
          </div>
        )}

        {/* Contacts Tab */}
        {activeTab === 'contacts' && (
          <div className="space-y-6">
            <p className="text-white/80 text-sm">
              Support services you can contact if you need urgent emotional support, practical help, or immediate assistance.
            </p>

            {ukContacts.map(group => (
              <div key={group.category} className="space-y-3">
                <h3 className="font-semibold text-sm uppercase tracking-wide" style={{ color: '#b5a47d' }}>
                  {group.category}
                </h3>
                {group.services.map(service => (
                  <div key={service.name} className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        {service.url ? (
                          <a href={service.url} target="_blank" rel="noopener noreferrer"
                            className="font-semibold flex items-center gap-1 hover:opacity-80"
                            style={{ color: '#153a21' }}>
                            {service.name}
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        ) : (
                          <p className="font-semibold" style={{ color: '#153a21' }}>{service.name}</p>
                        )}
                        {service.number && (
                          <a href={`tel:${service.number.replace(/\s/g, '')}`}
                            className="text-lg font-mono block mt-1 hover:opacity-80"
                            style={{ color: '#153a21' }}>
                            {service.number}
                          </a>
                        )}
                        <p className="text-xs mt-1 opacity-70" style={{ color: '#153a21' }}>{service.note}</p>
                      </div>
                      {service.number && !service.number.startsWith('Text') && (
                        <a href={`tel:${service.number.replace(/\s/g, '')}`}
                          className="p-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: '#153a21', color: '#b5a47d' }}>
                          <Phone className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                    {group.category === 'Immediate Danger' && (
                      <p className="text-xs mt-2 font-semibold" style={{ color: '#153a21' }}>
                        Use when you or someone else is in immediate danger.
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ))}

            {/* Professional Support */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm uppercase tracking-wide" style={{ color: '#b5a47d' }}>
                Professional Support
              </h3>
              <p className="text-white/70 text-sm">Add your own professional contacts below.</p>
              {professionals.map((prof, i) => (
                <div key={prof.id} className="p-3 rounded-lg space-y-2 border border-white/20">
                  <div className="flex items-center justify-between">
                    <select
                      value={prof.role}
                      onChange={e => updateProfessional(prof.id, 'role', e.target.value)}
                      className="text-sm font-semibold rounded px-2 py-1"
                      style={{ backgroundColor: '#b5a47d', color: '#153a21', border: 'none' }}
                    >
                      {professionalRoles.map(r => <option key={r} value={r}>{r}</option>)}
                      <option value="Other">Other</option>
                    </select>
                    {professionals.length > 1 && (
                      <button onClick={() => removeProfessional(prof.id)} style={{ color: '#b5a47d' }}>
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <Input
                    placeholder="Name"
                    value={prof.name}
                    onChange={e => updateProfessional(prof.id, 'name', e.target.value)}
                    className="border-2"
                    style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
                  />
                  <Input
                    placeholder="Phone / contact"
                    value={prof.phone}
                    onChange={e => updateProfessional(prof.id, 'phone', e.target.value)}
                    className="border-2"
                    style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
                  />
                </div>
              ))}
              <button onClick={addProfessional} className="flex items-center gap-2 text-sm" style={{ color: '#b5a47d' }}>
                <Plus className="h-4 w-4" /> Add professional contact
              </button>
            </div>
          </div>
        )}
      </main>

      <BottomNavBar />
    </div>
  );
}
