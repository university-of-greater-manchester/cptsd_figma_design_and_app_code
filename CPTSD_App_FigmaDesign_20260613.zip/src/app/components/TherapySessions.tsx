import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Plus, CalendarDays, BarChart2, BookOpen, ChevronDown, ChevronUp, X } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend
} from 'recharts';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

type TabType = 'tracker' | 'calendar' | 'charts';

interface TriggerEntry {
  id: string;
  date: string;
  trigger: string;
  response: string;
  intensity: string;
  support: string;
}

const triggerOptions = [
  'Conflict or disagreement', 'Conflict avoidance', 'Feeling criticised',
  'Feeling ignored or dismissed', 'Feeling trapped or pressured', 'Feeling out of control',
  'Uncertainty or unpredictability', 'Loud/noisy environment', 'Social interaction',
  'Being alone', 'Work/study stress', 'Unexpected change', 'Physical exhaustion',
  'Physical pain or illness', 'Poor sleep', 'Memory or reminder', 'Feeling rejected',
  'Financial stress', 'Hormonal/body changes', 'Overstimulation/sensory overload',
  'Relationship difficulty', "I don't know", 'Other',
];

const responseOptions = [
  'Anxiety/panic', 'Urge to withdraw', 'Urge to escape or avoid',
  'Increased impulsivity/risk-taking', 'Difficulty slowing down', 'Emotional reactivity',
  'Irritability', 'Intrusive thoughts', 'Dissociation', 'Emotional overwhelm',
  'Racing thoughts', 'Low mood', 'Using substances to cope', 'Physical tension',
  'Fatigue', 'Urge to isolate', 'Difficulty concentrating', 'Hypervigilance',
  'Difficulty feeling present', 'Feeling disconnected from others', 'Feeling unlike yourself', 'Other',
];

const intensityOptions = ['Felt manageable', 'Felt difficult', 'Felt overwhelming'];

const supportOptions = [
  'Grounding exercise', 'Reached out for support', 'Time alone', 'Creative activity',
  'Comfort activity', 'Nature/outdoors', 'Routine or structure', 'Talking to someone',
  'Rest/sleep', 'Movement', 'Music/audio', 'Journalling', 'Breathing exercises',
  'Somatic exercises', 'Nothing helped', 'Still struggling', 'Other',
];

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const sampleEntries: TriggerEntry[] = [
  { id: '1', date: '2026-05-28', trigger: 'Work/study stress', response: 'Anxiety/panic', intensity: 'Felt difficult', support: 'Breathing exercises' },
  { id: '2', date: '2026-05-26', trigger: 'Social interaction', response: 'Urge to withdraw', intensity: 'Felt manageable', support: 'Time alone' },
  { id: '3', date: '2026-05-24', trigger: 'Poor sleep', response: 'Fatigue', intensity: 'Felt overwhelming', support: 'Rest/sleep' },
  { id: '4', date: '2026-05-22', trigger: 'Conflict or disagreement', response: 'Emotional reactivity', intensity: 'Felt difficult', support: 'Grounding exercise' },
  { id: '5', date: '2026-05-20', trigger: 'Feeling criticised', response: 'Intrusive thoughts', intensity: 'Felt manageable', support: 'Journalling' },
  { id: '6', date: '2026-05-18', trigger: 'Financial stress', response: 'Racing thoughts', intensity: 'Felt difficult', support: 'Talking to someone' },
  { id: '7', date: '2026-05-15', trigger: 'Physical exhaustion', response: 'Low mood', intensity: 'Felt overwhelming', support: 'Movement' },
  { id: '8', date: '2026-05-12', trigger: 'Feeling ignored or dismissed', response: 'Urge to isolate', intensity: 'Felt difficult', support: 'Grounding exercise' },
];

type SelectFieldProps = {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
};

function SelectField({ label, value, options, onChange }: SelectFieldProps) {
  const [open, setOpen] = useState(false);
  return (
    <div className="space-y-1">
      <p className="text-xs text-white/60 uppercase tracking-wide">{label}</p>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm"
        style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
      >
        <span className={value ? '' : 'opacity-60'}>{value || `Select ${label.toLowerCase()}...`}</span>
        {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </button>
      {open && (
        <div className="rounded-lg border max-h-44 overflow-y-auto" style={{ borderColor: '#b5a47d', backgroundColor: '#153a21' }}>
          {options.map(opt => (
            <button
              key={opt}
              onClick={() => { onChange(opt); setOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm hover:opacity-80 transition-opacity border-b border-white/10 last:border-0"
              style={{ color: value === opt ? '#b5a47d' : 'rgba(255,255,255,0.8)', fontWeight: value === opt ? 600 : 400 }}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function TrackerTab({ entries, onAdd }: { entries: TriggerEntry[]; onAdd: (e: TriggerEntry) => void }) {
  const [showForm, setShowForm] = useState(false);
  const [trigger, setTrigger] = useState('');
  const [response, setResponse] = useState('');
  const [intensity, setIntensity] = useState('');
  const [support, setSupport] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleSave = () => {
    if (!trigger || !response || !intensity || !support) return;
    onAdd({
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      trigger, response, intensity, support
    });
    setTrigger(''); setResponse(''); setIntensity(''); setSupport('');
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
        <p className="text-white/80 text-sm">
          Notice situations, environments, or experiences that may affect how you feel.
        </p>
        <p className="text-white/50 text-xs mt-2 italic">
          This tool helps you understand patterns over time, without judgement.
        </p>
      </div>

      {/* Reflection Tool */}
      <div className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
        <div className="flex items-center gap-3 mb-2">
          <BookOpen className="h-5 w-5" style={{ color: '#153a21' }} />
          <h3 className="font-semibold" style={{ color: '#153a21' }}>Reflection Tool</h3>
        </div>
        <p className="text-sm opacity-80 mb-3" style={{ color: '#153a21' }}>
          A guided space for deeper self-reflection. Based on pages 61–62 of the CPTSD Toolkit.
        </p>
        <Button className="w-full" style={{ backgroundColor: '#153a21', color: '#b5a47d' }}>
          Open Reflection Tool
        </Button>
      </div>

      {/* Log Trigger Button */}
      {!showForm && (
        <Button
          onClick={() => setShowForm(true)}
          className="w-full"
          style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
        >
          <Plus className="h-4 w-4 mr-2" />
          Log a Trigger
        </Button>
      )}

      {/* Log Form */}
      {showForm && (
        <div className="p-4 rounded-lg border-2 space-y-4" style={{ borderColor: '#b5a47d' }}>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold" style={{ color: '#b5a47d' }}>New Entry</h3>
            <button onClick={() => setShowForm(false)} style={{ color: '#b5a47d' }}>
              <X className="h-5 w-5" />
            </button>
          </div>
          <SelectField label="What was happening at the time?" value={trigger} options={triggerOptions} onChange={setTrigger} />
          <SelectField label="What did you notice?" value={response} options={responseOptions} onChange={setResponse} />
          <SelectField label="How strong did this feel?" value={intensity} options={intensityOptions} onChange={setIntensity} />
          <SelectField label="What supported you afterwards?" value={support} options={supportOptions} onChange={setSupport} />
          <Button
            onClick={handleSave}
            disabled={!trigger || !response || !intensity || !support}
            className="w-full"
            style={{ backgroundColor: '#b5a47d', color: '#153a21', opacity: (!trigger || !response || !intensity || !support) ? 0.5 : 1 }}
          >
            Save Entry
          </Button>
        </div>
      )}

      {/* Entries List */}
      <div className="space-y-3">
        <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Recent Entries</h3>
        {entries.map(entry => (
          <div key={entry.id} className="rounded-lg overflow-hidden">
            <button
              onClick={() => setExpandedId(expandedId === entry.id ? null : entry.id)}
              className="w-full flex items-center justify-between p-4"
              style={{ backgroundColor: '#b5a47d' }}
            >
              <div className="text-left">
                <p className="font-medium text-sm" style={{ color: '#153a21' }}>{entry.trigger}</p>
                <p className="text-xs opacity-70 mt-0.5" style={{ color: '#153a21' }}>{entry.date}</p>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: '#153a21', color: '#b5a47d' }}
                >
                  {entry.intensity.replace('Felt ', '')}
                </span>
                {expandedId === entry.id
                  ? <ChevronUp className="h-4 w-4" style={{ color: '#153a21' }} />
                  : <ChevronDown className="h-4 w-4" style={{ color: '#153a21' }} />
                }
              </div>
            </button>
            {expandedId === entry.id && (
              <div className="p-4 border-t-2 space-y-2" style={{ backgroundColor: '#1e4d30', borderColor: '#b5a47d' }}>
                <div>
                  <p className="text-xs text-white/50 uppercase">Response</p>
                  <p className="text-sm" style={{ color: '#b5a47d' }}>{entry.response}</p>
                </div>
                <div>
                  <p className="text-xs text-white/50 uppercase">Intensity</p>
                  <p className="text-sm" style={{ color: '#b5a47d' }}>{entry.intensity}</p>
                </div>
                <div>
                  <p className="text-xs text-white/50 uppercase">Support Used</p>
                  <p className="text-sm" style={{ color: '#b5a47d' }}>{entry.support}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function CalendarTab({ entries }: { entries: TriggerEntry[] }) {
  const today = new Date();
  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const entriesByDate = useMemo(() => {
    const map: Record<string, TriggerEntry[]> = {};
    entries.forEach(e => {
      if (!map[e.date]) map[e.date] = [];
      map[e.date].push(e);
    });
    return map;
  }, [entries]);

  const selectedEntries = selectedDate ? (entriesByDate[selectedDate] || []) : [];

  const intensityColor = (i: string) => {
    if (i === 'Felt manageable') return '#4ade80';
    if (i === 'Felt difficult') return '#facc15';
    return '#f87171';
  };

  const prevMonth = () => setViewDate(new Date(year, month - 1, 1));
  const nextMonth = () => setViewDate(new Date(year, month + 1, 1));

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  return (
    <div className="space-y-4">
      {/* Month navigation */}
      <div className="flex items-center justify-between">
        <button onClick={prevMonth} className="p-2 rounded-lg hover:opacity-80" style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h3 className="font-semibold" style={{ color: '#b5a47d' }}>
          {MONTHS[month]} {year}
        </h3>
        <button onClick={nextMonth} className="p-2 rounded-lg hover:opacity-80" style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-5 w-5 rotate-180" />
        </button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 gap-1 mb-1">
        {DAYS.map(d => (
          <div key={d} className="text-center text-xs text-white/50 py-1">{d}</div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {cells.map((day, i) => {
          if (!day) return <div key={`empty-${i}`} />;
          const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const dayEntries = entriesByDate[dateStr] || [];
          const isToday = today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
          return (
            <button
              key={dateStr}
              onClick={() => { if (dayEntries.length) { setSelectedDate(dateStr); setDialogOpen(true); } }}
              className="aspect-square flex flex-col items-center justify-center rounded-lg relative"
              style={{
                backgroundColor: isToday ? 'rgba(181,164,125,0.2)' : 'transparent',
                border: isToday ? '1px solid #b5a47d' : '1px solid transparent',
              }}
            >
              <span className="text-xs" style={{ color: isToday ? '#b5a47d' : 'rgba(255,255,255,0.7)' }}>{day}</span>
              {dayEntries.length > 0 && (
                <div
                  className="rounded-full mt-0.5"
                  style={{
                    width: dayEntries.length > 1 ? 10 : 7,
                    height: dayEntries.length > 1 ? 10 : 7,
                    backgroundColor: intensityColor(dayEntries[0].intensity),
                  }}
                />
              )}
            </button>
          );
        })}
      </div>

      <div className="flex gap-4 flex-wrap mt-2">
        {[['Felt manageable', '#4ade80'], ['Felt difficult', '#facc15'], ['Felt overwhelming', '#f87171']].map(([label, color]) => (
          <div key={label} className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
            <span className="text-xs text-white/60">{label}</span>
          </div>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#b5a47d' }}>Entries for {selectedDate}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2">
            {selectedEntries.map(e => (
              <div key={e.id} className="p-3 rounded-lg space-y-2" style={{ backgroundColor: '#b5a47d' }}>
                <div><p className="text-xs opacity-60" style={{ color: '#153a21' }}>Trigger</p><p className="text-sm font-medium" style={{ color: '#153a21' }}>{e.trigger}</p></div>
                <div><p className="text-xs opacity-60" style={{ color: '#153a21' }}>Response</p><p className="text-sm" style={{ color: '#153a21' }}>{e.response}</p></div>
                <div><p className="text-xs opacity-60" style={{ color: '#153a21' }}>Intensity</p><p className="text-sm" style={{ color: '#153a21' }}>{e.intensity}</p></div>
                <div><p className="text-xs opacity-60" style={{ color: '#153a21' }}>Support</p><p className="text-sm" style={{ color: '#153a21' }}>{e.support}</p></div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ChartsTab({ entries }: { entries: TriggerEntry[] }) {
  const triggerFreqData = useMemo(() => {
    const counts: Record<string, number> = {};
    entries.forEach(e => { counts[e.trigger] = (counts[e.trigger] || 0) + 1; });
    return Object.entries(counts)
      .map(([name, count]) => ({ name: name.length > 16 ? name.slice(0, 15) + '…' : name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [entries]);

  const intensityData = useMemo(() => {
    const intensityMap: Record<string, number> = { 'Felt manageable': 1, 'Felt difficult': 2, 'Felt overwhelming': 3 };
    return entries
      .slice()
      .sort((a, b) => a.date.localeCompare(b.date))
      .map(e => ({
        date: e.date.slice(5),
        intensity: intensityMap[e.intensity] || 1,
      }));
  }, [entries]);

  return (
    <div className="space-y-8">
      {/* Trigger Frequency */}
      <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
        <h3 className="font-semibold mb-4" style={{ color: '#b5a47d' }}>Trigger Frequency</h3>
        {triggerFreqData.length > 0 ? (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={triggerFreqData} layout="vertical" margin={{ left: 0, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis type="number" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="name" width={90} tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#153a21', border: '1px solid #b5a47d', color: '#b5a47d', fontSize: 12 }}
                formatter={(val: number) => [val, 'Entries']}
              />
              <Bar dataKey="count" fill="#b5a47d" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-white/50 text-sm text-center py-6">No data yet. Log some triggers to see your frequency chart.</p>
        )}
      </div>

      {/* Intensity Over Time */}
      <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
        <h3 className="font-semibold mb-4" style={{ color: '#b5a47d' }}>Intensity Over Time</h3>
        {intensityData.length > 0 ? (
          <>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={intensityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 10 }} />
                <YAxis
                  domain={[1, 3]}
                  ticks={[1, 2, 3]}
                  tickFormatter={(v) => v === 1 ? 'Low' : v === 2 ? 'Mid' : 'High'}
                  tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 10 }}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: '#153a21', border: '1px solid #b5a47d', color: '#b5a47d', fontSize: 12 }}
                  formatter={(v: number) => [v === 1 ? 'Manageable' : v === 2 ? 'Difficult' : 'Overwhelming', 'Intensity']}
                />
                <Line type="monotone" dataKey="intensity" stroke="#b5a47d" strokeWidth={2} dot={{ fill: '#b5a47d', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2 flex-wrap">
              {[['1 = Manageable', '#4ade80'], ['2 = Difficult', '#facc15'], ['3 = Overwhelming', '#f87171']].map(([label, color]) => (
                <div key={label} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                  <span className="text-xs text-white/50">{label}</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-white/50 text-sm text-center py-6">No data yet. Log some triggers to see your intensity trend.</p>
        )}
      </div>
    </div>
  );
}

export function TherapySessions() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('tracker');
  const [entries, setEntries] = useState<TriggerEntry[]>(sampleEntries);

  const handleAddEntry = (entry: TriggerEntry) => {
    setEntries(prev => [entry, ...prev]);
  };

  const tabs: { key: TabType; label: string; icon: typeof BarChart2 }[] = [
    { key: 'tracker', label: 'Tracker', icon: Plus },
    { key: 'calendar', label: 'Calendar', icon: CalendarDays },
    { key: 'charts', label: 'Charts', icon: BarChart2 },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Pattern Awareness</h1>
      </header>

      {/* Sub-tabs */}
      <div className="sticky z-40 px-4 py-3 border-b border-white/10 flex gap-2" style={{ backgroundColor: '#153a21', top: '73px' }}>
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === tab.key ? '#b5a47d' : 'transparent',
              color: activeTab === tab.key ? '#153a21' : '#b5a47d',
            }}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        {activeTab === 'tracker' && <TrackerTab entries={entries} onAdd={handleAddEntry} />}
        {activeTab === 'calendar' && <CalendarTab entries={entries} />}
        {activeTab === 'charts' && <ChartsTab entries={entries} />}
      </main>

      <BottomNavBar />
    </div>
  );
}
