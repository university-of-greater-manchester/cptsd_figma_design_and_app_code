import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';

export function SignUpStep1() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    middleName: '',
    lastName: '',
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhone = (phone: string) => {
    return /^\+?[\d\s-]{10,}$/.test(phone);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName) newErrors.firstName = 'First name is required';
    if (!formData.lastName) newErrors.lastName = 'Last name is required';

    if (!formData.username) {
      newErrors.username = 'Username is required';
    } else if (!validateEmail(formData.username) && !validatePhone(formData.username)) {
      newErrors.username = 'Please enter a valid email or phone number';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(formData.password)) {
      newErrors.password = 'Password must contain uppercase, lowercase, number and special character';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (validateForm()) {
      // Store form data in sessionStorage for the next step
      sessionStorage.setItem('signupData', JSON.stringify(formData));
      navigate('/signup/verify');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-8" style={{ backgroundColor: '#153a21' }}>
      <div className="w-full max-w-md space-y-6">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Create Account</h1>
          <p className="text-white/80">Step 1 of 2 - Basic Information</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="firstName" className="text-white">First Name *</Label>
            <Input
              id="firstName"
              value={formData.firstName}
              onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
              placeholder="Enter your first name"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
            {errors.firstName && <p className="text-red-400 text-sm">{errors.firstName}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="middleName" className="text-white">Middle Name (Optional)</Label>
            <Input
              id="middleName"
              value={formData.middleName}
              onChange={(e) => setFormData({ ...formData, middleName: e.target.value })}
              placeholder="Enter your middle name"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="lastName" className="text-white">Last Name *</Label>
            <Input
              id="lastName"
              value={formData.lastName}
              onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
              placeholder="Enter your last name"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
            {errors.lastName && <p className="text-red-400 text-sm">{errors.lastName}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">Email or Phone Number *</Label>
            <Input
              id="username"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              placeholder="Enter email or phone number"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
            {errors.username && <p className="text-red-400 text-sm">{errors.username}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">Password *</Label>
            <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="Enter password (min 8 characters)"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
            {errors.password && <p className="text-red-400 text-sm">{errors.password}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword" className="text-white">Confirm Password *</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              placeholder="Re-enter password"
              className="border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
            {errors.confirmPassword && <p className="text-red-400 text-sm">{errors.confirmPassword}</p>}
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              onClick={() => navigate('/')}
              variant="outline"
              className="flex-1 border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              Back to Login
            </Button>
            <Button
              onClick={handleContinue}
              className="flex-1"
              style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            >
              Continue
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
