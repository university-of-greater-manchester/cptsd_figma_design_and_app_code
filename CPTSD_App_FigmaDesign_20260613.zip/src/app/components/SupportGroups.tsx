import { useNavigate } from 'react-router';
import { ArrowLeft, Users, Clock, Lock, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function SupportGroups() {
  const navigate = useNavigate();

  const myGroups = [
    {
      id: 1,
      name: 'Healing Together',
      members: 45,
      nextMeeting: 'May 7, 2026 at 6:00 PM',
      privacy: 'private'
    },
    {
      id: 2,
      name: 'CPTSD Recovery',
      members: 78,
      nextMeeting: 'May 3, 2026 at 7:00 PM',
      privacy: 'private'
    }
  ];

  const availableGroups = [
    {
      id: 3,
      name: 'Mindfulness & Meditation',
      members: 32,
      description: 'Practice mindfulness techniques together',
      privacy: 'public'
    },
    {
      id: 4,
      name: 'Trauma Survivors Network',
      members: 156,
      description: 'Safe space for sharing and support',
      privacy: 'private'
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Support Groups</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4" style={{ color: '#b5a47d' }}>My Groups</h2>
          <div className="space-y-3">
            {myGroups.map((group) => (
              <div key={group.id} className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold" style={{ color: '#153a21' }}>{group.name}</h3>
                  {group.privacy === 'private' ? (
                    <Lock className="h-4 w-4" style={{ color: '#153a21' }} />
                  ) : (
                    <Globe className="h-4 w-4" style={{ color: '#153a21' }} />
                  )}
                </div>
                <div className="space-y-2 text-sm mb-3" style={{ color: '#153a21' }}>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>{group.members} members</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>Next: {group.nextMeeting}</span>
                  </div>
                </div>
                <Button className="w-full" style={{ backgroundColor: '#153a21', color: '#b5a47d' }}>
                  Open Group
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-4" style={{ color: '#b5a47d' }}>Discover Groups</h2>
          <div className="space-y-3">
            {availableGroups.map((group) => (
              <div key={group.id} className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold" style={{ color: '#b5a47d' }}>{group.name}</h3>
                  {group.privacy === 'private' ? (
                    <Lock className="h-4 w-4" style={{ color: '#b5a47d' }} />
                  ) : (
                    <Globe className="h-4 w-4" style={{ color: '#b5a47d' }} />
                  )}
                </div>
                <p className="text-sm mb-3 text-white/80">{group.description}</p>
                <div className="flex items-center gap-2 text-sm mb-3" style={{ color: '#b5a47d' }}>
                  <Users className="h-4 w-4" />
                  <span>{group.members} members</span>
                </div>
                <Button variant="outline" className="w-full border-2" style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}>
                  Join Group
                </Button>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
