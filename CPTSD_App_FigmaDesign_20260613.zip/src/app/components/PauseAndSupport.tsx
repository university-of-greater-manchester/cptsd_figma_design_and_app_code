import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Heart, Phone, Star, List, Settings2, X, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface Exercise {
  id: string;
  title: string;
  description: string;
  category: string;
}

const allExercises: Exercise[] = [
  { id: '1', title: '5-4-3-2-1 Technique', description: 'Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste', category: 'Grounding' },
  { id: '2', title: 'Box Breathing', description: 'Breathe in for 4, hold for 4, out for 4, hold for 4', category: 'Breathing' },
  { id: '3', title: 'Body Scan', description: 'Focus attention on each part of your body from toes to head', category: 'Body' },
  { id: '4', title: 'Safe Place Visualisation', description: 'Imagine a place where you feel completely safe and calm', category: 'Visualisation' },
  { id: '5', title: 'Cold Water Technique', description: 'Hold ice or run cold water over your wrists to help ground yourself', category: 'Grounding' },
  { id: '6', title: 'Progressive Muscle Relaxation', description: 'Tense and release each muscle group to release physical tension', category: 'Body' },
  { id: '7', title: '4-7-8 Breathing', description: 'Inhale for 4, hold for 7, exhale for 8 counts', category: 'Breathing' },
  { id: '8', title: 'Butterfly Hug', description: 'Cross your arms over your chest and alternate gentle taps', category: 'Body' },
];

export function PauseAndSupport() {
  const navigate = useNavigate();
  const [favourites, setFavourites] = useState<string[]>(['1', '2', '3', '4']);
  const [showAllExercises, setShowAllExercises] = useState(false);
  const [showManageFavourites, setShowManageFavourites] = useState(false);

  const toggleFavourite = (id: string) => {
    setFavourites(prev =>
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const favouriteExercises = allExercises.filter(e => favourites.includes(e.id)).slice(0, 4);

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Pause & Support</h1>
      </header>

      <main className="px-3 py-4 pb-24 max-w-md mx-auto">

        {/* Subtle Crisis Notice */}
        <div className="mb-4 p-2.5 rounded-lg border border-white/20">
          <p className="text-white/70 text-xs leading-relaxed">
            Need urgent help? If you feel unsafe or in immediate danger, support is available.{' '}
            <button
              onClick={() => navigate('/safeguarding')}
              className="underline"
              style={{ color: '#b5a47d' }}
            >
              Get Support Contacts
            </button>
          </p>
        </div>

        {/* Grounding Techniques */}
        <div className="mb-4">
          <h2 className="text-base font-semibold mb-1.5" style={{ color: '#b5a47d' }}>Grounding Techniques</h2>
          <p className="text-white/80 text-xs mb-3 leading-relaxed">
            These tools can help you steady your thoughts, body, or emotions when things feel intense.
          </p>

          {/* Favourites */}
          <div className="mb-3">
            <p className="text-white/60 text-xs mb-2 uppercase tracking-wide">Favourites</p>
            {favouriteExercises.length > 0 ? (
              <div className="space-y-2">
                {favouriteExercises.map((ex, i) => (
                  <div key={ex.id} className="p-3 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white/50 mb-0.5">Favourite {i + 1}</p>
                        <h3 className="font-semibold text-sm mb-0.5" style={{ color: '#b5a47d' }}>{ex.title}</h3>
                        <p className="text-white/80 text-xs leading-snug">{ex.description}</p>
                      </div>
                      <Star className="h-4 w-4 flex-shrink-0 mt-1" style={{ color: '#b5a47d' }} fill="#b5a47d" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3 rounded-lg border border-white/20 text-center">
                <p className="text-white/60 text-xs">No favourites selected yet. Use "Manage Favourites" to add some.</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            <Button
              onClick={() => setShowAllExercises(true)}
              className="w-full h-9 text-sm"
              style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            >
              <List className="h-4 w-4 mr-1.5" />
              All Grounding Exercises
            </Button>
            <Button
              onClick={() => setShowManageFavourites(true)}
              variant="outline"
              className="w-full h-9 text-sm border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              <Settings2 className="h-4 w-4 mr-1.5" />
              Manage Favourites
            </Button>
          </div>
        </div>

        {/* More Support Tools */}
        <div>
          <Button
            onClick={() => navigate('/selfcare')}
            variant="outline"
            className="w-full h-9 text-sm border-2"
            style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
          >
            <Heart className="h-4 w-4 mr-1.5" />
            More Support Tools
          </Button>
        </div>
      </main>

      {/* All Grounding Exercises Dialog */}
      <Dialog open={showAllExercises} onOpenChange={setShowAllExercises}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto" style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#b5a47d' }}>All Grounding Exercises</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2">
            {allExercises.map(ex => (
              <div key={ex.id} className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <span className="text-xs opacity-70 block mb-1" style={{ color: '#153a21' }}>{ex.category}</span>
                    <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>{ex.title}</h3>
                    <p className="text-sm opacity-90" style={{ color: '#153a21' }}>{ex.description}</p>
                  </div>
                  <button onClick={() => toggleFavourite(ex.id)} className="flex-shrink-0 mt-1">
                    <Star
                      className="h-5 w-5"
                      style={{ color: '#153a21' }}
                      fill={favourites.includes(ex.id) ? '#153a21' : 'none'}
                    />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Manage Favourites Dialog */}
      <Dialog open={showManageFavourites} onOpenChange={setShowManageFavourites}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto" style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#b5a47d' }}>Manage Favourites</DialogTitle>
          </DialogHeader>
          <p className="text-white/70 text-sm mt-1 mb-4">
            Tap the heart icon to add or remove exercises from your favourites.
          </p>
          <div className="space-y-3">
            {allExercises.map(ex => {
              const isFav = favourites.includes(ex.id);
              return (
                <div
                  key={ex.id}
                  className="p-4 rounded-lg flex items-center justify-between gap-3"
                  style={{ backgroundColor: isFav ? '#b5a47d' : 'transparent', border: `1px solid ${isFav ? '#b5a47d' : 'rgba(181,164,125,0.3)'}` }}
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm" style={{ color: isFav ? '#153a21' : '#b5a47d' }}>{ex.title}</h3>
                    <p className="text-xs mt-0.5 opacity-70" style={{ color: isFav ? '#153a21' : '#b5a47d' }}>{ex.category}</p>
                  </div>
                  <button
                    onClick={() => toggleFavourite(ex.id)}
                    className="p-2 rounded-full flex-shrink-0"
                    style={{ backgroundColor: isFav ? '#153a21' : '#b5a47d' }}
                  >
                    <Heart
                      className="h-4 w-4"
                      style={{ color: isFav ? '#b5a47d' : '#153a21' }}
                      fill={isFav ? '#b5a47d' : 'none'}
                    />
                  </button>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      <BottomNavBar />
    </div>
  );
}
