import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Send, User } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function Messages() {
  const navigate = useNavigate();
  const [message, setMessage] = useState('');

  const conversations = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      lastMessage: 'Looking forward to our session tomorrow!',
      time: '2 hours ago',
      unread: 2
    },
    {
      id: 2,
      name: 'Support Group - Healing Together',
      lastMessage: 'New post in the group',
      time: '1 day ago',
      unread: 5
    }
  ];

  const chatMessages = [
    {
      id: 1,
      sender: 'therapist',
      text: 'Hi! How are you feeling today?',
      time: '10:30 AM'
    },
    {
      id: 2,
      sender: 'user',
      text: 'I am doing better, thank you. The breathing exercises have been helpful.',
      time: '10:35 AM'
    },
    {
      id: 3,
      sender: 'therapist',
      text: 'That is wonderful to hear! Keep practicing them regularly.',
      time: '10:37 AM'
    },
    {
      id: 4,
      sender: 'therapist',
      text: 'Looking forward to our session tomorrow!',
      time: '10:38 AM'
    }
  ];

  const [selectedChat, setSelectedChat] = useState(conversations[0]);

  const handleSend = () => {
    if (message.trim()) {
      setMessage('');
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#b5a47d' }}>
            <User className="h-5 w-5" style={{ color: '#153a21' }} />
          </div>
          <div>
            <h1 className="text-lg font-semibold" style={{ color: '#b5a47d' }}>{selectedChat.name}</h1>
            <p className="text-xs text-white/60">Online</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6 space-y-4 overflow-y-auto">
        {chatMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs px-4 py-3 rounded-lg ${
                msg.sender === 'user' ? 'rounded-br-none' : 'rounded-bl-none'
              }`}
              style={{
                backgroundColor: msg.sender === 'user' ? '#b5a47d' : '#2a5a35',
                color: msg.sender === 'user' ? '#153a21' : '#b5a47d'
              }}
            >
              <p className="text-sm mb-1">{msg.text}</p>
              <p className="text-xs opacity-70">{msg.time}</p>
            </div>
          </div>
        ))}
      </main>

      <div className="sticky bottom-0 px-4 py-4 border-t border-white/10" style={{ backgroundColor: '#153a21' }}>
        <div className="flex gap-2">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="border-2"
            style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
          />
          <Button
            onClick={handleSend}
            size="icon"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
