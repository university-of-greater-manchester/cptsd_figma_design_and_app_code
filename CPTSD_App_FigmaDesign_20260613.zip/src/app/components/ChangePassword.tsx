import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { SideMenu } from './SideMenu';

export function ChangePassword() {
  const navigate = useNavigate();
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validatePassword = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.currentPassword) {
      newErrors.currentPassword = 'Current password is required';
    }

    if (!formData.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (formData.newPassword.length < 8) {
      newErrors.newPassword = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(formData.newPassword)) {
      newErrors.newPassword = 'Password must contain uppercase, lowercase, number and special character';
    }

    if (formData.newPassword === formData.currentPassword) {
      newErrors.newPassword = 'New password must be different from current password';
    }

    if (formData.newPassword !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validatePassword()) {
      toast.success('Password changed successfully!');
      setTimeout(() => navigate('/home'), 1500);
    }
  };

  const togglePasswordVisibility = (field: 'current' | 'new' | 'confirm') => {
    setShowPasswords({ ...showPasswords, [field]: !showPasswords[field] });
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Change Password</h1>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>Password Requirements:</h3>
          <ul className="text-white/80 text-sm space-y-1 list-disc list-inside">
            <li>At least 8 characters long</li>
            <li>Contains uppercase and lowercase letters</li>
            <li>Contains at least one number</li>
            <li>Contains at least one special character (@$!%*?&)</li>
          </ul>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-white">Current Password *</Label>
            <div className="relative">
              <Input
                type={showPasswords.current ? 'text' : 'password'}
                value={formData.currentPassword}
                onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                placeholder="Enter current password"
                className="border-2 pr-12"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
              <button
                type="button"
                onClick={() => togglePasswordVisibility('current')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
                style={{ color: '#153a21' }}
              >
                {showPasswords.current ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            {errors.currentPassword && <p className="text-red-400 text-sm">{errors.currentPassword}</p>}
          </div>

          <div className="space-y-2">
            <Label className="text-white">New Password *</Label>
            <div className="relative">
              <Input
                type={showPasswords.new ? 'text' : 'password'}
                value={formData.newPassword}
                onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                placeholder="Enter new password"
                className="border-2 pr-12"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
              <button
                type="button"
                onClick={() => togglePasswordVisibility('new')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
                style={{ color: '#153a21' }}
              >
                {showPasswords.new ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            {errors.newPassword && <p className="text-red-400 text-sm">{errors.newPassword}</p>}
          </div>

          <div className="space-y-2">
            <Label className="text-white">Confirm New Password *</Label>
            <div className="relative">
              <Input
                type={showPasswords.confirm ? 'text' : 'password'}
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="Re-enter new password"
                className="border-2 pr-12"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
              <button
                type="button"
                onClick={() => togglePasswordVisibility('confirm')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
                style={{ color: '#153a21' }}
              >
                {showPasswords.confirm ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            {errors.confirmPassword && <p className="text-red-400 text-sm">{errors.confirmPassword}</p>}
          </div>

          <div className="flex gap-3 pt-6">
            <Button
              onClick={() => navigate('/home')}
              variant="outline"
              className="flex-1 border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 text-lg font-semibold"
              style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            >
              Change Password
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
