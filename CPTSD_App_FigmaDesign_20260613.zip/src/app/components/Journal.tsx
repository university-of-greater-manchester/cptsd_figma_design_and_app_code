import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Plus, BookOpen } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function Journal() {
  const navigate = useNavigate();
  const [showNewEntry, setShowNewEntry] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const journalEntries = [
    {
      id: 1,
      title: 'Reflection on Today',
      date: 'April 29, 2026',
      preview: 'Today was challenging but I managed to use the breathing techniques...'
    },
    {
      id: 2,
      title: 'Small Victories',
      date: 'April 27, 2026',
      preview: 'I was able to go to the grocery store without feeling overwhelmed...'
    },
    {
      id: 3,
      title: 'Processing Emotions',
      date: 'April 25, 2026',
      preview: 'Feeling more aware of my triggers after therapy session...'
    }
  ];

  const handleSave = () => {
    if (!title || !content) {
      toast.error('Please add both title and content');
      return;
    }
    toast.success('Journal entry saved!');
    setTitle('');
    setContent('');
    setShowNewEntry(false);
  };

  if (showNewEntry) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
        <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
          <SideMenu />
          <Button variant="ghost" size="icon" onClick={() => setShowNewEntry(false)} style={{ color: '#b5a47d' }}>
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>New Entry</h1>
        </header>

        <main className="px-4 py-6 max-w-2xl mx-auto">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-white">Entry Title</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Give your entry a title..."
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Your Thoughts</Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your thoughts, feelings, and reflections..."
                className="min-h-96 border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setShowNewEntry(false)}
                variant="outline"
                className="flex-1 border-2"
                style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                className="flex-1 text-lg font-semibold"
                style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
              >
                Save Entry
              </Button>
            </div>
          </div>
        </main>

        {/* Bottom Navigation Bar */}
        <BottomNavBar />
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Journal</h1>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto pb-24">
        <Button
          onClick={() => setShowNewEntry(true)}
          className="w-full mb-6 text-lg font-semibold flex items-center justify-center gap-2"
          style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
        >
          <Plus className="h-5 w-5" />
          New Entry
        </Button>

        <div className="space-y-3">
          {journalEntries.map((entry) => (
            <div
              key={entry.id}
              className="p-4 rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
              style={{ backgroundColor: '#b5a47d' }}
            >
              <div className="flex items-start gap-3">
                <BookOpen className="h-5 w-5 mt-1" style={{ color: '#153a21' }} />
                <div className="flex-1">
                  <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>{entry.title}</h3>
                  <p className="text-sm mb-2 opacity-70" style={{ color: '#153a21' }}>{entry.date}</p>
                  <p className="text-sm opacity-80" style={{ color: '#153a21' }}>{entry.preview}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
