import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';

export function ForgotPassword() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleResetPassword = () => {
    if (username) {
      setSubmitted(true);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: '#153a21' }}>
        <div className="w-full max-w-md space-y-6 text-center">
          <div className="mb-8">
            <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Check Your Email</h1>
            <p className="text-white/80">
              We've sent password reset instructions to <strong style={{ color: '#b5a47d' }}>{username}</strong>
            </p>
          </div>

          <Button
            onClick={() => navigate('/')}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            Back to Login
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: '#153a21' }}>
      <div className="w-full max-w-md space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Reset Password</h1>
          <p className="text-white/80">Enter your email or phone number to receive reset instructions</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">Email or Phone Number</Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your email or phone number"
              className="border-2"
              style={{
                backgroundColor: '#b5a47d',
                borderColor: '#b5a47d',
                color: '#153a21'
              }}
            />
          </div>

          <Button
            onClick={handleResetPassword}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            disabled={!username}
          >
            Send Reset Instructions
          </Button>

          <Button
            onClick={() => navigate('/')}
            variant="outline"
            className="w-full border-2"
            style={{
              borderColor: '#b5a47d',
              color: '#b5a47d',
              backgroundColor: 'transparent'
            }}
          >
            Back to Login
          </Button>
        </div>
      </div>
    </div>
  );
}
