import { useNavigate } from 'react-router';
import { ArrowLeft, Share2, Mail, MessageCircle, Copy, Link as LinkIcon } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function ShareApp() {
  const navigate = useNavigate();
  const appUrl = 'https://cptsd-toolkit.app';
  const shareMessage = 'Check out CPTSD Toolkit - A supportive app for managing Complex PTSD and supporting your healing journey.';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    toast.success('Link copied to clipboard!');
  };

  const handleShareEmail = () => {
    const subject = 'CPTSD Toolkit - Healing Support App';
    const body = `${shareMessage}\n\n${appUrl}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const handleShareSMS = () => {
    const body = `${shareMessage} ${appUrl}`;
    window.location.href = `sms:?body=${encodeURIComponent(body)}`;
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'CPTSD Toolkit',
          text: shareMessage,
          url: appUrl,
        });
        toast.success('Shared successfully!');
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      toast.info('Share feature not supported on this device');
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Share This App</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
          <div className="flex items-start gap-3">
            <Share2 className="h-6 w-6 mt-1" style={{ color: '#153a21' }} />
            <div>
              <h3 className="font-semibold mb-2" style={{ color: '#153a21' }}>Spread Hope & Healing</h3>
              <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
                Help others discover CPTSD Toolkit and support their recovery journey.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <Button
            onClick={handleNativeShare}
            className="w-full flex items-center justify-start gap-3 text-lg h-auto py-4"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <Share2 className="h-6 w-6" />
            <div className="text-left">
              <div className="font-semibold">Share via...</div>
              <div className="text-xs opacity-80">Use your device's share menu</div>
            </div>
          </Button>

          <Button
            onClick={handleCopyLink}
            className="w-full flex items-center justify-start gap-3 text-lg h-auto py-4"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <Copy className="h-6 w-6" />
            <div className="text-left">
              <div className="font-semibold">Copy Link</div>
              <div className="text-xs opacity-80">Copy URL to clipboard</div>
            </div>
          </Button>

          <Button
            onClick={handleShareEmail}
            className="w-full flex items-center justify-start gap-3 text-lg h-auto py-4"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <Mail className="h-6 w-6" />
            <div className="text-left">
              <div className="font-semibold">Share via Email</div>
              <div className="text-xs opacity-80">Send recommendation by email</div>
            </div>
          </Button>

          <Button
            onClick={handleShareSMS}
            className="w-full flex items-center justify-start gap-3 text-lg h-auto py-4"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <MessageCircle className="h-6 w-6" />
            <div className="text-left">
              <div className="font-semibold">Share via SMS</div>
              <div className="text-xs opacity-80">Send text message</div>
            </div>
          </Button>
        </div>

        <div className="mt-6 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <div className="flex items-start gap-3">
            <LinkIcon className="h-5 w-5 mt-0.5" style={{ color: '#b5a47d' }} />
            <div>
              <h4 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>App Link</h4>
              <p className="text-sm text-white/80 font-mono break-all">
                {appUrl}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
          <h4 className="font-semibold mb-2" style={{ color: '#153a21' }}>Why Share?</h4>
          <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
            By sharing CPTSD Toolkit, you're helping others who may be struggling to find the
            support and resources they need for their healing journey. Together, we create a
            stronger community of support and understanding.
          </p>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
