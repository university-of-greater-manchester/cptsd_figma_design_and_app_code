import { useNavigate } from 'react-router';
import { ArrowLeft, Heart, Shield, Brain, BookOpen, Activity, LayoutDashboard } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function AboutApp() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>About CPTSD Toolkit</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: '#b5a47d' }}>
            <Heart className="h-10 w-10" style={{ color: '#153a21' }} />
          </div>
          <h2 className="text-2xl font-semibold mb-2" style={{ color: '#b5a47d' }}>CPTSD Toolkit</h2>
          <p className="text-white/70">Version 1.0.0</p>
        </div>

        <div className="space-y-6">
          <div className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
            <h3 className="font-semibold mb-2" style={{ color: '#153a21' }}>Our Mission</h3>
            <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
              CPTSD Toolkit is designed to support individuals living with Complex Post-Traumatic
              Stress Disorder (CPTSD) on their healing journey. We provide tools, resources, and
              a safe space for self-care and recovery.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold" style={{ color: '#b5a47d' }}>Features</h3>

            {[
              { icon: Activity, title: 'Daily Check-in', desc: 'Track how you are feeling each day and monitor your wellbeing over time.' },
              { icon: Heart, title: 'Pause & Support', desc: 'Grounding tools and support to help you through difficult moments.' },
              { icon: Shield, title: 'Personal Safety', desc: 'Create and maintain your personal safety plan and access support contacts.' },
              { icon: Brain, title: 'Pattern Awareness', desc: 'Recognise your patterns over time using the Trigger Tracker and charts.' },
              { icon: BookOpen, title: 'Library', desc: 'Access the CPTSD Toolkit educational content, organised by chapter.' },
              { icon: LayoutDashboard, title: 'Dashboard', desc: 'View your wellbeing overview and progress at a glance.' },
            ].map(feature => (
              <div key={feature.title} className="p-3 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
                <div className="flex items-start gap-3">
                  <feature.icon className="h-5 w-5 mt-0.5" style={{ color: '#b5a47d' }} />
                  <div>
                    <h4 className="font-semibold mb-1" style={{ color: '#b5a47d' }}>{feature.title}</h4>
                    <p className="text-sm text-white/80">{feature.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
            <h3 className="font-semibold mb-2" style={{ color: '#153a21' }}>Disclaimer</h3>
            <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
              This app is not a substitute for professional medical advice, diagnosis, or treatment.
              Always seek the advice of your physician or qualified health provider with any
              questions you may have regarding a medical condition.
            </p>
          </div>

          <div className="text-center pt-4">
            <p className="text-sm text-white/60">
              Made with <Heart className="h-4 w-4 inline" style={{ color: '#b5a47d' }} /> for healing and recovery
            </p>
          </div>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
