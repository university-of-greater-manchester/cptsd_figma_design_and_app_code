import { useNavigate } from 'react-router';
import { ArrowLeft, Wind, Music, Sparkles, Sun, Moon } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function SelfCare() {
  const navigate = useNavigate();

  const activities = [
    {
      icon: Wind,
      title: 'Breathing Exercises',
      description: 'Guided breathing to reduce anxiety',
      duration: '5-10 min'
    },
    {
      icon: Music,
      title: 'Meditation',
      description: 'Calming meditation sessions',
      duration: '10-20 min'
    },
    {
      icon: Sparkles,
      title: 'Grounding Techniques',
      description: '5-4-3-2-1 sensory grounding',
      duration: '5 min'
    },
    {
      icon: Sun,
      title: 'Morning Routine',
      description: 'Start your day mindfully',
      duration: '15 min'
    },
    {
      icon: Moon,
      title: 'Sleep Preparation',
      description: 'Wind down for better sleep',
      duration: '20 min'
    },
    {
      icon: Music,
      title: 'Calming Sounds',
      description: 'Nature sounds and music',
      duration: 'As needed'
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Self-Care Activities</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <p className="text-white/80 mb-6">Choose an activity to help you feel grounded and calm</p>

        <div className="grid grid-cols-1 gap-4">
          {activities.map((activity, index) => (
            <div
              key={index}
              className="p-4 rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
              style={{ backgroundColor: '#b5a47d' }}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full" style={{ backgroundColor: '#153a21' }}>
                  <activity.icon className="h-6 w-6" style={{ color: '#b5a47d' }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>{activity.title}</h3>
                  <p className="text-sm mb-2 opacity-80" style={{ color: '#153a21' }}>{activity.description}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 rounded" style={{ backgroundColor: '#153a21', color: '#b5a47d' }}>
                      {activity.duration}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>Quick Tip</h3>
          <p className="text-white/80 text-sm">
            Regular self-care practice can help manage CPTSD symptoms. Try to engage in at least one activity daily, even if just for a few minutes.
          </p>
        </div>
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
