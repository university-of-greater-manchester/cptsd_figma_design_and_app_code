import { useState } from 'react';
import { useNavigate } from 'react-router';
import { User, Bell, LogOut, KeyRound, MessageSquare, BookOpen, Heart, Brain, Shield, LayoutDashboard, Activity } from 'lucide-react';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

export function HomeScreen() {
  const navigate = useNavigate();
  const [notificationCount] = useState(3);
  const userName = 'User';

  const handleLogout = () => {
    navigate('/');
  };

  // Order: (1) Daily Check-in / (2) Pause & Support / (3) Personal Safety / (4) Pattern Awareness / (5) Library / (6) Dashboard
  const quickAccessButtons = [
    { icon: Activity, label: 'Daily Check-in', description: 'Track your mood and wellbeing', path: '/daily-checkin' },
    { icon: Heart, label: 'Pause & Support', description: 'Tools and support to help you through difficult moments', path: '/pause-support' },
    { icon: Shield, label: 'Personal Safety', description: 'Support & Planning', path: '/safeguarding' },
    { icon: Brain, label: 'Pattern Awareness', description: 'Recognise your patterns over time', path: '/therapy' },
    { icon: BookOpen, label: 'Library', description: 'Educational content and resources', path: '/resources' },
    { icon: LayoutDashboard, label: 'Dashboard', description: 'View your progress and overview', path: '/dashboard' },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      {/* Header */}
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center justify-between border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />

        {/* User Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="relative">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#b5a47d' }}>
                  <User className="h-5 w-5" style={{ color: '#153a21' }} />
                </div>
                {notificationCount > 0 && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-white text-xs font-semibold">
                    {notificationCount}
                  </div>
                )}
              </div>
              <div className="text-left">
                <p className="font-medium" style={{ color: '#b5a47d' }}>{userName}</p>
                <div className="flex items-center gap-1 text-xs text-white/70">
                  <Bell className="h-3 w-3" />
                  <span>{notificationCount} new</span>
                </div>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56" style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
            <DropdownMenuItem className="cursor-pointer" style={{ color: '#b5a47d' }} onClick={() => navigate('/update-profile')}>
              <User className="mr-2 h-4 w-4" />
              <span>Update Profile</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer" style={{ color: '#b5a47d' }} onClick={() => navigate('/change-password')}>
              <KeyRound className="mr-2 h-4 w-4" />
              <span>Change Password</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer" style={{ color: '#b5a47d' }} onClick={() => navigate('/messages')}>
              <MessageSquare className="mr-2 h-4 w-4" />
              <span>Messages ({notificationCount})</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator style={{ backgroundColor: '#b5a47d' }} />
            <DropdownMenuItem
              className="cursor-pointer text-red-400"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Logout</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6 pb-24">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Welcome Back, {userName}</h1>
            <p className="text-white/80">How are you feeling today?</p>
          </div>

          {/* Quick Access Grid */}
          <div className="grid grid-cols-2 gap-4">
            {quickAccessButtons.map((button, index) => (
              <button
                key={index}
                onClick={() => button.path && navigate(button.path)}
                className="p-4 rounded-lg text-left hover:opacity-90 transition-opacity"
                style={{ backgroundColor: '#b5a47d' }}
              >
                <button.icon className="h-8 w-8 mb-3" style={{ color: '#153a21' }} />
                <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>
                  {button.label}
                </h3>
                <p className="text-xs opacity-80" style={{ color: '#153a21' }}>
                  {button.description}
                </p>
              </button>
            ))}
          </div>
        </div>
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
