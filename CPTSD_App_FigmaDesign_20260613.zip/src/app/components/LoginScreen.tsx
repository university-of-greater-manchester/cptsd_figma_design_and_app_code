import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';

export function LoginScreen() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSignIn = () => {
    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }

    // Mock authentication - in real app, this would validate against backend
    if (username && password.length >= 8) {
      navigate('/home');
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: '#153a21' }}>
      <div className="w-full max-w-md space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Welcome Back</h1>
          <p className="text-white/80">Sign in to continue</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">Username / Email</Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username or email"
              className="border-2"
              style={{
                backgroundColor: '#b5a47d',
                borderColor: '#b5a47d',
                color: '#153a21'
              }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="border-2"
              style={{
                backgroundColor: '#b5a47d',
                borderColor: '#b5a47d',
                color: '#153a21'
              }}
            />
          </div>

          {error && (
            <p className="text-red-400 text-sm">{error}</p>
          )}

          <Button
            onClick={handleSignIn}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            Sign In
          </Button>

          <div className="text-center">
            <button
              onClick={() => navigate('/forgot-password')}
              className="text-sm underline"
              style={{ color: '#b5a47d' }}
            >
              Forgot Password?
            </button>
          </div>

          <div className="text-center pt-4">
            <p className="text-white/80 mb-2">Don't have an account?</p>
            <Button
              onClick={() => navigate('/signup')}
              variant="outline"
              className="border-2"
              style={{
                borderColor: '#b5a47d',
                color: '#b5a47d',
                backgroundColor: 'transparent'
              }}
            >
              Sign Up
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
