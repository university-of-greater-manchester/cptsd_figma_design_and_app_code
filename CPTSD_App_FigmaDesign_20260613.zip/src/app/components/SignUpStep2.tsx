import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { toast } from 'sonner';

export function SignUpStep2() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState('');
  const [timeLeft, setTimeLeft] = useState(180); // 3 minutes in seconds
  const [canResend, setCanResend] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const signupData = sessionStorage.getItem('signupData');
    if (!signupData) {
      navigate('/signup');
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setCanResend(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVerify = () => {
    if (otp.length !== 6) {
      setError('Please enter the complete 6-digit OTP');
      return;
    }

    // Mock OTP verification - in real app, this would validate against backend
    if (otp === '123456') {
      const signupData = sessionStorage.getItem('signupData');
      if (signupData) {
        // In real app, save to database here
        sessionStorage.removeItem('signupData');
        toast.success('Account created successfully! Please sign in.');
        navigate('/');
      }
    } else {
      setError('Invalid OTP. Please try again.');
    }
  };

  const handleResend = () => {
    // Mock resend OTP
    setTimeLeft(180);
    setCanResend(false);
    setOtp('');
    setError('');
    toast.success('OTP has been resent');
  };

  const signupData = JSON.parse(sessionStorage.getItem('signupData') || '{}');
  const username = signupData.username || '';

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ backgroundColor: '#153a21' }}>
      <div className="w-full max-w-md space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Verify Your Account</h1>
          <p className="text-white/80">Step 2 of 2 - OTP Verification</p>
        </div>

        <div className="text-center mb-6">
          <p className="text-white/90 mb-4">
            We've sent a 6-digit verification code to
          </p>
          <p className="font-semibold mb-6" style={{ color: '#b5a47d' }}>{username}</p>
          <p className="text-white/70 text-sm">
            Time remaining: <span className="font-semibold" style={{ color: '#b5a47d' }}>{formatTime(timeLeft)}</span>
          </p>
        </div>

        <div className="flex justify-center mb-6">
          <InputOTP
            maxLength={6}
            value={otp}
            onChange={(value) => {
              setOtp(value);
              setError('');
            }}
          >
            <InputOTPGroup>
              {[0, 1, 2, 3, 4, 5].map((index) => (
                <InputOTPSlot
                  key={index}
                  index={index}
                  className="border-2"
                  style={{
                    backgroundColor: '#b5a47d',
                    borderColor: '#b5a47d',
                    color: '#153a21',
                    fontSize: '1.5rem',
                    width: '3rem',
                    height: '3rem'
                  }}
                />
              ))}
            </InputOTPGroup>
          </InputOTP>
        </div>

        {error && (
          <p className="text-red-400 text-sm text-center">{error}</p>
        )}

        <div className="space-y-3">
          <Button
            onClick={handleVerify}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            disabled={otp.length !== 6}
          >
            Verify OTP
          </Button>

          {canResend ? (
            <Button
              onClick={handleResend}
              variant="outline"
              className="w-full border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              Resend OTP
            </Button>
          ) : (
            <p className="text-center text-white/60 text-sm">
              Didn't receive the code? You can resend in {formatTime(timeLeft)}
            </p>
          )}

          <Button
            onClick={() => navigate('/signup')}
            variant="ghost"
            className="w-full"
            style={{ color: '#b5a47d' }}
          >
            Back to Sign Up
          </Button>
        </div>

        <div className="text-center text-sm text-white/60 mt-6">
          <p>For testing purposes, use OTP: <span className="font-mono" style={{ color: '#b5a47d' }}>123456</span></p>
        </div>
      </div>
    </div>
  );
}
