import { useNavigate } from 'react-router';
import { ArrowLeft, BookOpen, Heart, CheckCircle, Activity, BarChart2 } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const stateDistribution = [
  { name: 'Okay', value: 3, color: '#4ade80' },
  { name: 'A bit unsettled', value: 2, color: '#facc15' },
  { name: 'Stressed / Activated', value: 1, color: '#fb923c' },
  { name: 'Overwhelmed', value: 1, color: '#f87171' },
];

export function Dashboard() {
  const navigate = useNavigate();

  const stats = [
    {
      icon: CheckCircle,
      label: 'Check-ins logged this week',
      value: '5',
    },
    {
      icon: BookOpen,
      label: 'Journal entries written',
      value: '12',
    },
    {
      icon: Activity,
      label: 'Upcoming Sessions',
      value: '2',
    },
    {
      icon: Heart,
      label: 'Self-care activities used',
      value: '8',
    }
  ];

  const recentActivity = [
    { type: 'check-in', title: 'Daily Check-in Completed', date: 'Today, 9:30 AM', icon: Activity },
    { type: 'journal', title: 'New Journal Entry', date: 'Yesterday, 8:15 PM', icon: BookOpen },
    { type: 'self-care', title: 'Breathing Exercise', date: 'Yesterday, 2:45 PM', icon: Heart },
  ];

  const quickActions = [
    { label: 'Daily Check-in', path: '/daily-checkin', icon: Activity },
    { label: 'Journal', path: '/journal', icon: BookOpen },
    { label: 'Self-Care', path: '/selfcare', icon: Heart },
    { label: 'Pattern Awareness', path: '/therapy', icon: BarChart2 },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Dashboard</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-2" style={{ color: '#b5a47d' }}>Welcome Back!</h2>
          <p className="text-white/80">Here's your progress overview</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {stats.map((stat, index) => (
            <div key={index} className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className="h-5 w-5" style={{ color: '#153a21' }} />
              </div>
              <div className="text-3xl font-bold mb-1" style={{ color: '#153a21' }}>
                {stat.value}
              </div>
              <div className="text-xs opacity-80" style={{ color: '#153a21' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* State Overview This Week */}
        <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
          <h3 className="font-semibold mb-4" style={{ color: '#153a21' }}>State Overview This Week</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={stateDistribution}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {stateDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value: number, name: string) => [`${value} check-in${value !== 1 ? 's' : ''}`, name]}
                contentStyle={{ backgroundColor: '#153a21', border: '1px solid #b5a47d', color: '#b5a47d' }}
              />
              <Legend
                formatter={(value) => <span style={{ color: '#153a21', fontSize: '11px' }}>{value}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
          <p className="text-xs opacity-70 text-center mt-2" style={{ color: '#153a21' }}>
            Distribution of states from your check-ins this week
          </p>
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={() => navigate(action.path)}
                className="p-4 rounded-lg text-left hover:opacity-90 transition-opacity border-2"
                style={{ borderColor: '#b5a47d', backgroundColor: 'transparent' }}
              >
                <action.icon className="h-6 w-6 mb-2" style={{ color: '#b5a47d' }} />
                <span className="text-sm font-medium" style={{ color: '#b5a47d' }}>
                  {action.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h3 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Recent Activity</h3>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div key={index} className="p-3 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-full" style={{ backgroundColor: '#b5a47d' }}>
                    <activity.icon className="h-4 w-4" style={{ color: '#153a21' }} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium mb-1" style={{ color: '#b5a47d' }}>{activity.title}</h4>
                    <p className="text-xs text-white/60">{activity.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
