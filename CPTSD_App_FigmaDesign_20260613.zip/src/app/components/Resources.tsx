import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, ChevronRight, Printer, BookOpen, X, FileWarning } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

// Place the CPTSD Toolkit PDF at: public/cptsd-toolkit.pdf
// The viewer will open directly to the chapter's starting page.
const PDF_PATH = '/cptsd-toolkit.pdf';

type FilterType = 'All' | 'Understanding' | 'Tools' | 'Reflect' | 'Media';

interface Chapter {
  title: string;
  pages: string;
  startPage: number;
  category: FilterType[];
}

const chapters: Chapter[] = [
  { title: 'Introduction', pages: '3–6', startPage: 3, category: ['Understanding'] },
  { title: 'The Nervous System and Dysregulation', pages: '8–14', startPage: 8, category: ['Understanding'] },
  { title: 'The Survival Response', pages: '17–22', startPage: 17, category: ['Understanding'] },
  { title: 'Self-Soothing Strategies That Actually Work', pages: '23–34', startPage: 23, category: ['Tools'] },
  { title: 'From Survival to Self-Kindness', pages: '35–46', startPage: 35, category: ['Reflect'] },
  { title: 'The Door to Your Inner Child', pages: '47–50', startPage: 47, category: ['Reflect'] },
  { title: 'From Wounds to Words', pages: '51–56', startPage: 51, category: ['Reflect', 'Tools'] },
  { title: "When Thoughts Aren't the Whole Story", pages: '57–64', startPage: 57, category: ['Understanding', 'Reflect'] },
  { title: 'Beneath the Noise: Reclaiming Inner Knowing', pages: '65–70', startPage: 65, category: ['Reflect'] },
  { title: 'From Inner Signals to Inner Self', pages: '71–80', startPage: 71, category: ['Reflect', 'Tools'] },
  { title: 'From Connection to Cognition', pages: '81–86', startPage: 81, category: ['Understanding'] },
  { title: 'Who You Think You Are vs Who You Truly Are', pages: '87–90', startPage: 87, category: ['Reflect'] },
  { title: 'Finding Support Where You Are', pages: '91–94', startPage: 91, category: ['Understanding'] },
  { title: 'Letting Go of Familiar Pain', pages: '95–98', startPage: 95, category: ['Reflect'] },
  { title: 'Making Safety Real', pages: '99–101', startPage: 99, category: ['Tools'] },
  { title: 'Tools for the Bad Days', pages: '103–113', startPage: 103, category: ['Tools'] },
  { title: 'Crisis Plan', pages: '114–115', startPage: 114, category: ['Tools'] },
  { title: 'A Letter to the Tired, Trying and Dysregulated You', pages: '116', startPage: 116, category: ['Reflect'] },
  { title: 'Notes', pages: '117', startPage: 117, category: ['All'] },
  { title: 'Final Words', pages: '118', startPage: 118, category: ['All'] },
];

const filterTabs: { key: FilterType; label: string }[] = [
  { key: 'All', label: 'All' },
  { key: 'Understanding', label: 'Understanding' },
  { key: 'Tools', label: 'Tools' },
  { key: 'Reflect', label: 'Reflect' },
  { key: 'Media', label: 'Media' },
];

interface PDFViewerProps {
  chapter: Chapter;
  onClose: () => void;
}

function PDFViewer({ chapter, onClose }: PDFViewerProps) {
  const [pdfError, setPdfError] = useState(false);
  // Opens the PDF directly at the chapter's starting page using the #page fragment.
  // All modern browsers (Chrome, Firefox, Edge, Safari) honour this fragment in their built-in PDF viewers.
  const pdfUrl = `${PDF_PATH}#page=${chapter.startPage}`;

  const handlePrint = () => {
    const printWindow = window.open(pdfUrl, '_blank');
    printWindow?.focus();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ backgroundColor: '#153a21' }}>
      {/* Viewer header */}
      <header
        className="flex-shrink-0 px-4 py-3 flex items-center gap-3 border-b border-white/10"
        style={{ backgroundColor: '#153a21' }}
      >
        <Button variant="ghost" size="icon" onClick={onClose} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: '#b5a47d' }}>
            {chapter.title}
          </p>
          <p className="text-xs text-white/50">Pages {chapter.pages}</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={handlePrint}
          title="Open in new tab / Print"
          style={{ color: '#b5a47d' }}
        >
          <Printer className="h-5 w-5" />
        </Button>
      </header>

      {/* PDF iframe */}
      {!pdfError ? (
        <iframe
          key={pdfUrl}
          src={pdfUrl}
          className="flex-1 w-full border-0"
          title={chapter.title}
          onError={() => setPdfError(true)}
        />
      ) : (
        /* Fallback when PDF hasn't been uploaded yet */
        <div className="flex-1 flex flex-col items-center justify-center gap-6 px-8 text-center">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#b5a47d' }}
          >
            <FileWarning className="h-10 w-10" style={{ color: '#153a21' }} />
          </div>
          <div>
            <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>
              Toolkit PDF not found
            </h3>
            <p className="text-white/70 text-sm leading-relaxed">
              To enable in-app reading, place the CPTSD Toolkit PDF at:
            </p>
            <p
              className="mt-2 px-3 py-1.5 rounded text-sm font-mono"
              style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            >
              public/cptsd-toolkit.pdf
            </p>
            <p className="text-white/50 text-xs mt-3">
              Once uploaded, chapters will open automatically at page {chapter.startPage}.
            </p>
          </div>
          <Button
            onClick={() => window.open(PDF_PATH, '_blank')}
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            <BookOpen className="h-4 w-4 mr-2" />
            Try Opening PDF Directly
          </Button>
        </div>
      )}
    </div>
  );
}

export function Resources() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [openChapter, setOpenChapter] = useState<Chapter | null>(null);

  const filteredChapters = chapters.filter(ch =>
    activeFilter === 'All'
      ? true
      : ch.category.includes(activeFilter) || ch.category.includes('All')
  );

  if (openChapter) {
    return <PDFViewer chapter={openChapter} onClose={() => setOpenChapter(null)} />;
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header
        className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10"
        style={{ backgroundColor: '#153a21' }}
      >
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Library</h1>
      </header>

      {/* Filter Bar */}
      <div
        className="sticky z-40 px-4 py-3 border-b border-white/10 overflow-x-auto"
        style={{ backgroundColor: '#153a21', top: '73px' }}
      >
        <div className="flex gap-2 min-w-max">
          {filterTabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveFilter(tab.key)}
              className="px-4 py-1.5 rounded-full text-sm font-medium transition-all whitespace-nowrap"
              style={{
                backgroundColor: activeFilter === tab.key ? '#b5a47d' : 'transparent',
                color: activeFilter === tab.key ? '#153a21' : '#b5a47d',
                border: `1px solid ${activeFilter === tab.key ? '#b5a47d' : 'rgba(181,164,125,0.4)'}`,
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <p className="text-white/70 text-sm mb-6">
          Select a chapter to read it directly — the PDF will open at that page automatically.
        </p>

        <div className="space-y-2">
          {filteredChapters.map((chapter, index) => (
            <button
              key={index}
              onClick={() => setOpenChapter(chapter)}
              className="w-full flex items-center justify-between p-4 rounded-lg text-left hover:opacity-90 transition-opacity"
              style={{ backgroundColor: '#b5a47d' }}
            >
              <div className="flex-1 min-w-0 mr-3">
                <p className="font-medium text-sm leading-snug" style={{ color: '#153a21' }}>
                  {chapter.title}
                </p>
                <p className="text-xs mt-0.5 opacity-70" style={{ color: '#153a21' }}>
                  page {chapter.pages}
                </p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: '#153a21', color: '#b5a47d' }}
                >
                  {chapter.category[0] === 'All' ? 'General' : chapter.category[0]}
                </span>
                <ChevronRight className="h-4 w-4" style={{ color: '#153a21' }} />
              </div>
            </button>
          ))}

          {filteredChapters.length === 0 && (
            <div className="text-center py-12">
              <p className="text-white/60">No chapters in this category yet.</p>
            </div>
          )}
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
