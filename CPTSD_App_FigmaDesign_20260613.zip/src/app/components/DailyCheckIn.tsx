import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Share2 } from 'lucide-react';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

type OptionButtonProps = {
  label: string;
  selected: boolean;
  onClick: () => void;
};

function OptionButton({ label, selected, onClick }: OptionButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all"
      style={{
        backgroundColor: selected ? '#b5a47d' : 'transparent',
        color: selected ? '#153a21' : '#b5a47d',
        border: `1px solid ${selected ? '#b5a47d' : 'rgba(181,164,125,0.4)'}`,
      }}
    >
      {label}
    </button>
  );
}

const affectingOptions = [
  'Nothing specific', 'Stress', 'Conflict', 'Fatigue',
  'Memories', 'Thoughts', 'Social interaction', 'Other'
];

export function DailyCheckIn() {
  const navigate = useNavigate();
  const [mood, setMood] = useState('');
  const [sleep, setSleep] = useState('');
  const [manageable, setManageable] = useState('');
  const [connection, setConnection] = useState('');
  const [nervousSystem, setNervousSystem] = useState('');
  const [affecting, setAffecting] = useState('');
  const [notes, setNotes] = useState('');
  const [showShareDialog, setShowShareDialog] = useState(false);

  const handleSubmit = () => {
    if (!mood || !sleep || !nervousSystem) {
      toast.error('Please complete the main check-in questions');
      return;
    }
    toast.success('Daily check-in saved successfully!');
    setTimeout(() => navigate('/home'), 1500);
  };

  const shareOptions = ['Just me', 'Trusted person', 'Professional support', 'Export', 'Messaging service'];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold flex-1" style={{ color: '#b5a47d' }}>Daily Check-In</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <p className="text-white/80 mb-6 text-sm">Take a moment to notice how you're doing right now</p>

        <div className="space-y-7">

          {/* How are you feeling right now */}
          <div className="space-y-3">
            <Label className="text-white font-medium">How are you feeling right now?</Label>
            <div className="space-y-2">
              {['Okay', 'A bit unsettled', 'Stressed / Activated', 'Overwhelmed'].map(opt => (
                <OptionButton key={opt} label={opt} selected={mood === opt} onClick={() => setMood(opt)} />
              ))}
            </div>
          </div>

          {/* Sleep last night */}
          <div className="space-y-3">
            <Label className="text-white font-medium">Sleep last night</Label>
            <div className="space-y-2">
              {['Restful', 'Broken', 'Poor', 'Didn\'t sleep', 'Not sure'].map(opt => (
                <OptionButton key={opt} label={opt} selected={sleep === opt} onClick={() => setSleep(opt)} />
              ))}
            </div>
          </div>

          {/* What feels manageable today */}
          <div className="space-y-3">
            <Label className="text-white font-medium">What feels manageable today?</Label>
            <div className="space-y-2">
              {[
                'Usual routine feels manageable',
                'I may need to slow down',
                'Basic tasks feel difficult',
                'I\'m in survival mode today'
              ].map(opt => (
                <OptionButton key={opt} label={opt} selected={manageable === opt} onClick={() => setManageable(opt)} />
              ))}
            </div>
          </div>

          {/* How connected do you feel today */}
          <div className="space-y-3">
            <Label className="text-white font-medium">How connected do you feel today?</Label>
            <div className="space-y-2">
              {['Connected / engaged', 'Somewhat distant', 'Very disconnected / withdrawn'].map(opt => (
                <OptionButton key={opt} label={opt} selected={connection === opt} onClick={() => setConnection(opt)} />
              ))}
            </div>
          </div>

          {/* Nervous System Check */}
          <div className="space-y-3">
            <Label className="text-white font-medium">Nervous System Check</Label>
            <div className="space-y-2">
              {['Calm', 'Slightly tense', 'Activated / stressed', 'Highly activated'].map(opt => (
                <OptionButton key={opt} label={opt} selected={nervousSystem === opt} onClick={() => setNervousSystem(opt)} />
              ))}
            </div>
          </div>

          {/* What's been affecting you today */}
          <div className="space-y-3">
            <Label className="text-white font-medium">What's been affecting you today?</Label>
            <div className="grid grid-cols-2 gap-2">
              {affectingOptions.map(opt => (
                <button
                  key={opt}
                  onClick={() => setAffecting(affecting === opt ? '' : opt)}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-left transition-all"
                  style={{
                    backgroundColor: affecting === opt ? '#b5a47d' : 'transparent',
                    color: affecting === opt ? '#153a21' : '#b5a47d',
                    border: `1px solid ${affecting === opt ? '#b5a47d' : 'rgba(181,164,125,0.4)'}`,
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          {/* Additional Notes */}
          <div className="space-y-3">
            <Label className="text-white font-medium">Additional Notes</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Share any thoughts, observations, or anything you'd like to note..."
              className="min-h-28 border-2"
              style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
            />
          </div>

          {/* Share Snapshot */}
          <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
            <div className="flex items-center gap-3 mb-2">
              <Share2 className="h-5 w-5" style={{ color: '#b5a47d' }} />
              <h3 className="font-semibold" style={{ color: '#b5a47d' }}>Share a snapshot of how you're feeling</h3>
            </div>
            <p className="text-white/70 text-xs mb-3">
              Share a summary of your mood state, capacity, sleep, and connection with someone you trust or your support team.
            </p>
            <Button
              onClick={() => setShowShareDialog(true)}
              variant="outline"
              className="w-full border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share Snapshot
            </Button>
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full text-lg font-semibold"
            style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
          >
            Save Check-In
          </Button>
        </div>
      </main>

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#b5a47d' }}>Share Snapshot</DialogTitle>
          </DialogHeader>
          <p className="text-white/70 text-sm mb-4">
            Choose how you'd like to share your check-in summary:
          </p>
          <div className="space-y-2">
            {shareOptions.map(opt => (
              <button
                key={opt}
                onClick={() => {
                  toast.success(`Shared via: ${opt}`);
                  setShowShareDialog(false);
                }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all hover:opacity-80"
                style={{ backgroundColor: '#b5a47d' }}
              >
                <span className="font-medium text-sm" style={{ color: '#153a21' }}>{opt}</span>
                <ArrowLeft className="h-4 w-4 rotate-180" style={{ color: '#153a21' }} />
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <BottomNavBar />
    </div>
  );
}
