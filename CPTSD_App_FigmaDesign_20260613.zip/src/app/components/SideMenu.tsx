import { useNavigate } from 'react-router';
import { Menu, Heart, Home as HomeIcon, Database, Shield, Info, MessageCircle, Share2 } from 'lucide-react';
import { Button } from './ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from './ui/sheet';

const menuItems = [
  { icon: HomeIcon, label: 'Home', path: '/home' },
  { icon: Database, label: 'Manage Data', path: '/manage-data' },
  { icon: Shield, label: 'Privacy Policy', path: '/privacy-policy' },
  { icon: Info, label: 'About CPTSD Toolkit', path: '/about' },
  { icon: MessageCircle, label: 'Feedback', path: '/feedback' },
  { icon: Share2, label: 'Share This App', path: '/share-app' },
];

export function SideMenu() {
  const navigate = useNavigate();

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" style={{ color: '#b5a47d' }}>
          <Menu className="h-6 w-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 flex flex-col" style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
        <SheetHeader className="sr-only">
          <SheetTitle style={{ color: '#b5a47d' }}>Navigation Menu</SheetTitle>
          <SheetDescription style={{ color: '#b5a47d' }}>
            Access all features and settings
          </SheetDescription>
        </SheetHeader>

        <div className="flex items-center justify-center gap-2 py-5 border-b border-white/10">
          <Heart className="h-7 w-7" style={{ color: '#b5a47d' }} />
          <h2 className="text-lg font-bold" style={{ color: '#b5a47d' }}>CPTSD Toolkit</h2>
        </div>

        <div className="flex-1 mt-6 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:opacity-80 transition-opacity"
              style={{ backgroundColor: 'transparent', color: '#b5a47d' }}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-center py-4 border-t border-white/10">
          <p className="text-base font-semibold" style={{ color: '#b5a47d' }}>Version 1.0.0</p>
        </div>
      </SheetContent>
    </Sheet>
  );
}
