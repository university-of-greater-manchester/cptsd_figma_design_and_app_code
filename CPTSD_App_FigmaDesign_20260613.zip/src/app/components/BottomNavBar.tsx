import { useNavigate, useLocation } from 'react-router';
import { Home, Activity, Brain, FileText, Heart, Users, MessageSquare, BookOpen, ChevronRight, ChevronLeft, Shield, LayoutDashboard } from 'lucide-react';
import { useState, useRef, useEffect, useCallback } from 'react';

const navItems = [
  { icon: Home, label: 'Home', path: '/home' },
  { icon: Activity, label: 'Daily Check-in', path: '/daily-checkin' },
  { icon: Heart, label: 'Pause &\nSupport', path: '/pause-support' },
  { icon: Shield, label: 'Personal Safety', path: '/safeguarding' },
  { icon: Brain, label: 'Pattern\nAwareness', path: '/therapy' },
  { icon: BookOpen, label: 'Library', path: '/resources' },
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: FileText, label: 'Journal', path: '/journal' },
  { icon: Users, label: 'Groups', path: '/support-groups' },
  { icon: MessageSquare, label: 'Messages', path: '/messages' },
];

export function BottomNavBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showRightArrow, setShowRightArrow] = useState(false);
  const [showLeftArrow, setShowLeftArrow] = useState(false);

  const checkScroll = useCallback(() => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowRightArrow(scrollLeft + clientWidth < scrollWidth - 10);
      setShowLeftArrow(scrollLeft > 10);
    }
  }, []);

  // Scroll active tab into view whenever the route changes
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const activeEl = container.querySelector('[data-active="true"]') as HTMLElement | null;
    if (activeEl) {
      const containerLeft = container.getBoundingClientRect().left;
      const elLeft = activeEl.getBoundingClientRect().left;
      const elWidth = activeEl.offsetWidth;
      const containerWidth = container.offsetWidth;
      const targetScroll = container.scrollLeft + (elLeft - containerLeft) - (containerWidth / 2) + (elWidth / 2);
      container.scrollTo({ left: targetScroll, behavior: 'smooth' });
    }

    setTimeout(checkScroll, 300);
  }, [location.pathname, checkScroll]);

  useEffect(() => {
    checkScroll();
    const container = scrollContainerRef.current;
    container?.addEventListener('scroll', checkScroll);
    window.addEventListener('resize', checkScroll);
    return () => {
      container?.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, [checkScroll]);

  const scrollRight = () => {
    scrollContainerRef.current?.scrollBy({ left: 200, behavior: 'smooth' });
  };

  const scrollLeft = () => {
    scrollContainerRef.current?.scrollBy({ left: -200, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t border-white/10 z-50" style={{ backgroundColor: '#153a21' }}>
      <div className="relative">
        {showLeftArrow && (
          <button
            onClick={scrollLeft}
            className="absolute left-0 top-0 bottom-0 px-2 flex items-center justify-center z-10"
            style={{
              background: 'linear-gradient(to left, transparent, #153a21 30%)',
              color: '#b5a47d'
            }}
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
        )}

        <div
          ref={scrollContainerRef}
          className="flex overflow-x-auto py-2 px-2 gap-1 scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const labelLines = item.label.split('\n');
            return (
              <button
                key={item.path}
                data-active={isActive}
                onClick={() => navigate(item.path)}
                className="flex flex-col items-center justify-center min-w-[68px] px-2 py-2 rounded-lg transition-all flex-shrink-0"
                style={{
                  backgroundColor: isActive ? '#b5a47d' : 'transparent',
                  color: isActive ? '#153a21' : '#b5a47d'
                }}
              >
                <item.icon className="h-5 w-5 mb-1" />
                <span className="text-[10px] font-medium text-center leading-tight">
                  {labelLines.map((line, i) => (
                    <span key={i} className="block">{line}</span>
                  ))}
                </span>
              </button>
            );
          })}
        </div>

        {showRightArrow && (
          <button
            onClick={scrollRight}
            className="absolute right-0 top-0 bottom-0 px-2 flex items-center justify-center z-10"
            style={{
              background: 'linear-gradient(to right, transparent, #153a21 30%)',
              color: '#b5a47d'
            }}
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        )}
      </div>
      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
