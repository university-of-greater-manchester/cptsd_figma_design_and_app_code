import { useNavigate } from 'react-router';
import { ArrowLeft, Calendar as CalendarIcon, Clock, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Calendar } from './ui/calendar';
import { useState } from 'react';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function Appointments() {
  const navigate = useNavigate();
  const [date, setDate] = useState<Date | undefined>(new Date());

  const appointments = [
    {
      id: 1,
      title: 'Therapy Session',
      date: 'May 2, 2026',
      time: '2:00 PM',
      location: 'Video Call',
      type: 'therapy'
    },
    {
      id: 2,
      title: 'Psychiatrist Appointment',
      date: 'May 5, 2026',
      time: '10:00 AM',
      location: 'Main Clinic, Room 205',
      type: 'medical'
    },
    {
      id: 3,
      title: 'Support Group Meeting',
      date: 'May 7, 2026',
      time: '6:00 PM',
      location: 'Community Center',
      type: 'group'
    }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Appointments</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg flex justify-center" style={{ backgroundColor: '#b5a47d' }}>
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md"
          />
        </div>

        <Button className="w-full mb-6 text-lg font-semibold" style={{ backgroundColor: '#b5a47d', color: '#153a21' }}>
          Schedule New Appointment
        </Button>

        <h2 className="text-lg font-semibold mb-4" style={{ color: '#b5a47d' }}>Upcoming Appointments</h2>
        <div className="space-y-3">
          {appointments.map((appointment) => (
            <div key={appointment.id} className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
              <h3 className="font-semibold mb-3" style={{ color: '#153a21' }}>{appointment.title}</h3>
              <div className="space-y-2 text-sm" style={{ color: '#153a21' }}>
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  <span>{appointment.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span>{appointment.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>{appointment.location}</span>
                </div>
              </div>
              <div className="flex gap-2 mt-3">
                <Button className="flex-1" style={{ backgroundColor: '#153a21', color: '#b5a47d' }}>
                  View Details
                </Button>
                <Button variant="outline" className="flex-1 border-2" style={{ borderColor: '#153a21', color: '#153a21', backgroundColor: 'transparent' }}>
                  Reschedule
                </Button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar />
    </div>
  );
}
