import { useNavigate } from 'react-router';
import { ArrowLeft, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function PrivacyPolicy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Privacy Policy</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
          <div className="flex items-start gap-3">
            <Shield className="h-6 w-6 mt-1" style={{ color: '#153a21' }} />
            <div>
              <h3 className="font-semibold mb-2" style={{ color: '#153a21' }}>Your Privacy Matters</h3>
              <p className="text-sm opacity-90" style={{ color: '#153a21' }}>
                Last updated: May 3, 2026
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6 text-white/90">
          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Data Collection</h2>
            <p className="text-sm mb-2">
              CPTSD Toolkit collects and stores the following information locally on your device:
            </p>
            <ul className="list-disc list-inside text-sm space-y-1 ml-2">
              <li>Personal profile information (name, email, phone)</li>
              <li>Daily check-in responses and mood tracking</li>
              <li>Journal entries and personal notes</li>
              <li>Safety plan details</li>
              <li>Appointment and session information</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Data Storage</h2>
            <p className="text-sm">
              All your data is stored locally on your device. We do not transmit, store, or process
              your personal information on external servers. Your information remains private and
              under your control at all times.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Data Security</h2>
            <p className="text-sm">
              We implement appropriate security measures to protect your information. However,
              please note that no method of electronic storage is 100% secure. We recommend
              using device-level security features such as passwords or biometric authentication.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Third-Party Sharing</h2>
            <p className="text-sm">
              We do not share, sell, or distribute your personal information to third parties.
              Your data is yours alone and stays on your device.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Your Rights</h2>
            <p className="text-sm mb-2">You have the right to:</p>
            <ul className="list-disc list-inside text-sm space-y-1 ml-2">
              <li>Access all your stored data</li>
              <li>Export your data at any time</li>
              <li>Delete all your data permanently</li>
              <li>Modify your information</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: '#b5a47d' }}>Contact</h2>
            <p className="text-sm">
              If you have questions about this Privacy Policy, please contact us through the
              Feedback section in the app menu.
            </p>
          </section>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
