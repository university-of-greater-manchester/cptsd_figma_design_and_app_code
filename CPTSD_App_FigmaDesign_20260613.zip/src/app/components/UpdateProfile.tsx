import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Camera, User, Image as ImageIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { SideMenu } from './SideMenu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';

export function UpdateProfile() {
  const navigate = useNavigate();
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [showImageOptions, setShowImageOptions] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    firstName: 'User',
    middleName: '',
    lastName: 'Name',
    email: 'user@example.com',
    phone: '+1234567890',
    emergencyContact: '',
    emergencyPhone: ''
  });

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
        setShowImageOptions(false);
        toast.success('Profile picture updated!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraClick = () => {
    cameraInputRef.current?.click();
  };

  const handleGalleryClick = () => {
    galleryInputRef.current?.click();
  };

  const handleSave = () => {
    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast.error('Please fill in all required fields');
      return;
    }
    toast.success('Profile updated successfully!');
    setTimeout(() => navigate('/home'), 1500);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Update Profile</h1>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        {/* Profile Photo */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative">
            <div className="w-24 h-24 rounded-full flex items-center justify-center overflow-hidden" style={{ backgroundColor: '#b5a47d' }}>
              {profileImage ? (
                <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="h-12 w-12" style={{ color: '#153a21' }} />
              )}
            </div>
            <button
              onClick={() => setShowImageOptions(true)}
              className="absolute bottom-0 right-0 p-2 rounded-full"
              style={{ backgroundColor: '#b5a47d' }}
            >
              <Camera className="h-4 w-4" style={{ color: '#153a21' }} />
            </button>
          </div>
          <p className="text-white/70 text-sm mt-2">Tap to change photo</p>
        </div>

        {/* Hidden file inputs */}
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="user"
          onChange={handleImageSelect}
          className="hidden"
        />
        <input
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageSelect}
          className="hidden"
        />

        {/* Image Options Dialog */}
        <Dialog open={showImageOptions} onOpenChange={setShowImageOptions}>
          <DialogContent className="max-w-sm" style={{ backgroundColor: '#153a21', borderColor: '#b5a47d' }}>
            <DialogHeader>
              <DialogTitle style={{ color: '#b5a47d' }}>Choose Photo</DialogTitle>
              <DialogDescription style={{ color: '#b5a47d' }}>
                Select how you would like to update your profile picture
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 pt-4">
              <Button
                onClick={handleCameraClick}
                className="w-full flex items-center justify-center gap-3 text-lg"
                style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
              >
                <Camera className="h-5 w-5" />
                Take Photo
              </Button>
              <Button
                onClick={handleGalleryClick}
                className="w-full flex items-center justify-center gap-3 text-lg"
                style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
              >
                <ImageIcon className="h-5 w-5" />
                Choose from Gallery
              </Button>
              <Button
                onClick={() => setShowImageOptions(false)}
                variant="outline"
                className="w-full border-2"
                style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
              >
                Cancel
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <div className="space-y-4">
          {/* Personal Information */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold" style={{ color: '#b5a47d' }}>Personal Information</h2>

            <div className="space-y-2">
              <Label className="text-white">First Name *</Label>
              <Input
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Middle Name</Label>
              <Input
                value={formData.middleName}
                onChange={(e) => setFormData({ ...formData, middleName: e.target.value })}
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Last Name *</Label>
              <Input
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4 pt-4">
            <h2 className="text-lg font-semibold" style={{ color: '#b5a47d' }}>Contact Information</h2>

            <div className="space-y-2">
              <Label className="text-white">Email *</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Phone Number</Label>
              <Input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="space-y-4 pt-4">
            <h2 className="text-lg font-semibold" style={{ color: '#b5a47d' }}>Emergency Contact</h2>

            <div className="space-y-2">
              <Label className="text-white">Contact Name</Label>
              <Input
                value={formData.emergencyContact}
                onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                placeholder="Emergency contact name"
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Contact Phone</Label>
              <Input
                type="tel"
                value={formData.emergencyPhone}
                onChange={(e) => setFormData({ ...formData, emergencyPhone: e.target.value })}
                placeholder="Emergency contact phone"
                className="border-2"
                style={{ backgroundColor: '#b5a47d', borderColor: '#b5a47d', color: '#153a21' }}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-6">
            <Button
              onClick={() => navigate('/home')}
              variant="outline"
              className="flex-1 border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 text-lg font-semibold"
              style={{ backgroundColor: '#b5a47d', color: '#153a21' }}
            >
              Save Changes
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
