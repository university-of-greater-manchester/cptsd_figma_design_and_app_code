import { useNavigate } from 'react-router';
import { ArrowLeft, Download, Upload, Trash2, Database } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { BottomNavBar } from './BottomNavBar';
import { SideMenu } from './SideMenu';

export function ManageData() {
  const navigate = useNavigate();

  const handleExportData = () => {
    toast.success('Data exported successfully!');
  };

  const handleImportData = () => {
    toast.info('Select file to import data');
  };

  const handleClearData = () => {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      toast.success('All data cleared');
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#153a21' }}>
      <header className="sticky top-0 z-50 px-4 py-4 flex items-center gap-3 border-b border-white/10" style={{ backgroundColor: '#153a21' }}>
        <SideMenu />
        <Button variant="ghost" size="icon" onClick={() => navigate('/home')} style={{ color: '#b5a47d' }}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold" style={{ color: '#b5a47d' }}>Manage Data</h1>
      </header>

      <main className="px-4 py-6 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <div className="flex items-start gap-3">
            <Database className="h-6 w-6 mt-1" style={{ color: '#b5a47d' }} />
            <div>
              <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>Your Data</h3>
              <p className="text-white/80 text-sm">
                Manage your personal data, including exporting, importing, and clearing all stored information.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
            <div className="flex items-start gap-3 mb-3">
              <Download className="h-6 w-6" style={{ color: '#153a21' }} />
              <div className="flex-1">
                <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>Export Data</h3>
                <p className="text-sm opacity-80 mb-3" style={{ color: '#153a21' }}>
                  Download all your data including journal entries, check-ins, and settings
                </p>
              </div>
            </div>
            <Button
              onClick={handleExportData}
              className="w-full"
              style={{ backgroundColor: '#153a21', color: '#b5a47d' }}
            >
              Export My Data
            </Button>
          </div>

          <div className="p-4 rounded-lg" style={{ backgroundColor: '#b5a47d' }}>
            <div className="flex items-start gap-3 mb-3">
              <Upload className="h-6 w-6" style={{ color: '#153a21' }} />
              <div className="flex-1">
                <h3 className="font-semibold mb-1" style={{ color: '#153a21' }}>Import Data</h3>
                <p className="text-sm opacity-80 mb-3" style={{ color: '#153a21' }}>
                  Restore your data from a previous export
                </p>
              </div>
            </div>
            <Button
              onClick={handleImportData}
              className="w-full"
              style={{ backgroundColor: '#153a21', color: '#b5a47d' }}
            >
              Import Data
            </Button>
          </div>

          <div className="p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
            <div className="flex items-start gap-3 mb-3">
              <Trash2 className="h-6 w-6" style={{ color: '#b5a47d' }} />
              <div className="flex-1">
                <h3 className="font-semibold mb-1" style={{ color: '#b5a47d' }}>Clear All Data</h3>
                <p className="text-sm text-white/80 mb-3">
                  Permanently delete all your data from this app. This action cannot be undone.
                </p>
              </div>
            </div>
            <Button
              onClick={handleClearData}
              variant="outline"
              className="w-full border-2"
              style={{ borderColor: '#b5a47d', color: '#b5a47d', backgroundColor: 'transparent' }}
            >
              Clear All Data
            </Button>
          </div>
        </div>

        <div className="mt-6 p-4 rounded-lg border-2" style={{ borderColor: '#b5a47d' }}>
          <h3 className="font-semibold mb-2" style={{ color: '#b5a47d' }}>Data Privacy</h3>
          <p className="text-white/80 text-sm mb-3">
            Your data is stored locally on your device and is never shared with third parties.
            You have full control over your information.
          </p>
          <Button
            onClick={() => navigate('/privacy-policy')}
            variant="ghost"
            className="text-sm"
            style={{ color: '#b5a47d' }}
          >
            View Privacy Policy →
          </Button>
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
