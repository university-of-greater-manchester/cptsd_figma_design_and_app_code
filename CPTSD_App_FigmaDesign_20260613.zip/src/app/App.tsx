import { BrowserRouter, Routes, Route } from 'react-router';
import { Toaster } from './components/ui/sonner';
import { LoginScreen } from './components/LoginScreen';
import { SignUpStep1 } from './components/SignUpStep1';
import { SignUpStep2 } from './components/SignUpStep2';
import { HomeScreen } from './components/HomeScreen';
import { ForgotPassword } from './components/ForgotPassword';
import { DailyCheckIn } from './components/DailyCheckIn';
import { TherapySessions } from './components/TherapySessions';
import { Appointments } from './components/Appointments';
import { Journal } from './components/Journal';
import { SelfCare } from './components/SelfCare';
import { SupportGroups } from './components/SupportGroups';
import { Messages } from './components/Messages';
import { Resources } from './components/Resources';
import { UpdateProfile } from './components/UpdateProfile';
import { ChangePassword } from './components/ChangePassword';
import { PauseAndSupport } from './components/PauseAndSupport';
import { SafeGuarding } from './components/SafeGuarding';
import { ManageData } from './components/ManageData';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { AboutApp } from './components/AboutApp';
import { Feedback } from './components/Feedback';
import { ShareApp } from './components/ShareApp';
import { Dashboard } from './components/Dashboard';

export default function App() {
  return (
    <BrowserRouter>
      <div className="size-full">
        <Routes>
          <Route path="/" element={<LoginScreen />} />
          <Route path="/signup" element={<SignUpStep1 />} />
          <Route path="/signup/verify" element={<SignUpStep2 />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/home" element={<HomeScreen />} />
          <Route path="/daily-checkin" element={<DailyCheckIn />} />
          <Route path="/therapy" element={<TherapySessions />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/journal" element={<Journal />} />
          <Route path="/selfcare" element={<SelfCare />} />
          <Route path="/support-groups" element={<SupportGroups />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/update-profile" element={<UpdateProfile />} />
          <Route path="/change-password" element={<ChangePassword />} />
          <Route path="/pause-support" element={<PauseAndSupport />} />
          <Route path="/safeguarding" element={<SafeGuarding />} />
          <Route path="/manage-data" element={<ManageData />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/about" element={<AboutApp />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/share-app" element={<ShareApp />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
        <Toaster />
      </div>
    </BrowserRouter>
  );
}